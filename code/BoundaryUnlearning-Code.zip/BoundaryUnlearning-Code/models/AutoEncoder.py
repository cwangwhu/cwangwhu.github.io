import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import *
# from .camada_binaria import BinaryLayer

"""
    The autoencoder has the layer size [10, 7, 4, 7, 10] for Cifar10.  
"""

class EncoderFC(nn.Module):


    def __init__(self):
        super(EncoderFC, self).__init__()

        self.fc1 = nn.Linear(10, 7)
        self.af1 = nn.Relu()
        self.bn1 = nn.BatchNorm1d(7)
        self.fc2 = nn.Linear(7, 4)
        self.af2 = nn.Relu()
        self.bn2 = nn.BatchNorm1d(4)

    def forward(self, x):

        x = self.fc1(x)
        x = self.af1(x)
        x = self.bn1(x)
        x = self.fc2(x)
        x = self.af2(x)
        x = self.bn2(x)
        return x


class DecoderFC(nn.Module):
    """
    FC Decoder composed by 3 512-units fully-connected layers
    """

    def __init__(self):
        super(DecoderFC, self).__init__()

        self.fc1 = nn.Linear(4, 7)
        self.af1 = nn.Relu()
        self.bn1 = nn.BatchNorm1d(7)
        self.fc2 = nn.Linear(7, 10)
        self.af2 = nn.Relu()
        self.bn2 = nn.BatchNorm1d(10)

    def forward(self, x):
        """
        :param x: encoded features
        :return:
        """
        x = self.fc1(x)
        x = self.af1(x)
        x = self.bn1(x)
        x = self.fc2(x)
        x = self.af2(x)
        x = self.bn2(x)
        return x


class AE(nn.Module):

    def __init__(self):
        super(AE, self).__init__()

        self.fc_encoder = EncoderFC()
        self.fc_decoder = DecoderFC()

    def forward(self, x, num_pass=0):
        r = self.fc_encoder(x)
        out = self.fc_decoder(r)
        return out