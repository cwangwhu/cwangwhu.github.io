# Boundary Unlearning: Rapid Forgetting of Deep Networks via Shifting the Decision Boundary

## Getting Started
### Prerequisites
**Boundary Unlearning** requires the following packages: 
- Python 3.8.0
- Pytorch 1.10.0
- torchvison 0.11.1
- Sklearn 0.24.2
- Numpy 1.21.2

### Links to downloadable version of the datasets. 
   -- Vggface2: https://www.robots.ox.ac.uk/~vgg/data/vgg_face2/ 

   -- CIFAR-10: http://www.cs.toronto.edu/~kriz/cifar.html

### File Structure 
```
Boundary Unlearning for CIFAR-10
├── data
│   └── CIFAR10
├── models
│   ├── __init__.py
│   └── Nets.py
├── __init__.py
├── adv_generator.py
├── trainer.py
├── utils.py
├── class_unlearning.ipynb
└── README.md
```

The training and evaluation code can be found in 'trainer.py' file. The core code is in 'class_unlearning.ipynb', which is a Jupyter Notebook file. You can run the cells named 'Boundary Shrink' and 'Boundary Expanding' in 'class_unlearning.ipynb' and get the corresponding results.
