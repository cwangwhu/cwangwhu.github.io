import numpy
from data_iterator import DataIterator
import tensorflow as tf
from model import *
import time
import random
import os
import sys
from utils import *
import pandas as pd

EMBEDDING_DIM = 18
HIDDEN_SIZE = 20
ATTENTION_SIZE = 20
best_auc = 0.0
best_auc_gen = 0.0

data = pd.read_csv('user_profile.csv')
data_sort_user = data.sort_values(by="userid" , ascending=True)
data_sort_user['pvalue_level']=data_sort_user['pvalue_level'].fillna(data_sort_user['pvalue_level'].mode()[0])
data_sort_user = data_sort_user.fillna(2.0)

def prepare_data(input, target, maxlen = None, return_neg = False):
    lengths_x = [len(s[4]) for s in input]
    seqs_mid = [inp[3] for inp in input]
    seqs_cat = [inp[4] for inp in input]

    if maxlen is not None:
        new_seqs_mid = []
        new_seqs_cat = []
        new_lengths_x = []
        for l_x, inp in zip(lengths_x, input):
            new_seqs_mid.append(inp[3].astype('int64'))
            new_seqs_cat.append(inp[4].astype('int64'))
            new_lengths_x.append(l_x)
        lengths_x = new_lengths_x
        seqs_mid = new_seqs_mid
        seqs_cat = new_seqs_cat
        if len(lengths_x) < 1:
            return None, None, None, None
    n_samples = len(seqs_mid)
    maxlen_x = numpy.maximum(numpy.max(lengths_x),1)

    mid_his = numpy.zeros((n_samples, maxlen_x)).astype('int64')
    cat_his = numpy.zeros((n_samples, maxlen_x)).astype('int64')
    mid_mask = numpy.zeros((n_samples, maxlen_x)).astype('float32')
    for idx, [s_x, s_y] in enumerate(zip(seqs_mid, seqs_cat)):
        mid_mask[idx, :lengths_x[idx]] = 1.
        mid_his[idx, :lengths_x[idx]] = s_x
        cat_his[idx, :lengths_x[idx]] = s_y

    uids = numpy.array([int(inp[0]) for inp in input])
    mids = numpy.array([int(inp[1]) for inp in input])
    cats = numpy.array([int(inp[2]) for inp in input])
    user_profiles = numpy.zeros([uids.shape[0],9])
    for i in range(9):
        user_profiles[:,-i] = numpy.array([int(inp[-i]) for inp in input])
    return uids, mids, cats, mid_his, cat_his, mid_mask, numpy.array(target), numpy.array(lengths_x), user_profiles


def u_noclk_list(uids, mid_his, cat_his):
    noclk_mid_list = []
    noclk_cat_list = []
    for i in range(uids.shape[0]):
        noclk_tmp_mid = []
        noclk_tmp_cat = []
        for j in range(mid_his[i].shape[0]):
            noclk_tmp_mid_j = []
            noclk_tmp_cat_j = []
            noclk_index = 0
            while True:
                noclk_mid = random.randint(0, 846811)
                if noclk_mid in mid_his[i]:
                    continue
                noclk_tmp_mid_j.append(noclk_mid)
                noclk_tmp_cat_j.append(random.randint(0, 2))
                noclk_index += 1
                if noclk_index >= 5:
                    break
            noclk_tmp_mid.append(noclk_tmp_mid_j)
            noclk_tmp_cat.append(noclk_tmp_cat_j)
        noclk_mid_list.append(noclk_tmp_mid)
        noclk_cat_list.append(noclk_tmp_cat)
    return numpy.array(noclk_mid_list), numpy.array(noclk_cat_list)

def eval(sess, test_data, model, model_path, phase):
    if phase == 1:
        loss_sum = 0.
        accuracy_sum = 0.
        aux_loss_sum = 0.
        nums = 0
        stored_arr = []
        for src, tgt in test_data:

            uids, mids, cats, mid_his, cat_his, mid_mask, target, sl, user_profiles = prepare_data(src, tgt, return_neg=True)
            noclk_mids, noclk_cats = u_noclk_list(uids, mid_his, cat_his)
            prob, loss, acc, aux_loss = model.calculate(sess, [uids, mids, cats, mid_his, cat_his, mid_mask, target, sl, 0, user_profiles, noclk_mids, noclk_cats, phase])
            nums += 1
            loss_sum += loss
            aux_loss_sum = aux_loss
            accuracy_sum += acc
            prob_1 = prob[:, 0].tolist()
            target_1 = target[:, 0].tolist()
            for p ,t in zip(prob_1, target_1):
                stored_arr.append([p, t])
        test_auc = calc_auc(stored_arr)
        accuracy_sum = accuracy_sum / nums
        loss_sum = loss_sum / nums
        aux_loss_sum / nums
        global best_auc
        if best_auc < test_auc:
            best_auc = test_auc
            model.save(sess, model_path)
        return test_auc, loss_sum, accuracy_sum, aux_loss_sum

    elif phase == 3:
        loss_sum = 0.
        accuracy_sum = 0.
        aux_loss_sum = 0.
        nums = 0
        stored_arr = []

        loss_gen_sum = 0.
        accuracy_gen_sum = 0.
        stored_arr_gen = []
        for src, tgt in test_data:
            uids, mids, cats, mid_his, cat_his, mid_mask, target, sl, user_profiles = prepare_data(src, tgt, return_neg=True)
            noclk_mids, noclk_cats = u_noclk_list(uids, mid_his, cat_his)
            prob, loss, acc, aux_loss, probs_gen, loss_gen, acc_gen, aux_loss_gen = model.calculate(sess, [uids, mids, cats, mid_his, cat_his, mid_mask, target, sl, 0, user_profiles, noclk_mids, noclk_cats, phase])
            nums += 1
            loss_sum += loss
            aux_loss_sum = aux_loss
            accuracy_sum += acc
            prob_1 = prob[:, 0].tolist()
            target_1 = target[:, 0].tolist()
            for p ,t in zip(prob_1, target_1):
                stored_arr.append([p, t])

            loss_gen_sum += loss_gen
            accuracy_gen_sum += acc_gen
            aux_loss_gen_sum = aux_loss_gen
            prob_2 = probs_gen[:, 0].tolist()
            target_1 = target[:, 0].tolist()
            for p ,t in zip(prob_2, target_1):
                stored_arr_gen.append([p, t])

        test_auc = calc_auc(stored_arr)
        accuracy_sum = accuracy_sum / nums
        loss_sum = loss_sum / nums
        aux_loss_sum = aux_loss_sum / nums
        aux_loss_gen_sum = aux_loss_gen_sum / nums
        test_auc_gen = calc_auc(stored_arr_gen)
        accuracy_gen_sum = accuracy_gen_sum / nums
        loss_gen_sum = loss_gen_sum / nums


        global best_auc_gen
        if best_auc_gen < test_auc_gen:
            best_auc_gen = test_auc_gen
            model.save(sess, model_path+"_gen")
        return test_auc, loss_sum, accuracy_sum, aux_loss_sum, test_auc_gen, loss_gen_sum, accuracy_gen_sum, aux_loss_gen_sum

def train(
        train_file = "local_train_feature",
        test_file = "local_test_feature",
        batch_size = 1024,
        maxlen = 100,
        test_iter = 100,
        save_iter = 40000,
        model_type = 'DNN',
    seed = 2,
):
    best_model_path = "best_path/" + model_type + str(seed)
    gpu_options = tf.compat.v1.GPUOptions(allow_growth=True)
    n_cat = 3
    n_mid = 846812
    n_uid = 1141730
    n_feature = [97,13,3,7,4,4,2,5]
    with tf.compat.v1.Session(config=tf.compat.v1.ConfigProto(gpu_options=gpu_options)) as sess:
        train_data = DataIterator(train_file, batch_size, maxlen, shuffle_each_epoch=False)
        test_data = DataIterator(test_file, batch_size, maxlen)
        if model_type == 'DNN_Gen':
            model = Model_DNN_Gen(n_uid, n_mid, n_cat, n_feature, EMBEDDING_DIM, HIDDEN_SIZE, ATTENTION_SIZE)
        elif model_type == 'DIN_Gen':
            model = Model_DIN_Gen(n_uid, n_mid, n_cat, n_feature, EMBEDDING_DIM, HIDDEN_SIZE, ATTENTION_SIZE)
        elif model_type == 'DIEN_Gen':
            model = Model_DIEN_Gen(n_uid, n_mid, n_cat, n_feature, EMBEDDING_DIM, HIDDEN_SIZE, ATTENTION_SIZE)

        else:
            print ("Invalid model_type : %s", model_type)
            return
        sess.run(tf.compat.v1.global_variables_initializer())
        sess.run(tf.compat.v1.local_variables_initializer())
        sys.stdout.flush()
        sys.stdout.flush()
        print('phase = 1')
        start_time = time.time()
        lr = 0.001
        phase = 1
        for itr in range(2):
            iter = 0
            loss_sum = 0.0
            accuracy_sum = 0.
            aux_loss_sum = 0.
            for src, tgt in train_data:
                uids, mids, cats, mid_his, cat_his, mid_mask, target, sl, user_profiles = prepare_data(src, tgt, return_neg=True)
                noclk_mids, noclk_cats = u_noclk_list(uids, mid_his, cat_his)
                index = numpy.where(sl>=4)
                if numpy.shape(index)[1]==0:
                    continue
                index_cold = numpy.where(sl==4)
                mid_his[index_cold] = numpy.zeros_like(mid_his[index_cold])
                cat_his[index_cold] = numpy.zeros_like(cat_his[index_cold])
                mid_mask[index_cold] = numpy.zeros_like(mid_mask[index_cold])
                sl[index_cold] = sl[index_cold]-4
                loss, acc, aux_loss = model.train(sess, [uids[index], mids[index], cats[index], mid_his[index], cat_his[index], mid_mask[index], target[index], sl[index], lr, user_profiles[index], noclk_mids[index], noclk_cats[index], phase])
                loss_sum += loss
                accuracy_sum += acc
                aux_loss_sum += aux_loss
                iter += 1
                sys.stdout.flush()
                if (iter % test_iter) == 0:
                    print('train : iter: %d ----> train_loss: %.4f ---- train_accuracy: %.4f ---- train_aux_loss: %.4f' % \
                                          (iter, loss_sum / test_iter, accuracy_sum / test_iter, aux_loss_sum / test_iter))
                    if itr>0 and iter % 500 == 0:
                        print('test in the training :   test_auc: %.4f ----test_loss: %.4f ---- test_accuracy: %.4f ---- test_aux_loss: %.4f' % eval(sess, test_data, model, best_model_path, phase))
                    loss_sum = 0.0
                    accuracy_sum = 0.0
                    aux_loss_sum = 0.0
                    #break
            lr *= 0.5
            print('*'*40)
            print(iter)
            print('training time of phase 1: %.4f'%(time.time() - start_time))

        start_time = time.time()
        lr = 0.001
        phase = 2
        print('phase = 2')
        
        for itr in range(2):
            iter = 0
            loss_D_sum = 0.0
            acc_D_sum = 0.0
            loss_G_sum = 0.0
            acc_G_sum = 0.0
            train_loss = 0
            seq_sum = 0
            user_sum = 0
            for src, tgt in train_data:
                uids, mids, cats, mid_his, cat_his, mid_mask, target, sl, user_profiles = prepare_data(src, tgt, return_neg=True)
                seq_sum += numpy.sum(sl)
                user_sum += sl.shape[0]
                index = numpy.where(sl>=5)
                if numpy.shape(index)[1]==0:
                    continue
                loss_D, acc_D, loss_G, acc_G = model.train(sess, [uids[index], mids[index], cats[index], mid_his[index], cat_his[index], mid_mask[index], target[index], sl[index], lr, user_profiles[index], phase])
                loss_D_sum += numpy.mean(loss_D)
                acc_D_sum += acc_D
                loss_G_sum += numpy.mean(loss_G)
                acc_G_sum += acc_G
                iter += 1
                sys.stdout.flush()
                if (iter % test_iter) == 0:
                    print('----------  lr: %.8f   --------------' % lr)
                    print('this is gen : iter: %d ----> D loss: %.4f ---- D acc: %.4f ---- G loss: %.4f ---- G acc: %.4f' % \
                                          (iter, loss_D_sum / test_iter, acc_D_sum / test_iter, loss_G_sum / test_iter, acc_G_sum / test_iter))
                    if abs(loss_G_sum / test_iter - train_loss) < 1e-6:
                        break
                    train_loss = loss_G_sum / test_iter
                    loss_D_sum = 0.0
                    acc_D_sum = 0.0
                    loss_G_sum = 0.0
                    acc_G_sum = 0.0

            lr *= 0.5
            print('*'*40)
            print(iter)
            print('training time of phase 2: %.4f'%(time.time() - start_time))
            print("sequence:")
            print(seq_sum/user_sum)

        start_time = time.time()
        lr = 0.001
        phase = 3
        print('phase = 3')
        for itr in range(2):
            iter = 0
            loss_sum = 0.0
            accuracy_sum = 0.
            aux_loss_sum = 0.
            loss_gen_sum = 0.
            accuracy_gen_sum = 0.
            for src, tgt in train_data:
                uids, mids, cats, mid_his, cat_his, mid_mask, target, sl, user_profiles = prepare_data(src, tgt, return_neg=True)
                noclk_mids, noclk_cats = u_noclk_list(uids, mid_his, cat_his)
                index = numpy.where(sl>=4)
                if numpy.shape(index)[1]==0:
                    continue
                index_cold = numpy.where(sl==4)
                mid_his[index_cold] = numpy.zeros_like(mid_his[index_cold])
                cat_his[index_cold] = numpy.zeros_like(cat_his[index_cold])
                mid_mask[index_cold] = numpy.zeros_like(mid_mask[index_cold])
                sl[index_cold] = sl[index_cold]-4
                loss_gen, acc_gen, aux_loss = model.train(sess, [uids[index], mids[index], cats[index], mid_his[index], cat_his[index], mid_mask[index], target[index], sl[index], lr, user_profiles[index], noclk_mids[index], noclk_cats[index], phase])
                loss = 0
                acc = 0
                loss_sum += loss
                accuracy_sum += acc
                aux_loss_sum += aux_loss
                loss_gen_sum += loss_gen
                accuracy_gen_sum += acc_gen
                iter += 1
                sys.stdout.flush()
                if (iter % test_iter) == 0:
                    print('this is gen : iter: %d ----> train_loss: %.4f ---- train_loss_gen: %.4f ---- train_accuracy: %.4f ---- train_accuracy_gen: %.4f ---- tran_aux_loss: %.4f' % \
                                          (iter, loss_sum / test_iter, loss_gen_sum / test_iter, accuracy_sum / test_iter, accuracy_gen_sum / test_iter, aux_loss_sum / test_iter))
                    test_auc, loss_sum, accuracy_sum, aux_loss_sum, test_auc_gen, loss_gen_sum, accuracy_gen_sum, aux_loss_gen_sum = eval(sess, test_data, model, best_model_path, phase)
                    print('  this is gen :    test_auc: %.4f ----test_loss: %.4f ---- test_accuracy: %.4f ---- test_aux_loss: %.4f ---- test_auc_gen: %.4f ----test_loss_gen: %.4f ---- test_accuracy_gen: %.4f ---- test_aux_loss_gen: %.4f' % (test_auc, loss_sum, accuracy_sum, aux_loss_sum, test_auc_gen, loss_gen_sum, accuracy_gen_sum, aux_loss_gen_sum ))
                    global best_auc_gen
                    if best_auc_gen == test_auc_gen:
                        model.save(sess, best_model_path+"_phase2_phase3")
                        item_his_eb_gen_sum_show, item_his_eb_sum_show = model.show_gen_real_dif(sess,[uids, mids, cats, mid_his, cat_his, mid_mask, target, sl, lr, user_profiles, phase])
                        print('item_his_eb_gen_sum_show')
                        print(item_his_eb_gen_sum_show)
                        print('*'*40)
                        print('item_his_eb_sum_show')
                        print(item_his_eb_sum_show)
                        print("the best model of phase3 saved!          test_auc_gen: %.4f"%test_auc_gen)
                    loss_sum = 0.0
                    accuracy_sum = 0.0
                    loss_gen_sum = 0.0
                    accuracy_gen_sum = 0.0
                    aux_loss_sum = 0.0
                    #break
            lr *= 0.5
            print('*'*40)
            print(iter)
            print('training time of phase 3: %.4f'%(time.time() - start_time))
        print('best test_auc_gen: %.4f'%best_auc_gen)

def test(
        train_file = "local_train_feature",
        test_file = "local_test_feature",
        batch_size = 1024,
        maxlen = 100,
        test_iter = 100,
        save_iter = 40000,
        model_type = 'DNN',
	seed = 2,
):

    model_path = "best_path/" + model_type + str(seed) + "_gen"
    gpu_options = tf.compat.v1.GPUOptions(allow_growth=True)
    n_cat = 3
    n_mid = 846812
    n_uid = 1141730
    n_feature = [97,13,3,7,4,4,2,5]
    with tf.compat.v1.Session(config=tf.compat.v1.ConfigProto(gpu_options=gpu_options)) as sess:
        test_data = DataIterator(test_file, batch_size, maxlen)
        if model_type == 'DNN_Gen':
            model = Model_DNN_Gen(n_uid, n_mid, n_cat, n_feature, EMBEDDING_DIM, HIDDEN_SIZE, ATTENTION_SIZE)
        elif model_type == 'DIN_Gen':
            model = Model_DIN_Gen(n_uid, n_mid, n_cat, n_feature, EMBEDDING_DIM, HIDDEN_SIZE, ATTENTION_SIZE)
        elif model_type == 'DIEN_Gen':
            model = Model_DIEN_Gen(n_uid, n_mid, n_cat, n_feature, EMBEDDING_DIM, HIDDEN_SIZE, ATTENTION_SIZE)

        else:
            print ("Invalid model_type : %s", model_type)
            return
        model.restore(sess, model_path)
        print('      test_auc: %.4f ----test_loss: %.4f ---- test_accuracy: %.4f ---- test_aux_loss: %.4f ---- test_auc_gen: %.4f ----test_loss_gen: %.4f ---- test_accuracy_gen: %.4f ---- test_aux_gen_loss: %.4f' % eval(sess, test_data, model, model_path, 3))


if __name__ == '__main__':
    if len(sys.argv) == 5:
        SEED = int(sys.argv[4])
    else:
        SEED = 3
    tf.compat.v1.set_random_seed(SEED)
    numpy.random.seed(SEED)
    random.seed(SEED)
    os.environ["CUDA_VISIBLE_DEVICES"] = sys.argv[3]
    if sys.argv[1] == 'train':
        train(model_type=sys.argv[2], seed=SEED)
    elif sys.argv[1] == 'test':
        test(model_type=sys.argv[2], seed=SEED)
    else:
        print('do nothing...')