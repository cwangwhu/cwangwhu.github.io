prepare data:

You can get the data from aliyun website:
https://tianchi.aliyun.com/dataset/dataDetail?dataId=56

Then, you can process the downloaded dataset in the same way as:
https://github.com/mouna99/dien


When you see the files below, you can follow the next guidance.
user_profile.csv
local_train_feature
local_test_feature


train model applied with GF2:
python train.py train [model name]_Gen

The model blelow had been supported:
DNN
DIN
DIEN