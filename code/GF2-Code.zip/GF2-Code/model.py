import tensorflow as tf
from tensorflow.python.ops.rnn_cell import GRUCell
from rnn import dynamic_rnn
from utils import *
from Dice import dice
class Model(object):
    def __init__(self, n_uid, n_mid, n_cat, n_feature, EMBEDDING_DIM, HIDDEN_SIZE, ATTENTION_SIZE, use_negsampling = False):
        with tf.name_scope('Inputs'):
            self.mid_his_batch_ph = tf.placeholder(tf.int32, [None, None], name='mid_his_batch_ph')
            self.cat_his_batch_ph = tf.placeholder(tf.int32, [None, None], name='cat_his_batch_ph')
            self.uid_batch_ph = tf.placeholder(tf.int32, [None, ], name='uid_batch_ph')
            self.mid_batch_ph = tf.placeholder(tf.int32, [None, ], name='mid_batch_ph')
            self.cat_batch_ph = tf.placeholder(tf.int32, [None, ], name='cat_batch_ph')
            self.uprofile_batch_ph1 = tf.placeholder(tf.int32, [None, ], name='uprofile_batch_ph1')
            self.uprofile_batch_ph2 = tf.placeholder(tf.int32, [None, ], name='uprofile_batch_ph2')
            self.uprofile_batch_ph3 = tf.placeholder(tf.int32, [None, ], name='uprofile_batch_ph3')
            self.uprofile_batch_ph4 = tf.placeholder(tf.int32, [None, ], name='uprofile_batch_ph4')
            self.uprofile_batch_ph5 = tf.placeholder(tf.int32, [None, ], name='uprofile_batch_ph5')
            self.uprofile_batch_ph6 = tf.placeholder(tf.int32, [None, ], name='uprofile_batch_ph6')
            self.uprofile_batch_ph7 = tf.placeholder(tf.int32, [None, ], name='uprofile_batch_ph7')
            self.uprofile_batch_ph8 = tf.placeholder(tf.int32, [None, ], name='uprofile_batch_ph8')

            self.mask = tf.placeholder(tf.float32, [None, None], name='mask')
            self.seq_len_ph = tf.placeholder(tf.int32, [None], name='seq_len_ph')
            self.target_ph = tf.placeholder(tf.float32, [None, None], name='target_ph')
            self.lr = tf.placeholder(tf.float64, [])
            self.use_negsampling =use_negsampling
            if use_negsampling:
                self.noclk_mid_batch_ph = tf.placeholder(tf.int32, [None, None, None], name='noclk_mid_batch_ph') #generate 3 item IDs from negative sampling.
                self.noclk_cat_batch_ph = tf.placeholder(tf.int32, [None, None, None], name='noclk_cat_batch_ph')

        # Embedding layer
        with tf.variable_scope('Embedding_layer'):
            self.uid_embeddings_var = tf.get_variable("uid_embedding_var", [n_uid, EMBEDDING_DIM])
            tf.summary.histogram('uid_embeddings_var', self.uid_embeddings_var)
            self.uid_batch_embedded = tf.nn.embedding_lookup(self.uid_embeddings_var, self.uid_batch_ph)

            self.mid_embeddings_var = tf.get_variable("mid_embedding_var", [n_mid, EMBEDDING_DIM])
            tf.summary.histogram('mid_embeddings_var', self.mid_embeddings_var)
            self.mid_batch_embedded = tf.nn.embedding_lookup(self.mid_embeddings_var, self.mid_batch_ph)
            self.mid_his_batch_embedded = tf.nn.embedding_lookup(self.mid_embeddings_var, self.mid_his_batch_ph)
            if self.use_negsampling:
                self.noclk_mid_his_batch_embedded = tf.nn.embedding_lookup(self.mid_embeddings_var, self.noclk_mid_batch_ph)

            self.cat_embeddings_var = tf.get_variable("cat_embedding_var", [n_cat, 2])
            tf.summary.histogram('cat_embeddings_var', self.cat_embeddings_var)
            self.cat_batch_embedded = tf.nn.embedding_lookup(self.cat_embeddings_var, self.cat_batch_ph)
            self.cat_his_batch_embedded = tf.nn.embedding_lookup(self.cat_embeddings_var, self.cat_his_batch_ph)
            if self.use_negsampling:
                self.noclk_cat_his_batch_embedded = tf.nn.embedding_lookup(self.cat_embeddings_var, self.noclk_cat_batch_ph)
            self.uprofile_embeddings_var1 = tf.get_variable("uprofile_embedding_var1", [n_feature[0], 2])
            self.uprofile_batch_embedded1 = tf.nn.embedding_lookup(self.uprofile_embeddings_var1, self.uprofile_batch_ph1)
            self.uprofile_embeddings_var2 = tf.get_variable("uprofile_embedding_var2", [n_feature[1], 2])
            self.uprofile_batch_embedded2 = tf.nn.embedding_lookup(self.uprofile_embeddings_var2, self.uprofile_batch_ph2)
            self.uprofile_embeddings_var3 = tf.get_variable("uprofile_embedding_var3", [n_feature[2], 2])
            self.uprofile_batch_embedded3 = tf.nn.embedding_lookup(self.uprofile_embeddings_var3, self.uprofile_batch_ph3)
            self.uprofile_embeddings_var4 = tf.get_variable("uprofile_embedding_var4", [n_feature[3], 2])
            self.uprofile_batch_embedded4 = tf.nn.embedding_lookup(self.uprofile_embeddings_var4, self.uprofile_batch_ph4)
            self.uprofile_embeddings_var5 = tf.get_variable("uprofile_embedding_var5", [n_feature[4], 2])
            self.uprofile_batch_embedded5 = tf.nn.embedding_lookup(self.uprofile_embeddings_var5, self.uprofile_batch_ph5)
            self.uprofile_embeddings_var6 = tf.get_variable("uprofile_embedding_var6", [n_feature[5], 2])
            self.uprofile_batch_embedded6 = tf.nn.embedding_lookup(self.uprofile_embeddings_var6, self.uprofile_batch_ph6)
            self.uprofile_embeddings_var7 = tf.get_variable("uprofile_embedding_var7", [n_feature[6], 2])
            self.uprofile_batch_embedded7 = tf.nn.embedding_lookup(self.uprofile_embeddings_var7, self.uprofile_batch_ph7)
            self.uprofile_embeddings_var8 = tf.get_variable("uprofile_embedding_var8", [n_feature[7], 2])
            self.uprofile_batch_embedded8 = tf.nn.embedding_lookup(self.uprofile_embeddings_var8, self.uprofile_batch_ph8)

        self.uprofile_eb = tf.concat([self.uprofile_batch_embedded1, self.uprofile_batch_embedded2,
                                      self.uprofile_batch_embedded3, self.uprofile_batch_embedded4,
                                      self.uprofile_batch_embedded5, self.uprofile_batch_embedded6,
                                      self.uprofile_batch_embedded7, self.uprofile_batch_embedded8,], 1)

        self.mid_batch_popular = tf.random_uniform(tf.shape(self.mid_batch_ph), minval=1,maxval=101,dtype=tf.int32)
        self.mid_batch_embedded_popular = tf.nn.embedding_lookup(self.mid_embeddings_var, self.mid_batch_popular)
        self.cat_batch_popular = tf.random_uniform(tf.shape(self.cat_batch_ph), minval=1,maxval=2,dtype=tf.int32)
        self.cat_batch_embedded_popular = tf.nn.embedding_lookup(self.cat_embeddings_var, self.cat_batch_popular)
        self.item_eb_popular = tf.concat([self.mid_batch_embedded_popular, self.cat_batch_embedded_popular], 1)

        self.item_eb = tf.concat([self.mid_batch_embedded, self.cat_batch_embedded], 1)
        self.item_his_eb = tf.concat([self.mid_his_batch_embedded, self.cat_his_batch_embedded], 2)
        self.item_his_eb_sum = tf.reduce_sum(self.item_his_eb, 1)
        if self.use_negsampling:
            self.noclk_item_his_eb = tf.concat([self.noclk_mid_his_batch_embedded[:, :, 0, :], self.noclk_cat_his_batch_embedded[:, :, 0, :]], -1)
            self.noclk_item_his_eb = tf.reshape(self.noclk_item_his_eb, [-1, tf.shape(self.noclk_mid_his_batch_embedded)[1], 20])
            self.noclk_his_eb = tf.concat([self.noclk_mid_his_batch_embedded, self.noclk_cat_his_batch_embedded], -1)
            self.noclk_his_eb_sum_1 = tf.reduce_sum(self.noclk_his_eb, 2)
            self.noclk_his_eb_sum = tf.reduce_sum(self.noclk_his_eb_sum_1, 1)
        self.eb_params = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope='Embedding_layer')



    def build_fcn_net_pur(self, inp, use_dice = False):
        with tf.variable_scope('fcn_layer', reuse=tf.AUTO_REUSE):
            bn1 = tf.layers.batch_normalization(inputs=inp, name='bn1')
            dnn1 = tf.layers.dense(bn1, 200, activation=None, name='f1')
            if use_dice:
                dnn1 = dice(dnn1, name='dice_1')
            else:
                dnn1 = prelu(dnn1, 'prelu1')

            dnn2 = tf.layers.dense(dnn1, 80, activation=None, name='f2')
            if use_dice:
                dnn2 = dice(dnn2, name='dice_2')
            else:
                dnn2 = prelu(dnn2, 'prelu2')
            dnn3 = tf.layers.dense(dnn2, 2, activation=None, name='f3')
            fcn_output = tf.nn.softmax(dnn3) + 0.00000001

        self.fcn_params = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope='fcn_layer')


        return fcn_output

    def build_generator_net(self, inp, EMBEDDING_DIM, use_dice = False):

        with tf.variable_scope('Generator_layer'):
            gen_size = 64
            gen_noise = tf.random_normal(tf.shape(inp), mean=0.0, stddev=1.0, dtype=tf.float32)
            gen_inp = tf.multiply(inp, gen_noise)
            gen_bn1 = tf.layers.batch_normalization(inputs=gen_inp, name='gen_bn1')
            gen_dnn1 = tf.layers.dense(gen_bn1, 128, activation=None, kernel_regularizer=tf.keras.regularizers.l1_l2(l1=0.01, l2=0.01), bias_regularizer=tf.keras.regularizers.l2(l=0.01), name='gen_f1')
            gen_dnn1 = prelu(gen_dnn1, 'gen_prelu1')
            gen_dnn2 = tf.layers.dense(gen_dnn1, 64, activation=None, kernel_regularizer=tf.keras.regularizers.l1_l2(l1=0.01, l2=0.01), bias_regularizer=tf.keras.regularizers.l2(l=0.01), name='gen_f2')
            gen_dnn2 = prelu(gen_dnn2, 'gen_prelu2')
            gen_dnn3 = tf.layers.dense(gen_dnn2, 32, activation=None, kernel_regularizer=tf.keras.regularizers.l1_l2(l1=0.01, l2=0.01), bias_regularizer=tf.keras.regularizers.l2(l=0.01), name='gen_f3')
            gen_dnn3 = prelu(gen_dnn3, 'gen_prelu3')
            gen_dnn4 = tf.layers.dense(gen_dnn3, 20 * gen_size, activation = "tanh", kernel_regularizer=tf.keras.regularizers.l1_l2(l1=0.01, l2=0.01), bias_regularizer=tf.keras.regularizers.l2(l=0.01), name='gen_f4')

            self.item_his_eb_gen = gen_dnn4
            self.item_his_eb_gen = tf.reshape(self.item_his_eb_gen,
                                              [tf.shape(self.item_his_eb_gen)[0], -1, 20])

        self.gen_params = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope='Generator_layer')


    def build_discriminator_net(self, inp, dis_condition, use_dice = False):
        with tf.variable_scope('Discriminator_layer', reuse=tf.AUTO_REUSE):
            dis_c = dis_condition
            dis_inp = tf.concat([dis_c, inp], 1)
            bn1 = tf.layers.batch_normalization(inputs=dis_inp, name='dis_bn1')
            dnn1 = tf.layers.dense(bn1, 128, activation=None, kernel_regularizer=tf.keras.regularizers.l1_l2(l1=0.01, l2=0.01), bias_regularizer=tf.keras.regularizers.l2(l=0.01), name='dis_f1')
            if use_dice:
                dnn1 = dice(dnn1, name='dis_dice_1')
            else:
                dnn1 = prelu(dnn1, 'dis_prelu1')
            dnn1 = tf.layers.dropout(dnn1,0.4)
            dnn2 = tf.layers.dense(dnn1, 64, activation=None, kernel_regularizer=tf.keras.regularizers.l1_l2(l1=0.01, l2=0.01), bias_regularizer=tf.keras.regularizers.l2(l=0.01), name='dis_f2')
            if use_dice:
                dnn2 = dice(dnn2, name='dis_dice_2')
            else:
                dnn2 = prelu(dnn2, 'dis_prelu2')
            dnn2 = tf.layers.dropout(dnn2,0.4)
            dnn3 = tf.layers.dense(dnn2, 32, activation=None, kernel_regularizer=tf.keras.regularizers.l1_l2(l1=0.01, l2=0.01), bias_regularizer=tf.keras.regularizers.l2(l=0.01), name='dis_f3')
            if use_dice:
                dnn3 = dice(dnn3, name='dis_dice_3')
            else:
                dnn3 = prelu(dnn3, 'dis_prelu3')
            dnn3 = tf.layers.dropout(dnn3,0.4)
            dnn4 = tf.layers.dense(dnn3, 1, activation=tf.nn.sigmoid, name='dis_f4')

        self.dis_params = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope='Discriminator_layer')
        return dnn4


    def build_loss_gen(self):

        with tf.name_scope('Metrics'):
            # Cross-entropy loss and optimizer initialization
            #phase 1
            weight = tf.reduce_sum(self.target_ph[:,0]) / tf.cast(tf.shape(self.target_ph)[0], tf.float32)
            self.loss = - tf.reduce_mean(tf.log(self.y_hat) * self.target_ph * [1-weight, weight])
            self.loss += self.aux_loss
            self.optimizer = tf.train.AdamOptimizer(learning_rate=self.lr).minimize(self.loss)
            self.accuracy = tf.reduce_mean(tf.cast(tf.equal(tf.round(self.y_hat), self.target_ph), tf.float32))
            tf.summary.scalar('loss', self.loss)
            tf.summary.scalar('accuracy', self.accuracy)

            #phase 2
            valid = tf.ones([tf.shape(self.uid_batch_embedded)[0], 1],tf.float32)
            fake = tf.zeros([tf.shape(self.uid_batch_embedded)[0], 1],tf.float32)
            self.dis_loss_real = tf.nn.sigmoid_cross_entropy_with_logits(labels=valid, logits=self.validity)
            self.dis_loss_fake = tf.nn.sigmoid_cross_entropy_with_logits(labels=fake, logits=self.validity_gen)
            self.dis_loss_G = tf.nn.sigmoid_cross_entropy_with_logits(labels=valid, logits=self.validity_gen)
            self.optimizerD_real = tf.train.AdamOptimizer(learning_rate=self.lr).minimize(self.dis_loss_real, var_list = self.dis_params)
            self.optimizerD_fake = tf.train.AdamOptimizer(learning_rate=self.lr).minimize(self.dis_loss_fake, var_list = self.dis_params)
            self.optimizerG = tf.train.AdamOptimizer(learning_rate=self.lr).minimize(self.dis_loss_G, var_list = self.gen_params)

            # Accuracy metric
            self.accuracy_D_real = tf.reduce_mean(tf.cast(tf.equal(tf.round(self.validity), valid), tf.float32))
            self.accuracy_D_fake = tf.reduce_mean(tf.cast(tf.equal(tf.round(self.validity_gen), fake), tf.float32))
            self.accuracy_G = tf.reduce_mean(tf.cast(tf.equal(tf.round(self.validity_gen), valid), tf.float32))

            tf.summary.scalar('dis_loss_real', self.dis_loss_real)
            tf.summary.scalar('dis_loss_fake', self.dis_loss_fake)
            tf.summary.scalar('dis_loss_G', self.dis_loss_G)
            tf.summary.scalar('accuracy_D_real', self.accuracy_D_real)
            tf.summary.scalar('accuracy_D_fake', self.accuracy_D_fake)
            tf.summary.scalar('accuracy_G', self.accuracy_G)

            #phase 3
            self.loss_G = - tf.reduce_mean(tf.log(self.y_hat_gen) * (self.target_ph) * [1-weight, weight])
            self.loss_G += self.aux_loss_gen
            self.optimizer_G = tf.train.AdamOptimizer(learning_rate=self.lr).minimize(self.loss_G,  var_list = self.gen_params)
            self.accuracy_Gen = tf.reduce_mean(tf.cast(tf.equal(tf.round(self.y_hat_gen), self.target_ph), tf.float32))
            tf.summary.scalar('loss_G', self.loss_G)
            tf.summary.scalar('accuracy_Gen', self.accuracy_Gen)

        self.merged = tf.summary.merge_all()



    def auxiliary_loss(self, h_states, click_seq, noclick_seq, mask, stag = None):
        mask = tf.cast(mask, tf.float32)
        click_input_ = tf.concat([h_states, click_seq], -1)
        noclick_input_ = tf.concat([h_states, noclick_seq], -1)
        click_prop_ = self.auxiliary_net(click_input_, stag = stag)[:, :, 0]
        click_loss_ = tf.cond(tf.shape(click_seq)[1] < 1, lambda: tf.zeros_like(mask), lambda: - tf.reshape(tf.log(click_prop_), [-1, tf.shape(click_seq)[1]]) * mask)
        noclick_loss_ = tf.cond(tf.shape(noclick_seq)[1] < 1, lambda: tf.zeros_like(mask), lambda: - tf.reshape(tf.log(1.0 - self.auxiliary_net(noclick_input_, stag = stag)[:, :, 0] + 0.00000002), [-1, tf.shape(noclick_seq)[1]]) * mask)
        loss_ = tf.reduce_mean(click_loss_ + noclick_loss_)
        return loss_

    def auxiliary_net(self, in_, stag='auxiliary_net'):
        bn1 = tf.layers.batch_normalization(inputs=in_, name='bn1' + stag, reuse=tf.AUTO_REUSE)
        dnn1 = tf.layers.dense(bn1, 100, activation=None, name='f1' + stag, reuse=tf.AUTO_REUSE)
        dnn1 = tf.nn.sigmoid(dnn1)
        dnn2 = tf.layers.dense(dnn1, 50, activation=None, name='f2' + stag, reuse=tf.AUTO_REUSE)
        dnn2 = tf.nn.sigmoid(dnn2)
        dnn3 = tf.layers.dense(dnn2, 2, activation=None, name='f3' + stag, reuse=tf.AUTO_REUSE)
        y_hat = tf.nn.softmax(dnn3) + 0.00000001
        return y_hat



    def train(self, sess, inps):
        if self.use_negsampling:
            if inps[-1] == 1:
                loss, accuracy, aux_loss, _ = sess.run([self.loss, self.accuracy, self.aux_loss, self.optimizer], feed_dict={
                    self.uid_batch_ph: inps[0],
                    self.mid_batch_ph: inps[1],
                    self.cat_batch_ph: inps[2],
                    self.mid_his_batch_ph: inps[3],
                    self.cat_his_batch_ph: inps[4],
                    self.mask: inps[5],
                    self.target_ph: inps[6],
                    self.seq_len_ph: inps[7],
                    self.lr: inps[8],
                    self.noclk_mid_batch_ph: inps[10],
                    self.noclk_cat_batch_ph: inps[11],
                    self.uprofile_batch_ph1: inps[9][:,1],
                    self.uprofile_batch_ph2: inps[9][:,2],
                    self.uprofile_batch_ph3: inps[9][:,3],
                    self.uprofile_batch_ph4: inps[9][:,4],
                    self.uprofile_batch_ph5: inps[9][:,5],
                    self.uprofile_batch_ph6: inps[9][:,6],
                    self.uprofile_batch_ph7: inps[9][:,7],
                    self.uprofile_batch_ph8: inps[9][:,8],
                })
                return loss, accuracy, aux_loss

            elif inps[-1] == 2:
                dis_loss_real, accuracy_D_real, _ = sess.run([self.dis_loss_real, self.accuracy_D_real, self.optimizerD_real], feed_dict={
                    self.uid_batch_ph: inps[0],
                    self.mid_batch_ph: inps[1],
                    self.cat_batch_ph: inps[2],
                    self.mid_his_batch_ph: inps[3],
                    self.cat_his_batch_ph: inps[4],
                    self.mask: inps[5],
                    self.target_ph: inps[6],
                    self.seq_len_ph: inps[7],
                    self.lr: inps[8],
                    self.uprofile_batch_ph1: inps[9][:,1],
                    self.uprofile_batch_ph2: inps[9][:,2],
                    self.uprofile_batch_ph3: inps[9][:,3],
                    self.uprofile_batch_ph4: inps[9][:,4],
                    self.uprofile_batch_ph5: inps[9][:,5],
                    self.uprofile_batch_ph6: inps[9][:,6],
                    self.uprofile_batch_ph7: inps[9][:,7],
                    self.uprofile_batch_ph8: inps[9][:,8],
                })

                dis_loss_fake, accuracy_D_fake, _ = sess.run([self.dis_loss_fake, self.accuracy_D_fake, self.optimizerD_fake], feed_dict={
                    self.uid_batch_ph: inps[0],
                    self.mid_batch_ph: inps[1],
                    self.cat_batch_ph: inps[2],
                    self.mid_his_batch_ph: inps[3],
                    self.cat_his_batch_ph: inps[4],
                    self.mask: inps[5],
                    self.target_ph: inps[6],
                    self.seq_len_ph: inps[7],
                    self.lr: inps[8],
                    self.uprofile_batch_ph1: inps[9][:,1],
                    self.uprofile_batch_ph2: inps[9][:,2],
                    self.uprofile_batch_ph3: inps[9][:,3],
                    self.uprofile_batch_ph4: inps[9][:,4],
                    self.uprofile_batch_ph5: inps[9][:,5],
                    self.uprofile_batch_ph6: inps[9][:,6],
                    self.uprofile_batch_ph7: inps[9][:,7],
                    self.uprofile_batch_ph8: inps[9][:,8],
                })

                dis_loss_G, accuracy_G, _ = sess.run([self.dis_loss_G, self.accuracy_G, self.optimizerG], feed_dict={
                    self.uid_batch_ph: inps[0],
                    self.mid_batch_ph: inps[1],
                    self.cat_batch_ph: inps[2],
                    self.mid_his_batch_ph: inps[3],
                    self.cat_his_batch_ph: inps[4],
                    self.mask: inps[5],
                    self.target_ph: inps[6],
                    self.seq_len_ph: inps[7],
                    self.lr: inps[8],
                    self.uprofile_batch_ph1: inps[9][:,1],
                    self.uprofile_batch_ph2: inps[9][:,2],
                    self.uprofile_batch_ph3: inps[9][:,3],
                    self.uprofile_batch_ph4: inps[9][:,4],
                    self.uprofile_batch_ph5: inps[9][:,5],
                    self.uprofile_batch_ph6: inps[9][:,6],
                    self.uprofile_batch_ph7: inps[9][:,7],
                    self.uprofile_batch_ph8: inps[9][:,8],
                })
                return (dis_loss_real+dis_loss_fake)/2, (accuracy_D_real+accuracy_D_fake)/2, dis_loss_G, accuracy_G

            elif inps[-1] == 3:

                loss_gen, accuracy_gen, aux_loss_gen, _ = sess.run([self.loss_G, self.accuracy_Gen, self.aux_loss_gen, self.optimizer_G], feed_dict={
                    self.uid_batch_ph: inps[0],
                    self.mid_batch_ph: inps[1],
                    self.cat_batch_ph: inps[2],
                    self.mid_his_batch_ph: inps[3],
                    self.cat_his_batch_ph: inps[4],
                    self.mask: inps[5],
                    self.target_ph: inps[6],
                    self.seq_len_ph: inps[7],
                    self.lr: inps[8],
                    self.noclk_mid_batch_ph: inps[10],
                    self.noclk_cat_batch_ph: inps[11],
                    self.uprofile_batch_ph1: inps[9][:,1],
                    self.uprofile_batch_ph2: inps[9][:,2],
                    self.uprofile_batch_ph3: inps[9][:,3],
                    self.uprofile_batch_ph4: inps[9][:,4],
                    self.uprofile_batch_ph5: inps[9][:,5],
                    self.uprofile_batch_ph6: inps[9][:,6],
                    self.uprofile_batch_ph7: inps[9][:,7],
                    self.uprofile_batch_ph8: inps[9][:,8],
                })

                return loss_gen, accuracy_gen, aux_loss_gen
                # return loss, accuracy, loss_gen, accuracy_gen, 0
        else:
            if inps[-1] == 1:
                loss, accuracy, _ = sess.run([self.loss, self.accuracy, self.optimizer], feed_dict={
                    self.uid_batch_ph: inps[0],
                    self.mid_batch_ph: inps[1],
                    self.cat_batch_ph: inps[2],
                    self.mid_his_batch_ph: inps[3],
                    self.cat_his_batch_ph: inps[4],
                    self.mask: inps[5],
                    self.target_ph: inps[6],
                    self.seq_len_ph: inps[7],
                    self.lr: inps[8],
                    self.noclk_mid_batch_ph: inps[10],
                    self.noclk_cat_batch_ph: inps[11],
                    self.uprofile_batch_ph1: inps[9][:,1],
                    self.uprofile_batch_ph2: inps[9][:,2],
                    self.uprofile_batch_ph3: inps[9][:,3],
                    self.uprofile_batch_ph4: inps[9][:,4],
                    self.uprofile_batch_ph5: inps[9][:,5],
                    self.uprofile_batch_ph6: inps[9][:,6],
                    self.uprofile_batch_ph7: inps[9][:,7],
                    self.uprofile_batch_ph8: inps[9][:,8],
                })
                return loss, accuracy, 0

            elif inps[-1] == 2:
                dis_loss_real, accuracy_D_real, _ = sess.run([self.dis_loss_real, self.accuracy_D_real, self.optimizerD_real], feed_dict={
                    self.uid_batch_ph: inps[0],
                    self.mid_batch_ph: inps[1],
                    self.cat_batch_ph: inps[2],
                    self.mid_his_batch_ph: inps[3],
                    self.cat_his_batch_ph: inps[4],
                    self.mask: inps[5],
                    self.target_ph: inps[6],
                    self.seq_len_ph: inps[7],
                    self.lr: inps[8],
                    self.uprofile_batch_ph1: inps[9][:,1],
                    self.uprofile_batch_ph2: inps[9][:,2],
                    self.uprofile_batch_ph3: inps[9][:,3],
                    self.uprofile_batch_ph4: inps[9][:,4],
                    self.uprofile_batch_ph5: inps[9][:,5],
                    self.uprofile_batch_ph6: inps[9][:,6],
                    self.uprofile_batch_ph7: inps[9][:,7],
                    self.uprofile_batch_ph8: inps[9][:,8],
                })

                dis_loss_fake, accuracy_D_fake, _ = sess.run([self.dis_loss_fake, self.accuracy_D_fake, self.optimizerD_fake], feed_dict={
                    self.uid_batch_ph: inps[0],
                    self.mid_batch_ph: inps[1],
                    self.cat_batch_ph: inps[2],
                    self.mid_his_batch_ph: inps[3],
                    self.cat_his_batch_ph: inps[4],
                    self.mask: inps[5],
                    self.target_ph: inps[6],
                    self.seq_len_ph: inps[7],
                    self.lr: inps[8],
                    self.uprofile_batch_ph1: inps[9][:,1],
                    self.uprofile_batch_ph2: inps[9][:,2],
                    self.uprofile_batch_ph3: inps[9][:,3],
                    self.uprofile_batch_ph4: inps[9][:,4],
                    self.uprofile_batch_ph5: inps[9][:,5],
                    self.uprofile_batch_ph6: inps[9][:,6],
                    self.uprofile_batch_ph7: inps[9][:,7],
                    self.uprofile_batch_ph8: inps[9][:,8],
                })

                dis_loss_G, accuracy_G, _ = sess.run([self.dis_loss_G, self.accuracy_G, self.optimizerG], feed_dict={
                    self.uid_batch_ph: inps[0],
                    self.mid_batch_ph: inps[1],
                    self.cat_batch_ph: inps[2],
                    self.mid_his_batch_ph: inps[3],
                    self.cat_his_batch_ph: inps[4],
                    self.mask: inps[5],
                    self.target_ph: inps[6],
                    self.seq_len_ph: inps[7],
                    self.lr: inps[8],
                    self.uprofile_batch_ph1: inps[9][:,1],
                    self.uprofile_batch_ph2: inps[9][:,2],
                    self.uprofile_batch_ph3: inps[9][:,3],
                    self.uprofile_batch_ph4: inps[9][:,4],
                    self.uprofile_batch_ph5: inps[9][:,5],
                    self.uprofile_batch_ph6: inps[9][:,6],
                    self.uprofile_batch_ph7: inps[9][:,7],
                    self.uprofile_batch_ph8: inps[9][:,8],
                })
                return (dis_loss_real+dis_loss_fake)/2, (accuracy_D_real+accuracy_D_fake)/2, dis_loss_G, accuracy_G

            elif inps[-1] == 3:

                loss_gen, accuracy_gen, _ = sess.run([self.loss_G, self.accuracy_Gen, self.optimizer_G], feed_dict={
                    self.uid_batch_ph: inps[0],
                    self.mid_batch_ph: inps[1],
                    self.cat_batch_ph: inps[2],
                    self.mid_his_batch_ph: inps[3],
                    self.cat_his_batch_ph: inps[4],
                    self.mask: inps[5],
                    self.target_ph: inps[6],
                    self.seq_len_ph: inps[7],
                    self.lr: inps[8],
                    self.noclk_mid_batch_ph: inps[10],
                    self.noclk_cat_batch_ph: inps[11],
                    self.uprofile_batch_ph1: inps[9][:,1],
                    self.uprofile_batch_ph2: inps[9][:,2],
                    self.uprofile_batch_ph3: inps[9][:,3],
                    self.uprofile_batch_ph4: inps[9][:,4],
                    self.uprofile_batch_ph5: inps[9][:,5],
                    self.uprofile_batch_ph6: inps[9][:,6],
                    self.uprofile_batch_ph7: inps[9][:,7],
                    self.uprofile_batch_ph8: inps[9][:,8],
                })

                return loss_gen, accuracy_gen, 0


    def calculate(self, sess, inps):
        if self.use_negsampling:
            if inps[-1] == 1:

                probs, loss, accuracy, aux_loss = sess.run([self.y_hat, self.loss, self.accuracy, self.aux_loss], feed_dict={
                    self.uid_batch_ph: inps[0],
                    self.mid_batch_ph: inps[1],
                    self.cat_batch_ph: inps[2],
                    self.mid_his_batch_ph: inps[3],
                    self.cat_his_batch_ph: inps[4],
                    self.mask: inps[5],
                    self.target_ph: inps[6],
                    self.seq_len_ph: inps[7],
                    self.noclk_mid_batch_ph: inps[10],
                    self.noclk_cat_batch_ph: inps[11],
                    self.uprofile_batch_ph1: inps[9][:,1],
                    self.uprofile_batch_ph2: inps[9][:,2],
                    self.uprofile_batch_ph3: inps[9][:,3],
                    self.uprofile_batch_ph4: inps[9][:,4],
                    self.uprofile_batch_ph5: inps[9][:,5],
                    self.uprofile_batch_ph6: inps[9][:,6],
                    self.uprofile_batch_ph7: inps[9][:,7],
                    self.uprofile_batch_ph8: inps[9][:,8],
                })
                return probs, loss, accuracy, aux_loss
            elif inps[-1] == 3:
                probs, loss, accuracy, aux_loss = sess.run([self.y_hat, self.loss, self.accuracy, self.aux_loss], feed_dict={
                    self.uid_batch_ph: inps[0],
                    self.mid_batch_ph: inps[1],
                    self.cat_batch_ph: inps[2],
                    self.mid_his_batch_ph: inps[3],
                    self.cat_his_batch_ph: inps[4],
                    self.mask: inps[5],
                    self.target_ph: inps[6],
                    self.seq_len_ph: inps[7],
                    self.noclk_mid_batch_ph: inps[10],
                    self.noclk_cat_batch_ph: inps[11],
                    self.uprofile_batch_ph1: inps[9][:,1],
                    self.uprofile_batch_ph2: inps[9][:,2],
                    self.uprofile_batch_ph3: inps[9][:,3],
                    self.uprofile_batch_ph4: inps[9][:,4],
                    self.uprofile_batch_ph5: inps[9][:,5],
                    self.uprofile_batch_ph6: inps[9][:,6],
                    self.uprofile_batch_ph7: inps[9][:,7],
                    self.uprofile_batch_ph8: inps[9][:,8],
                })
                probs_gen, loss_gen, accuracy_gen, aux_loss_gen = sess.run([self.y_hat_gen, self.loss_G, self.accuracy_Gen, self.aux_loss_gen], feed_dict={
                    self.uid_batch_ph: inps[0],
                    self.mid_batch_ph: inps[1],
                    self.cat_batch_ph: inps[2],
                    self.mid_his_batch_ph: inps[3],
                    self.cat_his_batch_ph: inps[4],
                    self.mask: inps[5],
                    self.target_ph: inps[6],
                    self.seq_len_ph: inps[7],
                    self.noclk_mid_batch_ph: inps[10],
                    self.noclk_cat_batch_ph: inps[11],
                    self.uprofile_batch_ph1: inps[9][:,1],
                    self.uprofile_batch_ph2: inps[9][:,2],
                    self.uprofile_batch_ph3: inps[9][:,3],
                    self.uprofile_batch_ph4: inps[9][:,4],
                    self.uprofile_batch_ph5: inps[9][:,5],
                    self.uprofile_batch_ph6: inps[9][:,6],
                    self.uprofile_batch_ph7: inps[9][:,7],
                    self.uprofile_batch_ph8: inps[9][:,8],
                })

                return probs, loss, accuracy, aux_loss, probs_gen, loss_gen, accuracy_gen, aux_loss_gen
            else:
                print ("Invalid calculate ")
                return
        else:
            if inps[-1] == 1:

                probs, loss, accuracy = sess.run([self.y_hat, self.loss, self.accuracy], feed_dict={
                    self.uid_batch_ph: inps[0],
                    self.mid_batch_ph: inps[1],
                    self.cat_batch_ph: inps[2],
                    self.mid_his_batch_ph: inps[3],
                    self.cat_his_batch_ph: inps[4],
                    self.mask: inps[5],
                    self.target_ph: inps[6],
                    self.seq_len_ph: inps[7],
                    self.noclk_mid_batch_ph: inps[10],
                    self.noclk_cat_batch_ph: inps[11],
                    self.uprofile_batch_ph1: inps[9][:,1],
                    self.uprofile_batch_ph2: inps[9][:,2],
                    self.uprofile_batch_ph3: inps[9][:,3],
                    self.uprofile_batch_ph4: inps[9][:,4],
                    self.uprofile_batch_ph5: inps[9][:,5],
                    self.uprofile_batch_ph6: inps[9][:,6],
                    self.uprofile_batch_ph7: inps[9][:,7],
                    self.uprofile_batch_ph8: inps[9][:,8],
                })
                return probs, loss, accuracy, 0
            elif inps[-1] == 3:
                probs, loss, accuracy = sess.run([self.y_hat, self.loss, self.accuracy], feed_dict={
                    self.uid_batch_ph: inps[0],
                    self.mid_batch_ph: inps[1],
                    self.cat_batch_ph: inps[2],
                    self.mid_his_batch_ph: inps[3],
                    self.cat_his_batch_ph: inps[4],
                    self.mask: inps[5],
                    self.target_ph: inps[6],
                    self.seq_len_ph: inps[7],
                    self.noclk_mid_batch_ph: inps[10],
                    self.noclk_cat_batch_ph: inps[11],
                    self.uprofile_batch_ph1: inps[9][:,1],
                    self.uprofile_batch_ph2: inps[9][:,2],
                    self.uprofile_batch_ph3: inps[9][:,3],
                    self.uprofile_batch_ph4: inps[9][:,4],
                    self.uprofile_batch_ph5: inps[9][:,5],
                    self.uprofile_batch_ph6: inps[9][:,6],
                    self.uprofile_batch_ph7: inps[9][:,7],
                    self.uprofile_batch_ph8: inps[9][:,8],
                })
                probs_gen, loss_gen, accuracy_gen = sess.run([self.y_hat_gen, self.loss_G, self.accuracy_Gen], feed_dict={
                    self.uid_batch_ph: inps[0],
                    self.mid_batch_ph: inps[1],
                    self.cat_batch_ph: inps[2],
                    self.mid_his_batch_ph: inps[3],
                    self.cat_his_batch_ph: inps[4],
                    self.mask: inps[5],
                    self.target_ph: inps[6],
                    self.seq_len_ph: inps[7],
                    self.noclk_mid_batch_ph: inps[10],
                    self.noclk_cat_batch_ph: inps[11],
                    self.uprofile_batch_ph1: inps[9][:,1],
                    self.uprofile_batch_ph2: inps[9][:,2],
                    self.uprofile_batch_ph3: inps[9][:,3],
                    self.uprofile_batch_ph4: inps[9][:,4],
                    self.uprofile_batch_ph5: inps[9][:,5],
                    self.uprofile_batch_ph6: inps[9][:,6],
                    self.uprofile_batch_ph7: inps[9][:,7],
                    self.uprofile_batch_ph8: inps[9][:,8],
                })

                return probs, loss, accuracy, 0, probs_gen, loss_gen, accuracy_gen, 0

            else:
                print ("Invalid calculate ")
                return

    def save(self, sess, path):
        saver = tf.train.Saver()
        saver.save(sess, save_path=path)

    def restore(self, sess, path):
        saver = tf.train.Saver()
        saver.restore(sess, save_path=path)
        print('model restored from %s' % path)


class Model_DNN_Gen(Model):
    def __init__(self, n_uid, n_mid, n_cat, n_feature, EMBEDDING_DIM, HIDDEN_SIZE, ATTENTION_SIZE, use_negsampling=True):
        super(Model_DNN_Gen, self).__init__(n_uid, n_mid, n_cat, n_feature, EMBEDDING_DIM, HIDDEN_SIZE,
                                                          ATTENTION_SIZE,
                                                          use_negsampling)
        # phase 1
        inp = tf.concat([self.uid_batch_embedded, self.uprofile_eb, self.item_eb, self.item_his_eb_sum], 1)
        self.y_hat = self.build_fcn_net_pur(inp, use_dice=False)
        inp_gen_need = tf.concat([self.uid_batch_embedded, self.uprofile_eb, tf.where(tf.equal(self.seq_len_ph, 0), self.item_eb, tf.reduce_mean(self.item_his_eb, 1))], 1)
        self.build_generator_net(inp_gen_need, EMBEDDING_DIM, use_dice=False)
        self.aux_loss = tf.cast(0, tf.float32)
        self.aux_loss_gen = tf.cast(0, tf.float32)
        
        # phase 2
        dis_condition = inp_gen_need
        inp_dis = tf.reduce_mean(self.item_his_eb, 1)
        self.validity = self.build_discriminator_net(inp_dis, dis_condition, use_dice=False)
        inp_dis_gen = tf.reduce_mean(self.item_his_eb_gen, 1)
        self.validity_gen = self.build_discriminator_net(inp_dis_gen, dis_condition, use_dice=False)

        # phase 3
        self.item_his_eb_gen_sum = tf.where(tf.equal(self.seq_len_ph, 0), tf.reduce_sum(tf.concat([self.item_his_eb_gen, self.item_his_eb], 1), 1), tf.reduce_sum(self.item_his_eb, 1))
        inp_gen = tf.concat([self.uid_batch_embedded, self.uprofile_eb, self.item_eb, self.item_his_eb_gen_sum], 1)
        self.y_hat_gen = self.build_fcn_net_pur(inp_gen, use_dice=False)

        self.build_loss_gen()

class Model_DIN_Gen(Model):
    def __init__(self, n_uid, n_mid, n_cat, n_feature, EMBEDDING_DIM, HIDDEN_SIZE, ATTENTION_SIZE, use_negsampling=True):
        super(Model_DIN_Gen, self).__init__(n_uid, n_mid, n_cat, n_feature, EMBEDDING_DIM, HIDDEN_SIZE,
                                           ATTENTION_SIZE,
                                           use_negsampling)
        gen_size = 64
        inp_gen_need = tf.concat([self.uid_batch_embedded, self.uprofile_eb, tf.where(tf.equal(self.seq_len_ph, 0), self.item_eb, tf.reduce_mean(self.item_his_eb, 1))], 1)
        self.build_generator_net(inp_gen_need, EMBEDDING_DIM, use_dice=False)
        self.mask_gen = tf.concat([tf.ones([tf.shape(self.mask)[0], gen_size]), self.mask[:,:]], 1)
        # phase 1
        # Attention layer
        with tf.variable_scope('Attention_layer', reuse=tf.AUTO_REUSE):
            attention_output = din_attention(self.item_eb, self.item_his_eb, ATTENTION_SIZE, self.mask)
            att_fea = tf.reduce_sum(attention_output, 1)
            tf.summary.histogram('att_fea', att_fea)

            attention_output_gen = din_attention(self.item_eb, tf.concat([self.item_his_eb_gen, self.item_his_eb], 1), ATTENTION_SIZE, self.mask_gen)
            att_fea_gen = tf.reduce_sum(attention_output_gen, 1)
            tf.summary.histogram('att_fea_gen', att_fea_gen)
        self.att_params = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope='Attention_layer')

        self.aux_loss = tf.cast(0, tf.float32)
        self.aux_loss_gen = tf.cast(0, tf.float32)

        # phase 2
        dis_condition = inp_gen_need
        inp_dis = tf.reduce_mean(self.item_his_eb, 1)
        self.validity = self.build_discriminator_net(inp_dis, dis_condition, use_dice=False)
        inp_dis_gen = tf.reduce_mean(self.item_his_eb_gen, 1)
        self.validity_gen = self.build_discriminator_net(inp_dis_gen, dis_condition, use_dice=False)

        # phase 3
        inp = tf.concat([self.uid_batch_embedded, self.uprofile_eb, self.item_eb, self.item_his_eb_sum, self.item_eb * self.item_his_eb_sum, att_fea], 1)
        self.y_hat = self.build_fcn_net_pur(inp, use_dice=False)
        self.item_his_eb_gen_sum = tf.where(tf.equal(self.seq_len_ph, 0), tf.reduce_sum(tf.concat([self.item_his_eb_gen, self.item_his_eb], 1), 1), tf.reduce_sum(self.item_his_eb, 1))

        final_att_fea = tf.where(tf.equal(self.seq_len_ph, 0), att_fea_gen, att_fea)
        inp_gen = tf.concat([self.uid_batch_embedded, self.uprofile_eb, self.item_eb, self.item_his_eb_gen_sum, self.item_eb * self.item_his_eb_gen_sum, final_att_fea], 1)
        self.y_hat_gen = self.build_fcn_net_pur(inp_gen, use_dice=False)

        self.build_loss_gen()

class Model_DIEN_Gen(Model):
    def __init__(self, n_uid, n_mid, n_cat, n_feature,EMBEDDING_DIM, HIDDEN_SIZE, ATTENTION_SIZE, use_negsampling=True):
        super(Model_DIEN_Gen, self).__init__(n_uid, n_mid, n_cat, n_feature,
                                                          EMBEDDING_DIM, HIDDEN_SIZE, ATTENTION_SIZE,
                                                          use_negsampling)
        gen_size = 64
        inp_gen_need = tf.concat([self.uid_batch_embedded, self.uprofile_eb, tf.where(tf.equal(self.seq_len_ph, 0), self.item_eb, tf.reduce_mean(self.item_his_eb, 1))], 1)
        self.build_generator_net(inp_gen_need, EMBEDDING_DIM, use_dice=False)
        self.mask_gen = tf.concat([tf.ones([tf.shape(self.mask)[0], gen_size]), self.mask[:,:]], 1)
        self.seq_len_ph_gen = gen_size * tf.ones_like(self.seq_len_ph) + self.seq_len_ph
        # RNN layer(-s)
        with tf.variable_scope('rnn_1', reuse=tf.AUTO_REUSE):
            rnn_outputs, _ = dynamic_rnn(GRUCell(HIDDEN_SIZE), inputs=self.item_his_eb,
                                         sequence_length=self.seq_len_ph, dtype=tf.float32,
                                         scope="gru1")
            tf.summary.histogram('GRU_outputs', rnn_outputs)

            rnn_outputs_gen, _ = dynamic_rnn(GRUCell(HIDDEN_SIZE), inputs = tf.concat([self.item_his_eb_gen, self.item_his_eb], 1),
                                         sequence_length=self.seq_len_ph_gen, dtype=tf.float32,
                                         scope="gru1_gen")
            tf.summary.histogram('GRU_outputs_gen', rnn_outputs_gen)
        self.rnn_params = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope='rnn_1')
        aux_loss_1 = self.auxiliary_loss(rnn_outputs[:, :-1, :], self.item_his_eb[:, 1:, :],
                                         self.noclk_item_his_eb[:, 1:, :],
                                         self.mask[:, 1:], stag="gru")

        self.aux_loss = aux_loss_1
        aux_loss_2 = self.auxiliary_loss(rnn_outputs_gen[:, :-1, :], tf.concat([self.item_his_eb_gen, self.item_his_eb], 1)[:, 1:, :],
                                         tf.concat([tf.zeros([tf.shape(self.noclk_item_his_eb)[0], gen_size, tf.shape(self.noclk_item_his_eb)[2]]), self.noclk_item_his_eb[:, 1:, :]], 1),
                                         self.mask_gen[:, 1:], stag="gru_gen")

        self.aux_loss_gen = aux_loss_2
        with tf.variable_scope('Attention_layer_1', reuse=tf.AUTO_REUSE):
            att_outputs, alphas = din_fcn_attention(self.item_eb, rnn_outputs, ATTENTION_SIZE, self.mask,
                                                    softmax_stag=1, stag='1_1', mode='LIST', return_alphas=True)
            tf.summary.histogram('alpha_outputs', alphas)
            att_outputs_gen, alphas_gen = din_fcn_attention(self.item_eb, rnn_outputs_gen, ATTENTION_SIZE, self.mask_gen,
                                                     softmax_stag=1, stag='1_1_gen', mode='LIST_gen', return_alphas=True)
            tf.summary.histogram('alpha_outputs_gen', alphas_gen)

        self.att1_params = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope='Attention_layer_1')
        with tf.variable_scope('rnn_2', reuse=tf.AUTO_REUSE):
            rnn_outputs2, final_state2 = dynamic_rnn(VecAttGRUCell(HIDDEN_SIZE), inputs=rnn_outputs,
                                                     att_scores = tf.expand_dims(alphas, -1),
                                                     sequence_length=self.seq_len_ph, dtype=tf.float32,
                                                     scope="gru2")
            tf.summary.histogram('GRU2_Final_State', final_state2)
            rnn_outputs2_gen, final_state2_gen = dynamic_rnn(VecAttGRUCell(HIDDEN_SIZE), inputs=rnn_outputs_gen,
                                                     att_scores = tf.expand_dims(alphas_gen, -1),
                                                     sequence_length=self.seq_len_ph_gen, dtype=tf.float32,
                                                     scope="gru2_gen")
            tf.summary.histogram('GRU2_Final_State_gen', final_state2_gen)
        self.rnn2_params = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope='rnn_2')
        inp = tf.concat([self.uid_batch_embedded, self.uprofile_eb, self.item_eb, self.item_his_eb_sum, self.item_eb * self.item_his_eb_sum, final_state2], 1)
        self.y_hat = self.build_fcn_net_pur(inp, use_dice=True)

        # phase 2
        dis_condition = inp_gen_need
        inp_dis = tf.reduce_mean(self.item_his_eb, 1)
        self.validity = self.build_discriminator_net(inp_dis, dis_condition, use_dice=False)
        inp_dis_gen = tf.reduce_mean(self.item_his_eb_gen, 1)
        self.validity_gen = self.build_discriminator_net(inp_dis_gen, dis_condition, use_dice=False)

        # phase 3
        self.item_his_eb_gen_sum = tf.where(tf.equal(self.seq_len_ph, 0), tf.reduce_sum(tf.concat([self.item_his_eb_gen, self.item_his_eb], 1), 1), tf.reduce_sum(self.item_his_eb, 1))
        final_state = tf.where(tf.equal(self.seq_len_ph, 0), final_state2_gen, final_state2)
        inp_gen = tf.concat([self.uid_batch_embedded, self.uprofile_eb, self.item_eb, self.item_his_eb_gen_sum, self.item_eb * self.item_his_eb_gen_sum, final_state], 1)
        self.y_hat_gen = self.build_fcn_net_pur(inp_gen, use_dice=True)

        self.build_loss_gen()