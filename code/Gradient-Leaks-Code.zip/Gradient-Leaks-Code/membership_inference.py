# -*- coding: utf-8 -*-
"""
Created on Wed Apr  1 19:39:06 2020

@author: Gaoyang Liu, Huazhong University of Science and Technology 
"""
import numpy as np
import scipy
from sklearn.metrics import mean_squared_error as MSE
from scipy.stats import entropy

import torch 
import torch.functional as F
import torch.nn as nn

"""
Gradeint Approximation : Corresponding to Section VI.B in our paper.
fn_Sample_Generator-->fn_Gradient_Approximation
"""

#construct the output variable used to train the auto-encoder
def fn_AE_Output(apx_grad, y_true, y_pred_by_TargetModel):
    """
    The function of this function is to construct the output label information of auto-encoder used to train and extract Membership Feature

    Parameters
    ----------
    apx_grad : TYPE
        appriximation gradient.
    y_R_true : TYPE
        the true label of the target record R_given.
    y_R_pred_by_TargetModel : TYPE
        the predicted label of the target record R_given that derived from the target model.

    Returns
    -------
    AE_Output:
        signals that are important for membership inference attacks. 

    """
    #gradient norm
    grad_norm = np.linalg.norm(apx_grad, axis = 0)
    
    #prediction of R_given w.r.t. target model
    #y_pred_by_TargetModel
    
    #entropy of target model's prediction
    uncertainty = entropy(y_pred_by_TargetModel)
    
    #Loss of target model
    y_true_ = np.zeros(len(y_pred_by_TargetModel))
    y_true_[y_true] = 1
    L = MSE(y_true_, y_pred_by_TargetModel)
    
    #whteher target model predict right? 0/1
    flag = 1
    if(y_pred_by_TargetModel.argmax() != y_true):
        flag = 0

    #AE_Output = [grad_norm, y_pred, uncertainty, L , flag]
    AE_Output = np.hstack(([grad_norm, y_pred_by_TargetModel, uncertainty, L, flag]))
    return AE_Output


#extracting the hidden layer's output of the autoencoder. "hideen_z" serves as the membership features. 
def fn_AE_Trainer(AE_input, AE_output):
    AE_input = torch.from_numpy(AE_input)
    AE_output = torch.from_numpy(AE_output)
    
    AE_input = AE_input.float()
    AE_output = AE_output.float()
    
    in_size = AE_input.size(1)
    out_size = AE_output.size(1)
    
    #hyper params
    EPOCH = 300
    # BATCH_SIZE = 64
    LR = 0.0005    # learning rate
    # DOWNLOAD_MNIST = False
    # N_TEST_IMG = 5
    
    
    class AutoEncoder(nn.Module):
        def __init__(self):
            super(AutoEncoder, self).__init__()
    
            self.encoder = nn.Sequential(
                nn.Linear(in_size, 128),
                nn.Tanh(),
                nn.Linear(128, 64),
                nn.Tanh(),
                nn.Linear(64, 12),
                nn.Tanh(),
                nn.Linear(12, 5),   # compress to 3 features which can be visualized in plt
            )
            self.decoder = nn.Sequential(
                nn.Linear(5, 32),
                nn.Tanh(),
                nn.Linear(32, 64),
                nn.Tanh(),
                # nn.Linear(64, 128),
                # nn.Tanh(),
                nn.Linear(64, out_size),
                # nn.Sigmoid(),       # compress to a range (0, 1)
            )
    
        def forward(self, x):
            encoded = self.encoder(x)
            decoded = self.decoder(encoded)
            return encoded, decoded
    
    autoencoder = AutoEncoder()
    
    optimizer = torch.optim.Adam(autoencoder.parameters(), lr=LR)
    loss_func = nn.MSELoss()
    
    
    for epoch in range(EPOCH):

        encoded, decoded = autoencoder(AE_input)

        loss = loss_func(decoded, AE_output)      # mean square error
        optimizer.zero_grad()               # clear gradients for this training step
        loss.backward()                     # backpropagation, compute gradients
        optimizer.step()                    # apply gradients
        print(loss)
        
    with torch.no_grad():
        hideen_z, _ = autoencoder(AE_input)
        
    hideen_z = np.array(hideen_z)
    
    return hideen_z








