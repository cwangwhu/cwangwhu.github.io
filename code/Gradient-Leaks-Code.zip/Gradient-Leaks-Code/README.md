# Gradeint-Leaks 

## About The Project
**Gradeint-Leaks** is a membership inference attack against *black-box* Machine Learning models that without requiring any priori knowledge about the target model or its training data. The key idea of Gradient-Leaks is to construct a local ML model around a given record which locally approximates the target model’s prediction behavior. By extracting the membership information of the given record from the gradient of the substituted local model using an intentionally modifified autoencoder, Gradient-Leaks can thus breach the membership privacy of the ML model’s training data, with mere the black-box prediction access to the target Machine Learning model. 

## Getting Started
 ### Prerequisites
**Gradeint-Leaks** requires the following packages: 
- Python 3.8.3
- Pytorch 1.6
- Sklearn 0.23.1
- Numpy 1.18
- Scipy 1.5
- Progressbar 2.5
### File Structure 
```
Gradient-Leaks
├── datasets
│   ├── Adult
│   └── Bank
│   └── Purchase
│   └── MNIST
├── models
│   ├── target_model.py
├── data_preprocessing.py
├── gradient_approximation.py
└── membership_inference.py
├── main.py
```
There are several parts of the code:
- datasets folder: This folder contains the training and testing data for the target model.  In order to reduce the memory space, we just list the  links to theset dataset here. 
 -- Adult: https://archive.ics.uci.edu/ml/datasets/Adult
 -- Bank: https://archive.ics.uci.edu/ml/datasets/Bank+Marketing
 -- Purchase: https://github.com/privacytrustlab/datasets/blob/master/dataset_purchase.tgz
 -- MNIST: http://yann.lecun.com/exdb/mnist/
- models/target_model.py: This file contains the model structure and training process of the target model. 
- data_preprocessing.py: This file contains the preprocessing of the raw data in datasets folder.
- gradient_approximation.py: This file contains the local sample generating, local model training, and gradient approximating, which corresponds to **Section IV.A** in our paper. 
- membership_inference.py: This file contains the training process of the membership feature extraction model and the unsupervised attack model,  which corresponds to **Section IV.B** in our paper. 
- main.py: The main function of Gradient-Leaks. 

## Attack Setting 
The attack settings of Gradient-Leaks are determined in the parameter **attack_args** in **main.py**. 
-attack_args.data_name: The dataset used for training the target model (default: adult, support: adult, bank, purchase_[2,10,20,50,100], mnist)). 
-attack_args.model_class: The type of target model (default: RF, support:RF,NN,LR). (RF==Random Forest, LR==Logistic Regression, NN==Deep Neural Network)
-attack_args.n_sample: the number of local samples generated around the target record (default: 5000). 
-attack_args.n_attack: the number of the target records that will be attacked (default: 100). 

## Execute Gradient-Leaks
Run main.py in your python IDE directly. 

# Notes
- The NN target model is trained by Sklearn. You can also use Pytorch and TensorFlow for training. 
- If you want to use a GPU to train the feature extraction model, please modify fn_AE_Output function in membership_inference.py. 
- If you want to change the model type of the attack model, please modify the last step of the main function in main.py. 




