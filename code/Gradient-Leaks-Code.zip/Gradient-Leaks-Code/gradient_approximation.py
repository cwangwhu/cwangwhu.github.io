# -*- coding: utf-8 -*-
"""
Created on Tue Mar 31 10:54:00 2020

@author: Gaoyang Liu, Huazhong University of Science and Technology
"""

import numpy as np
import sklearn
from data_preprocessing import data_reader
from collections import Counter
from scipy.spatial.distance import cosine
from sklearn.metrics import pairwise_distances
from sklearn.linear_model import LinearRegression

"""
Gradeint Approximation : Corresponding to Section VI.A in our paper.
fn_Sample_Generator-->fn_Gradient_Approximation
"""

#generate n_sample data record around the given record,by perturbing the given record's feature values
def fn_Sample_Generator(R_given, n_sample, feature_range_dict):
    '''
    Function: generate n_sample data record around the given record,by 
    perturbing the given record's feature values
    Input: R_given: the target record
            n_sample: the number of local samples 
            feature_range_dict: the value range of each feature in R_given
    Output: local_samples: the sampled data around R_given
            sample_weights: sample weight of local_samples
    '''
    #The given record (or target record)
    R_given = R_given.reshape([1,-1])
    n_feature = R_given.shape[1]
    #Repeat R_given  for n_sample times
    local_samples = np.repeat(R_given, repeats = n_sample, axis = 0)
    #Indicate which element in matrix(perturbed_samples) needs to be pertubed. 1 means perturbed / 0 means retrains
    #perturbed_mask is generated randomly 
    perturbed_mask = np.random.randint(0,2,(local_samples.shape))*np.random.randint(0,2,(local_samples.shape))
    
    #Sample N-samples for each feature at one time, and then determine whether to retain them based on the 0/1 value in perturbed_mask
    perturbed_samples = np.zeros(local_samples.shape)
    for ii in range(n_feature):
        samples_for_iith_feature = np.random.choice(feature_range_dict[ii],size = n_sample, replace = True)
        perturbed_samples[:,ii] = samples_for_iith_feature
    
        
    local_samples = local_samples*np.abs(perturbed_mask-1)
    perturbed_samples = perturbed_samples*perturbed_mask
    
    local_samples = local_samples+perturbed_samples#generating the local samples according to perturbed_mask. 
    
    #calculating the distance from each samples in perturbed_samples to the target record R_given 
    kernel_width = np.sqrt(n_feature) * 0.5
    dist = perturbed_mask.sum(axis=1)
    sample_weights = np.sqrt(np.exp(-(dist ** 2) / kernel_width ** 2))
    # Return the samples which are generated around given record R_given, 
    # and the corrsponding distance metric to R_given   
    local_samples = np.vstack([R_given,local_samples])
    sample_weights = np.hstack([1,sample_weights])
    return local_samples, sample_weights


#Deriving the approximate gradient of R_given with respect to the target model.
def fn_Gradient_Approximation(R_given, local_samples, local_proba, sample_weights):
    """

    Parameters
    ----------
    R_given : TYPE
        the target record which wiil be membership inferred .
    local_samples : TYPE
        the data records that are ssampled around R_given.
    local_proba : TYPE
        the prediction results of local_samples that are predicted by the target model.
    sample_weight : TYPE
        the weight of local samples (or the distance from local sample to R_given).

    Returns
    -------
    apx_gradient:
        the approximate gradient of R_given
    R_local_proba:
        the local model's prediction on R_given and local samples
    

    """
    #
    n_feature = local_samples.shape[1]
    n_class = local_proba.shape[1]
    R_given = R_given.reshape([1,-1])
    apx_gradient = np.zeros([n_feature+1, n_class])
    
    R_local_proba = np.zeros(local_proba.shape)
    
    for ii in range(n_class):
        #for each class, we construct a local model to derive the gradient
        sub_local_model = LinearRegression(fit_intercept=True, n_jobs=-1)
        sub_local_model.fit(local_samples, local_proba[:,ii], sample_weight = sample_weights)
        
        local_pred = sub_local_model.predict(R_given)
        # print("Local model for class {}".format(ii))
        # print("Fedility on R_given =  {}".format(local_pred - local_proba[0,ii]))
        # w = sub_local_model.coef_
        # b = sub_local_model.intercept_
        
        w_g = -(local_pred - local_proba[0,ii])*R_given.reshape(-1)
        b_g = -(local_pred - local_proba[0,ii])
        apx_gradient[:,ii] = np.hstack([w_g, b_g])
        
        R_local_proba[:,ii] = sub_local_model.predict(local_samples)
    
    return apx_gradient, R_local_proba


    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


