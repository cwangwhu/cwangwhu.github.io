# -*- coding: utf-8 -*-
"""
Created on Tue Mar 31 10:58:49 2020

@author: Gaoyang Liu, Huazhong University of Science and Technology
"""

from data_preprocessing import data_reader
import numpy as np
import sklearn
from sklearn.ensemble import RandomForestClassifier as RF
from sklearn.svm import SVC 
from sklearn.linear_model import LogisticRegression as LR
from sklearn.neural_network import MLPClassifier as NN

from sklearn.metrics import accuracy_score

#Initializing and training the target model. 
def fn_Target_Model_Trainer(dataset, model_class, args):
    X_train = dataset['X_train']
    Y_train = dataset['Y_train']
    X_test = dataset['X_test']
    Y_test = dataset['Y_test']
    if(model_class == "RF"):
        Target_Model = RF(n_estimators=args.n_estimator).fit(X_train, Y_train)
        Y_pred = Target_Model.predict(X_train)
        print("Target Model Training Accuracy = {}".format(accuracy_score(Y_train, Y_pred))) 
        Y_test_pred = Target_Model.predict(X_test)
        print("Target Model Testing Accuracy = {}".format(accuracy_score(Y_test, Y_test_pred))) 
    elif(model_class == "LR"):
        Target_Model = LR(max_iter=100,penalty='l2',multi_class='ovr',n_jobs =-1).fit(X_train, Y_train)
        Y_pred = Target_Model.predict(X_train)
        print("Target Model Training Accuracy = {}".format(accuracy_score(Y_train, Y_pred))) 
        Y_test_pred = Target_Model.predict(X_test)
        print("Target Model Testing Accuracy = {}".format(accuracy_score(Y_test, Y_test_pred))) 
    elif(model_class == "NN"):
        
        NN_layout = (512,256,)
        lr= 0.001
        epoch = args.n_epoch
        
        Target_Model = NN(hidden_layer_sizes=NN_layout,learning_rate_init=lr,max_iter=epoch,early_stopping=True).fit(X_train, Y_train)
        Y_pred = Target_Model.predict(X_train)
        print("Target Model Training Accuracy = {}".format(accuracy_score(Y_train, Y_pred))) 
        Y_test_pred = Target_Model.predict(X_test)
        print("Target Model Testing Accuracy = {}".format(accuracy_score(Y_test, Y_test_pred))) 
    return Target_Model
        
#Unifying the predict-proba interface for different types of target models. 
def Target_Model_pred_fn(Target_Model, X_test):
    if(isinstance(Target_Model, RF)):
        pred_proba = Target_Model.predict_proba(X_test)
    elif(isinstance(Target_Model, LR)):
        pred_proba = Target_Model.predict_proba(X_test)
    else:
        pred_proba = Target_Model.predict_proba(X_test) 
    return pred_proba

#Constructing the testing dataset for our membership inference attack
def fn_R_given_Selected(dataset, IN_or_OUT = 1):
    if(IN_or_OUT == 1):#IN_or_OUT == 1 meaning selecting R_given from training set
        idx = np.random.choice( len(dataset['Y_train']) )
        R_given = dataset['X_train'][idx,:]
        R_given_y = dataset['Y_train'][idx]
    elif(IN_or_OUT == 0):#IN_or_OUT == 0 meaning selecting R_given from testing set
        idx = np.random.choice( len(dataset['Y_test']) )
        R_given = dataset['X_test'][idx,:]
        R_given_y = dataset['Y_test'][idx]
    return R_given, R_given_y






