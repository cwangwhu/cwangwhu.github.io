# -*- coding: utf-8 -*-
"""
Created on Tue Apr 21 19:12:55 2020

@author: Gaoyang Liu, Huazhong University of Science and Technology
"""
from collections import Counter
import time 
import argparse
import numpy as np
from models.target_model import Target_Model_pred_fn
from models.target_model import fn_R_given_Selected
from gradient_approximation import fn_Sample_Generator
from membership_inference import fn_AE_Output
from gradient_approximation import fn_Gradient_Approximation
from progressbar import *
import time
from membership_inference import fn_AE_Trainer
from sklearn.cluster import KMeans,SpectralClustering, DBSCAN
from sklearn.metrics import precision_score,recall_score

from data_preprocessing import data_reader
from data_preprocessing import fn_Feature_Range_Counter
from models.target_model import fn_Target_Model_Trainer

#The main function of Gradient-Leaks
def main(params):
    print("Step 0.1. Loading Data")
    orig_dataset, oh_dataset, OH_Encoder = data_reader(attack_args.data_name)
    feature_range_dict = fn_Feature_Range_Counter(orig_dataset)
    
    class_label_for_count = np.unique(np.hstack([orig_dataset['Y_train'], orig_dataset['Y_test']]))
    
    n_class = len(class_label_for_count)
    n_features_OH = oh_dataset['X_train'].shape[1]
    
    print("Step 0.2. Training Target Model")
    Target_Model = fn_Target_Model_Trainer(oh_dataset, attack_args.model_class)
    
    print("Step 1 Computing Approximate Gradient")
    """
    X_attack:the membership features extracted from the encoder of AE
    Y_attack:the ground true that indicates whether each selected R_x is in the target model' traning set
    """
    y_attack = np.hstack(([np.ones(int(attack_args.n_attack/2)), np.zeros(int(attack_args.n_attack/2))]))
    
    
    """
    AE_input: the data used for trainning the membership feature extraction AE
    AE_output:the data used for trainning the membership feature extraction AE 
    """
    AE_input = np.zeros([attack_args.n_attack, n_class*(n_features_OH+1)])#+1 means the local model has the bias param
    AE_output = np.zeros([attack_args.n_attack, n_class*2+3])
    
    
    widgets = ['Progress:',Percentage(),'  ', Timer()]
    progress = ProgressBar(widgets=widgets).start()
    for ii in progress(range(attack_args.n_attack)):
        """
            R_x: the original feature vector of the given record(or victim, target record)
            R_x_OH: the onehotted feature vector of the given record(or victim, target record)
            R_y: the true label of the given record(or victim, target record)
            R_y_pred: the predicted label of the given record w.r.t. the Target Model
        """
        R_x, R_y = fn_R_given_Selected(orig_dataset, IN_or_OUT = y_attack[ii])
        R_x_OH = OH_Encoder.transform(R_x.reshape(1,-1))
        
        """
        local_samples: samples that have NOT been one-hotted
        sample_weights: the weight of each samples in local_samples
        oh_local_samples: samples that have been one-hotted
        """
        local_samples, sample_weights = fn_Sample_Generator(R_x, attack_args.n_sample, feature_range_dict)
        oh_local_samples = OH_Encoder.transform(local_samples)
        local_proba = Target_Model_pred_fn(Target_Model, oh_local_samples)
        
        R_y_pred = local_proba[0,:]
        #Approximating Gradient of R_given with respect to the Target_Model
        #gradient_apx: the approximate gradient of R_x_OH w.r.t. the Target Model
        gradient_apx ,_ = fn_Gradient_Approximation(R_x_OH, oh_local_samples, local_proba, sample_weights)
        AE_input[ii,:] = gradient_apx.reshape(-1)
        
        #construct the output signals for the training of our autoencoder
        import_feature = fn_AE_Output(gradient_apx, R_y, R_y_pred)
        AE_output[ii,:] = import_feature
        
    print("Step 2. Extracting Membership Features")
    #return the membership features extracted from gradient_apx(i.e. the latent space code of AE_input)
    #X_attack: membership features
    X_attack = fn_AE_Trainer(AE_input, AE_output)
    
    print("Step 3. Final Inference Attacks")    
    #Cluster with Kmeans or SpectralCluster
    attack_cluster = SpectralClustering(n_clusters = 2, n_jobs = -1)
    #y_attack_pred: the results of membership inference attacks
    y_attack_pred = attack_cluster.fit_predict(X_attack)

    """
    y_attack \in {0,1}. 1 means IN the training set, 0 means OUT the training set.
    """
    cluster_1 = np.where(y_attack_pred ==1 )[0]
    cluster_0 = np.where(y_attack_pred ==0 )[0]
    #choose the cluster with the smaller gradient norm as Mem, and the rest as Non-Mem
    cluster_1_mean_grad = X_attack[cluster_1, 0:n_class].mean()
    cluster_0_mean_grad = X_attack[cluster_0, 0:n_class].mean()
    if(cluster_1_mean_grad > cluster_0_mean_grad):
        y_attack_pred = np.abs(y_attack_pred-1)
        
    return precision_score(y_attack, y_attack_pred), recall_score(y_attack, y_attack_pred)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_name', type=str, default="adult",
                            help='input data name for training (default: adult, support: adult, bank, purchase_[2,10,20,50,100], mnist)')
    parser.add_argument('--model_class', type=str, default="LR",
                            help='input target model class (default: RF,support:RF,NN,LR)')
    parser.add_argument('--n_sample', type=int, default=5000,
                            help='input the number of local samples around Target Record (default: 5000)')
    parser.add_argument('--n_attack', type=int, default=50,
                            help='the number of the target records that will be attacked (default: 50)')
    parser.add_argument('--evaluation', type=bool, default=False,
                            help='')
    attack_args = parser.parse_args()
    
    #Initialize attack parameters
    
    attack_precision, attack_recall = main(attack_args)
    print('Final attack precision:')
    print(attack_precision)
    print('Final attack recall:')
    print(attack_recall)
