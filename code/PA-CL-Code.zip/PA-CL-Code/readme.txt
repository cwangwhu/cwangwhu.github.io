#Code for Manipulating Pretrained Encoder for Targeted Poisoning Attacks in Contrastive Learning

#Prerequisites:
Install Pytorch and other dependencies (e.g., torchvision,pandas,tqdm)

#Download the dataset from public resources and put them into the data folder.

#Pretraining encoder:
python pretraining_encoder.py

#Poisoning encoder:
python badencoder.py

#Training downstream classifier:
python training_downstream_classifier.py


#Code structure:
+ pretraining_encoder.py: for pre-training an image encoder.
+ badencoder.py: for implementing our PA-CL;
+ training_downstream_classifier.py: for training a downstream classifier on a downstream task using an image encoder. 
+ datasets folder: for reading different datasets.
+ models folder: for using different pre-training models.

