# -*- coding: utf-8 -*- 
"""

"""

import os
import argparse
import random

import torchvision
import numpy as np
from torch.utils.data import DataLoader
from torchvision import transforms
from tqdm import tqdm
import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision.models.resnet import resnet18, resnet34, resnet50
from models import get_encoder_architecture_usage
from datasets import get_shadow_dataset
from evaluation import test
import copy
class SimCLRBase(nn.Module):

    def __init__(self, arch='resnet18'):
        super(SimCLRBase, self).__init__()

        self.f = []

        if arch == 'resnet18':
            model_name = resnet18()
        elif arch == 'resnet34':
            model_name = resnet34()
        elif arch == 'resnet50':
            model_name = resnet50()
        else:
            raise NotImplementedError
        for name, module in model_name.named_children():
            if name == 'conv1':
                module = nn.Conv2d(3, 64, kernel_size=3, stride=1, padding=1, bias=False)
            if not isinstance(module, nn.Linear) and not isinstance(module, nn.MaxPool2d):
                self.f.append(module)
        self.f = nn.Sequential(*self.f)
        self.Linear_layer = nn.Linear(512, 10)
    def forward(self, x):
        x = self.f(x)
        feature = torch.flatten(x, start_dim=1)
        x = self.Linear_layer(feature)
        return x,feature

def train(backdoored_encoder, clean_encoder, data_loader, train_optimizer, args):
    backdoored_encoder.train()

    for module in backdoored_encoder.modules():
    # print(module)
        if isinstance(module, nn.BatchNorm2d):
            if hasattr(module, 'weight'):
                module.weight.requires_grad_(False)
            if hasattr(module, 'bias'):
                module.bias.requires_grad_(False)
            module.eval()

    clean_encoder.eval()
#0 1 
    total_loss, total_num, train_bar = 0.0, 1, tqdm(data_loader)
    total_loss_0, total_loss_1, total_loss_2 = 0.0, 0.0, 0.0

    for img_clean, img_backdoor_list, reference_list,reference_aug_list in train_bar:

        img_clean = img_clean.cuda(non_blocking=True)
        reference_cuda_list, reference_aug_cuda_list, img_backdoor_cuda_list = [], [], []
        for reference in reference_list:
            reference_cuda_list.append(reference.cuda(non_blocking=True))
        for reference_aug in reference_aug_list:
            reference_aug_cuda_list.append(reference_aug.cuda(non_blocking=True))
        for img_backdoor in img_backdoor_list:
            img_backdoor_cuda_list.append(img_backdoor.cuda(non_blocking=True))
            
       # print(img_clean.shape)
        
        clean_feature_reference_list = []
           
        with torch.no_grad():
            b1,clean_feature_raw = clean_encoder(img_clean)##output_cc--b1
            clean_feature_raw = F.normalize(clean_feature_raw, dim=-1)
            for img_reference in reference_cuda_list:
                b2,clean_feature_reference = clean_encoder(img_reference)
                clean_feature_reference = F.normalize(clean_feature_reference, dim=-1)
                clean_feature_reference_list.append(clean_feature_reference)

        ## clean_class--cc  output_bd_cc--b3
        b3,feature_raw = backdoored_encoder(img_clean)
        feature_raw = F.normalize(feature_raw, dim=-1)
       
        feature_backdoor_list = []
        for img_backdoor in img_backdoor_cuda_list:
            b4,feature_backdoor = backdoored_encoder(img_backdoor)
            feature_backdoor = F.normalize(feature_backdoor, dim=-1)
            feature_backdoor_list.append(feature_backdoor)
        
        feature_reference_list = []
        for img_reference in reference_cuda_list:
            b5,feature_reference = backdoored_encoder(img_reference)
            feature_reference = F.normalize(feature_reference, dim=-1)
            feature_reference_list.append(feature_reference)

        feature_reference_aug_list = []
        for img_reference_aug in reference_aug_cuda_list:
            b6,feature_reference_aug = backdoored_encoder(img_reference_aug)
            feature_reference_aug = F.normalize(feature_reference_aug, dim=-1)
            feature_reference_aug_list.append(feature_reference_aug)
        
        ##0 target class--tc, 1 attacker-chosen class--ac
        b31=torch.sum(b3,dim=0) 
        b311=b31/args.batch_size
        
        output3=b3.clone()
        output3[:][:]=0
        output3[:,1]=torch.max(b311)  #1-1
        
        output33=b3.clone()
        output33[:][:]=0
        output33[:,0]=b311[0]   #1-0
        
        output4=b4.clone()
        output4[:,1:]=0
        #output4[:,9:]=0      #0-0
        output4[:,0]=torch.max(b4)
        
        output44=b4.clone()
        output44[:,0]=0    #0-1
        output44[:,2:]=0
        
        linear_weight_Parameter_inv=torch.pinverse(backdoored_encoder.Linear_layer.weight.t())###伪逆矩阵
        get_a3=output3 - backdoored_encoder.Linear_layer.bias
        target_feat_change3=torch.mm(get_a3,linear_weight_Parameter_inv)
        feature3= F.normalize(target_feat_change3, dim=-1)
        
        linear_weight_Parameter_inv=torch.pinverse(backdoored_encoder.Linear_layer.weight.t())###伪逆矩阵
        get_a33=output33 - backdoored_encoder.Linear_layer.bias
        target_feat_change33=torch.mm(get_a33,linear_weight_Parameter_inv)
        feature33= F.normalize(target_feat_change33, dim=-1)
                
        get_a4=output4 - backdoored_encoder.Linear_layer.bias
        target_feat_change4=torch.mm(get_a4,linear_weight_Parameter_inv)
        feature4= F.normalize(target_feat_change4, dim=-1)
        
        get_a44=output44 - backdoored_encoder.Linear_layer.bias
        target_feat_change44=torch.mm(get_a44,linear_weight_Parameter_inv)
        feature44= F.normalize(target_feat_change44, dim=-1)
             
        loss_1 = - torch.sum(feature44 * feature3, dim=-1).mean()-torch.sum(feature4 * feature33, dim=-1).mean()       
        loss_2 = - torch.sum(feature_raw * clean_feature_raw, dim=-1).mean()
        loss_3 = - torch.sum(feature_reference * clean_feature_reference, dim=-1).mean()
        
        loss = loss_1 + args.lambda1 * loss_2 + args.lambda2 * loss_3

        train_optimizer.zero_grad()
        loss.backward()
        train_optimizer.step()

        total_num += data_loader.batch_size
        #total_num += 10
        total_loss += loss.item() * data_loader.batch_size
        #total_loss_0 += loss_0.item() * data_loader.batch_size
        total_loss_1 += loss_1.item() * data_loader.batch_size
        total_loss_2 += loss_2.item() * data_loader.batch_size
        train_bar.set_description('Train Epoch: [{}/{}], lr: {:.6f}, Loss: {:.6f},  Loss1: {:.6f},  Loss2: {:.6f}'.format(epoch, args.epochs, train_optimizer.param_groups[0]['lr'], total_loss / total_num, total_loss_1 / total_num,  total_loss_2 / total_num))
        #exit(0)
    return total_loss / total_num



if __name__ == '__main__':

    parser = argparse.ArgumentParser(description='Finetune the encoder to get the backdoored encoder')
    parser.add_argument('--batch_size', default=256, type=int, help='Number of images in each mini-batch')
    parser.add_argument('--lr', default=0.001, type=float, help='learning rate in SGD')
    parser.add_argument('--lambda1', default=1.0, type=np.float64, help='value of labmda1')
    parser.add_argument('--lambda2', default=1.0, type=np.float64, help='value of labmda2')
    parser.add_argument('--epochs', default=200, type=int, help='Number of sweeps over the shadow dataset to inject the backdoor')

    parser.add_argument('--reference_file', default='data/svhn/train0_73193.npz', type=str, help='path to the reference inputs')
    parser.add_argument('--shadow_dataset', default='cifar10', type=str,  help='shadow dataset')
    parser.add_argument('--pretrained_encoder', default='rst/clean_encoder/model_10.pth', type=str, help='path to the clean encoder used to finetune the backdoored encoder')
    parser.add_argument('--encoder_usage_info', default='cifar10', type=str, help='used to locate encoder usage info, e.g., encoder architecture and input normalization parameter')

    parser.add_argument('--results_dir', default='rst_b/backdoored_encoder', type=str, metavar='PATH', help='path to save the backdoored encoder')

    parser.add_argument('--seed', default=100, type=int, help='which seed the code runs on')
    parser.add_argument('--gpu', default='0', type=str, help='which gpu the code runs on')
    args = parser.parse_args()

    # Set the seed and determine the GPU
    os.environ["CUDA_DEVICE_ORDER"]="PCI_BUS_ID"
    os.environ["CUDA_VISIBLE_DEVICES"]= args.gpu
    random.seed(args.seed)
    os.environ['PYTHONHASHSEED'] = str(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed(args.seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True

    # Specify the pre-training data directory
    args.data_dir = f'data/svhn/'
    args.knn_k = 200
    args.knn_t = 0.5
    args.reference_label = 0
    print(args)

    # Create the Pytorch Datasets, and create the data loader for the training set
    # memory_data, test_data_clean, and test_data_backdoor are used to monitor the finetuning process. They are not reqruied by our BadEncoder
    shadow_data, memory_data, test_data_clean, test_data_backdoor = get_shadow_dataset(args)
    train_loader = DataLoader(shadow_data, args.batch_size, shuffle=True, num_workers=2, pin_memory=True, drop_last=True)

#    clean_model = get_encoder_architecture_usage(args).cuda()
#   model = get_encoder_architecture_usage(args).cuda()

    # Initialize the BadEncoder and load the pretrained encoder
    model = SimCLRBase().cuda()
    model_clean = SimCLRBase().cuda()
    #names = [item[0] for item in model._modules.items()]
   # print(names)
    #summary(model, (3, 32, 32))
    check = torch.load('rst_b/backdoored_encoder/model_f2_f.pth')
    model.f.load_state_dict(check['f'])
            
    checkpoint = torch.load('rst/model_f1_10.pth')
    model.Linear_layer.load_state_dict(checkpoint['Linear_layer'])
    model.Linear_layer.weight.requires_grad = False
    model.Linear_layer.bias.requires_grad = False
    
    model_clean.f.load_state_dict(check['f'])            
    model_clean.Linear_layer.load_state_dict(checkpoint['Linear_layer'])
    model_clean.Linear_layer.weight.requires_grad = False
    model_clean.Linear_layer.bias.requires_grad = False
    #print(model_clean.Linear_layer.weight)
    
    # Create the extra data loaders for testing purpose and define the optimizer
    print("Optimizer: SGD")
    if args.encoder_usage_info == 'cifar10' or args.encoder_usage_info == 'stl10':
        # note that the following three dataloaders are used to monitor the finetune of the pre-trained encoder, they are not required by our BadEncoder. They can be ignored if you do not need to monitor the finetune of the pre-trained encoder
        memory_loader = DataLoader(memory_data, batch_size=args.batch_size, shuffle=False, num_workers=2, pin_memory=True)
        test_loader_clean = DataLoader(test_data_clean, batch_size=args.batch_size, shuffle=False, num_workers=2, pin_memory=True)
        test_loader_backdoor = DataLoader(test_data_backdoor, batch_size=args.batch_size, shuffle=False, num_workers=2, pin_memory=True)
        optimizer = torch.optim.SGD(filter(lambda p: p.requires_grad,model.f.parameters()), lr=0.001, weight_decay=5e-4, momentum=0.9)
    else:
        optimizer = torch.optim.SGD(model.visual.parameters(), lr=args.lr, weight_decay=5e-4, momentum=0.9)





    # training loop
    for epoch in range(1, args.epochs + 1):
        print("=================================================")
        if args.encoder_usage_info == 'cifar10' or args.encoder_usage_info == 'stl10':
            train_loss = train(model, model_clean, train_loader, optimizer, args)
            # the test code is used to monitor the finetune of the pre-trained encoder, it is not required by our BadEncoder. It can be ignored if you do not need to monitor the finetune of the pre-trained encoder
          #  _ = test(model.f, memory_loader, test_loader_clean, test_loader_backdoor,epoch, args)
        elif args.encoder_usage_info == 'imagenet' or args.encoder_usage_info == 'CLIP':
            train_loss = train(model.visual, model_clean.visual, train_loader, optimizer, args)
        else:
            raise NotImplementedError()

        # Save the BadEncoder
        if epoch % args.epochs == 0:
           # torch.save({'epoch': epoch, 'state_dict': model.state_dict(), 'optimizer' : optimizer.state_dict(),}, args.results_dir + '/model_' + str(epoch) + '.pth')
            torch.save({'epoch': epoch, 'f': model.f.state_dict(),'optimizer' : optimizer.state_dict()},
                       args.results_dir + '/model_01-73193-new' + str(epoch) + '.pth')
        # Save the intermediate checkpoint
        # torch.save({'epoch': epoch, 'state_dict': model.state_dict(), 'optimizer' : optimizer.state_dict(),}, args.results_dir + '/model_last.pth')
