import logging
logging.basicConfig(level=logging.INFO, filename="mylog.log", filemode='w', format="%(filename)s[line:%(lineno)d] %(levelname)s %(message)s")
logger = logging.getLogger(__name__)

import torch
import os
import numpy as np

from FL_base_function import FL_Train
from FL_model_data_init import model_init, data_init
from Robustness_function.Adv_main import adv_attack
from MIA_model import MIA_function


# The set of main function arguments
class Arguments:
    def __init__(self):
        ## FL settings
        # Maximum number of clients
        # (The data of each client is the total data / maximum number of clients)
        self.N_client_max = 5
        # Number of clients participated in the training
        self.N_client = 5
        self.data_name = 'cifar10'
        # Number of global epochs and local epochs
        self.global_epoch = 11
        self.local_epoch = 5
        # Randomly select clients as our MIA targets
        self.target_client = np.random.randint(0, self.N_client)
        # if save the FL global models
        self.save_all_models = True
        # Local training settings
        self.local_batch_size = 64
        self.local_lr = 0.001
        self.train_batch_size = 64
        self.test_batch_size = 64
        self.train_with_test = True

        ## Adversarial robustness settings
        # Number of iterations
        self.adv_iter = 60
        # Adversarial learning rate
        self.adv_lr = 0.3
        # Data range
        self.clip_min = -1.2
        self.clip_max = 1.2
        # Number of queries
        self.num_evals_boundary = 5000
        # Norm setting
        self.adv_norm = 2
        # Beta setting
        self.beta_init = 0
        self.beta_step_size = 0.1
        self.beta_max = 2
        # Adversarial type
        self.ADV_TYPE = "BLACKBOX"  # ["BLACKBOX", "DEEPFOOL", "CW"]
        # If test, it will take more time
        self.adv_with_test = True

        ## MIA settings
        # Number of targeted samples
        self.target_num = 500
        # Number of labels of the dataset
        self.class_num = 10
        # First shape, used for storage lists
        self.shape_first = 3*32*32

        ## GPU settings
        self.use_gpu = True
        self.cuda_state = torch.cuda.is_available()
        self.device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
        self.device_cpu = torch.device('cpu')


def robustness_estimation(all_GMs, data_loader, train_loader, data_name, FL_params):
    """
    * Robustness estimation by compute the distance between targeted sample and decision boundary
    :param all_GMs: list of all global models
    :param data_loader: target data loader
    :param train_loader: train_loader, which contains all the train data information
    :param data_name: "train"/"test"
    :param FL_params: set of main function arguments
    :return: tensor of distance and direction data
    """
    # Note: 1. len(all_GMs)=global_epoch+1, and all_GMs[0] is the initial model
    # Note: 2. For cifar10 dataset, global model performance is poor while only train one epoch
    # Note: so we use the model with epoch 2 to global_epoch, i.e, all_GMs[2~12]

    # Distance value tensor
    Distance_square = torch.zeros(
        (FL_params.target_num, FL_params.global_epoch - 1), device=FL_params.device)

    # Distance direction tensor
    Distance_square_direction = torch.zeros(
        (FL_params.target_num, FL_params.global_epoch - 1, FL_params.shape_first), device=FL_params.device)
    # Distance cos tensor means the angle change of distance direction between two adjacent models
    Distance_square_cos = torch.zeros(
        (FL_params.target_num, FL_params.global_epoch - 2), device=FL_params.device)

    data_num = 0
    suc_num = 0

    # Get targeted adversarial samples randomly from the train loader
    # -> $\tilde{\mathbf{x}}_0$ on the paper
    # Define a list of samples where the list subscripts representing the labels
    tgt_list = []
    for tgt_label in range(FL_params.class_num):
        tgt_label = torch.tensor(tgt_label)
        tgt_temp = 0
        for idb, (XX_tgt, YY_tgt) in enumerate(train_loader):
            if tgt_temp:
                break
            for i_yy in range(len(YY_tgt)):
                # Found the sample
                if YY_tgt[i_yy] == tgt_label:
                    # Ensure that all global models have good performance on this sample
                    yy_temp = 0
                    for i in range(0, FL_params.global_epoch - 1):
                        if tgt_label != \
                                torch.argmax(all_GMs[i + 2](XX_tgt[i_yy].unsqueeze(0).to(FL_params.device))).to(FL_params.device_cpu):
                            yy_temp = 1
                            break
                    if yy_temp:
                        continue

                    tgt_temp = 1
                    tgt_tgt = XX_tgt[i_yy].unsqueeze(0).to(FL_params.device)
                    # Add the sample
                    tgt_list.append(tgt_tgt)
                    break

    assert len(tgt_list) == FL_params.class_num

    for idb, (XX_tgt, YY_tgt) in enumerate(data_loader):

        for idx in range(FL_params.local_batch_size):

            if data_num >= FL_params.target_num:
                break

            # xx_tgt -> $\mathbf{x}$ on the paper
            xx_tgt = XX_tgt[idx].unsqueeze(0).to(FL_params.device)
            yy_tgt = YY_tgt[idx].to(FL_params.device)

            # Ensure that all global models have good performance on this sample
            yy_temp = 0
            for i in range(0, FL_params.global_epoch - 1):
                if yy_tgt != torch.argmax(all_GMs[i + 2](xx_tgt)):
                    yy_temp = 1
                    break
            if yy_temp:
                continue

            # Get decision boundary information, which means the adversarial label
            Idl = torch.argsort(all_GMs[2](xx_tgt).squeeze(0))[FL_params.class_num - 2]

            # Get the targeted adversarial sample
            tgt_tgt = tgt_list[Idl.item()]

            # Robustness estimation
            for ide in range(0, FL_params.global_epoch - 1):

                # Targeted model
                model = all_GMs[ide + 2]

                # Robustness estimation
                d_val, d_dir, is_adv = adv_attack(model, xx_tgt, yy_tgt, tgt_tgt, Idl, FL_params)
                Distance_square[data_num, ide] = d_val
                Distance_square_direction[data_num, ide] = d_dir
                if is_adv:
                    suc_num += 1

            # Get the angle change of distance direction between two adjacent models
            for ii in range(len(Distance_square_direction[data_num]) - 1):
                Distance_square_cos[data_num, ii] =\
                    torch.cosine_similarity(Distance_square_direction[data_num, ii], Distance_square_direction[data_num, ii + 1], dim=-1)

            logging.info("data_name:{}, data_num:{}, distance:{}, direction:{}".
                         format(data_name, data_num, Distance_square[data_num], Distance_square_cos[data_num]))

            data_num += 1

    logging.info("success_adv_num:{}, all_data_num:{}, accuracy:{}".
                 format(suc_num, FL_params.target_num * (FL_params.global_epoch - 1),
                        suc_num / (FL_params.target_num * (FL_params.global_epoch - 1))))

    return Distance_square, Distance_square_cos


def adv_MIA():

    # Parameters init
    FL_params = Arguments()

    # Generate the initial global model
    init_GM = model_init(FL_params.data_name)

    # Generate the loaders
    client_loaders, train_loader, test_loader = data_init(FL_params)

    # FL training
    # all_GMs: list of global models -> [M0, M1 ... Mt] in the paper
    # all_LMs: list of local models
    all_GMs, all_LMs = FL_Train(init_GM, client_loaders, test_loader, FL_params)

    # Generate the targeted loader
    data_loader_tgt = client_loaders[FL_params.target_client]

    # Run adversarial robustness estimation,
    # get the distance and direction data -> D^{attacker}_{train}, D^{attacker}_{test} in the paper
    distance_train, direction_train = \
        robustness_estimation(all_GMs, data_loader_tgt, train_loader, "train", FL_params)
    distance_test, direction_test = \
        robustness_estimation(all_GMs, test_loader, train_loader, "test", FL_params)

    distance_train = distance_train.cpu().numpy()
    direction_train = direction_train.cpu().numpy()
    distance_test = distance_test.cpu().numpy()
    direction_test = direction_test.cpu().numpy()

    # Save the distance for testing MIA better
    robustness_path = "./result/cifar10/"
    if not os.path.exists(robustness_path):
        os.makedirs(robustness_path)
    np.save(robustness_path + "CIFAR10_distance_train_" + str(FL_params.ADV_TYPE) + "_" + str(
        FL_params.global_epoch - 1) + "_" + str(FL_params.target_num) + ".npy", distance_train)
    np.save(robustness_path + "CIFAR10_distance_test_" + str(FL_params.ADV_TYPE) + "_" + str(
        FL_params.global_epoch - 1) + "_" + str(FL_params.target_num) + ".npy", distance_test)
    np.save(robustness_path + "CIFAR10_direction_train_" + str(FL_params.ADV_TYPE) + "_" + str(
        FL_params.global_epoch - 1) + "_" + str(FL_params.target_num) + ".npy", direction_train)
    np.save(robustness_path + "CIFAR10_direction_test_" + str(FL_params.ADV_TYPE) + "_" + str(
        FL_params.global_epoch - 1) + "_" + str(FL_params.target_num) + ".npy", direction_test)

    # MIA function and test
    MIA_function(distance_train, distance_test, direction_train, direction_test, FL_params)


if __name__ == "__main__":

    adv_MIA()
