import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import datasets, transforms
import numpy as np
from sklearn.model_selection import train_test_split
from torch.utils.data import Dataset, TensorDataset
from torch.utils.data import DataLoader


def model_init(data_name):
    if data_name not in ['cifar10', 'purchase100']:
        raise TypeError('data_name should be a string, including cifar10 and purchase100. ')

    if data_name == 'purchase100':
        model = Net_purchase100()
    if data_name == 'cifar10':
        model = Net_cifar10()

    return model


class Net_cifar10(nn.Module):
    def __init__(self):
        super(Net_cifar10, self).__init__()
        self.conv1 = nn.Conv2d(3, 6, 5)
        self.pool = nn.MaxPool2d(2, 2)
        self.conv2 = nn.Conv2d(6, 16, 5)
        self.fc1 = nn.Linear(16 * 5 * 5, 120)
        self.fc2 = nn.Linear(120, 84)
        self.fc3 = nn.Linear(84, 10)

    def forward(self, x):
        x = self.pool(F.relu(self.conv1(x)))
        x = self.pool(F.relu(self.conv2(x)))
        x = x.view(-1, 16 * 5 * 5)
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = self.fc3(x)
        return x


class Net_purchase100(nn.Module):
    def __init__(self):
        super(Net_purchase100, self).__init__()
        self.fc1 = nn.Linear(600, 1024)
        self.fc2 = nn.Linear(1024, 512)
        self.fc3 = nn.Linear(512, 256)
        self.fc4 = nn.Linear(256, 128)
        self.fc5 = nn.Linear(128, 100)

    def forward(self, x):
        x = torch.tanh(self.fc1(x))
        x = torch.tanh(self.fc2(x))
        x = torch.tanh(self.fc3(x))
        x = torch.tanh(self.fc4(x))
        x = torch.relu(self.fc5(x))
        return x


def data_init(FL_params):
    kwargs = {'num_workers': 0, 'pin_memory': True} if FL_params.cuda_state else {}
    trainset, testset = data_set(FL_params.data_name)

    train_loader = DataLoader(trainset, batch_size=FL_params.local_batch_size, shuffle=True, **kwargs)
    test_loader = DataLoader(testset, batch_size=FL_params.test_batch_size, shuffle=True, drop_last=True, **kwargs)

    # split the trainset evenly into N_client_max parts and save them for each clients
    split_index = [int(trainset.__len__() / FL_params.N_client_max)] * (FL_params.N_client_max - 1)
    split_index.append(
        int(trainset.__len__() - int(trainset.__len__() / FL_params.N_client_max) * (FL_params.N_client_max - 1)))
    client_dataset = torch.utils.data.random_split(trainset, split_index)

    # build clients' dataloader
    # note that we only need to build dataloader for the clients participated in the training, so the number is N_client
    client_loaders = []
    for ii in range(FL_params.N_client):
        client_loaders.append(
            DataLoader(client_dataset[ii], FL_params.local_batch_size, shuffle=True, drop_last=True, **kwargs))

    return client_loaders, train_loader, test_loader


def data_set(data_name):

    if data_name == 'cifar10':
        transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])

        trainset = datasets.CIFAR10(root='./data/cifar', train=True, download=True, transform=transform)
        testset = datasets.CIFAR10(root='./data/cifar', train=False, download=True, transform=transform)

    if data_name == 'purchase100':
        data = np.load("./data/purchase/purchase100.npz")

        xx = data["features"]
        yy = data["labels"]

        X_train, X_test, y_train, y_test = train_test_split(xx, yy, test_size=0.2, random_state=42)

        X_train_tensor = torch.Tensor(X_train).type(torch.FloatTensor)
        X_test_tensor = torch.Tensor(X_test).type(torch.FloatTensor)
        y_train_tensor = torch.Tensor(y_train).type(torch.LongTensor)
        y_test_tensor = torch.Tensor(y_test).type(torch.LongTensor)

        trainset = TensorDataset(X_train_tensor, y_train_tensor)
        testset = TensorDataset(X_test_tensor, y_test_tensor)

    return trainset, testset
