import torch


def is_adversarial(model, perturbed, adv_label, FL_params):
    """
    If the label after disturbance is the same as original one,
    it is judged as the adversarial sample (return True)
    """
    predict_label = torch.argmax(model(perturbed))
    target_label = torch.tensor([adv_label]).to(FL_params.device)
    return predict_label == target_label


def clip_image(image, clip_min, clip_max, FL_params):

    return torch.min(torch.max(
                torch.tensor(clip_min, device=FL_params.device), image),
                torch.tensor(clip_max, device=FL_params.device))


def binary_search(model, x_0, x_random, adv_label, FL_params, tol=0.00001):
    """
    Binary search to project adversarial sample onto the decision boundary
    :param model: targeted model
    :param x_0: targeted sample
    :param x_random: the sample after disturbance
    :param adv_label: targeted adversarial label
    :param FL_params: set of main function arguments
    :param tol: binary threshold
    :return adv: the sample at the boundary
    """
    adv = x_random
    cln = x_0

    while True:

        mid = (cln + adv) / 2.0

        if is_adversarial(model, mid, adv_label, FL_params):
            adv = mid
        else:
            cln = mid

        if torch.norm(adv - cln).cpu().numpy() < tol:
            break

    return adv


def initialize(model, x_sample, y_sample, tgt_sample, adv_label, FL_params):

    adv = binary_search(model, x_sample, tgt_sample, adv_label, FL_params)

    # l_distance = torch.norm(x_sample - adv, p=FL_params.attack_norm)

    # print('ori_label={}, pred_ori_label={}, adv_label={}, pred_adv_label={}, l_distance={}'
    #              .format(y_sample, torch.argmax(model(x_sample)), adv_label, torch.argmax(model(adv)), l_distance))

    # assert y_sample == torch.argmax(model(x_sample))
    # assert adv_label == torch.argmax(model(adv))
    #
    # print("The first data has been initialized !")

    return adv

