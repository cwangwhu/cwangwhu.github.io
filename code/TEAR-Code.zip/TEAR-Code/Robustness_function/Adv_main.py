import torch
import copy

from Robustness_function.Advinit_white import deepfool_initialize
from Robustness_function.Advinit_white import cw_initialize
from Robustness_function.Advinit_black import initialize, binary_search, is_adversarial


def objective_function(model, x_adv, x_ori, adv_label, distance, FL_params):
    """
    * Set the objective function,
     which is the opposite of the cosine similarity of the direction of normal vector and the direction of adversarial perturbation

    :param model: targeted model
    :param x_adv: the sample at the boundary
    :param x_ori: targeted sample
    :param adv_label: targeted adversarial label
    :param distance: adversarial robustness of the previous step
    :param FL_params: set of main function arguments
    :return cos: loss -> [-1, 0]
    """
    # compute the direction of adversarial perturbation
    x_sub = x_adv - x_ori
    x_sub = x_sub.view(-1)
    x_sub = x_sub / torch.norm(x_sub, p=FL_params.adv_norm)

    # compute the direction of normal vector
    grad_xadv = gradient_estimation_boundary(model, x_adv, adv_label, distance, FL_params)
    grad_xadv = grad_xadv.view(-1)
    grad_xadv = grad_xadv / torch.norm(grad_xadv, p=FL_params.adv_norm)

    cos = -torch.cosine_similarity(x_sub, grad_xadv, dim=-1)

    return cos


def gradient_estimation_boundary(model, sample, adv_label, distance, FL_params):
    """
    Monte-Carlo for the gradient estimation of the sample at the boundary,
    which represents the normal vector of the boundary

    :param model: targeted model
    :param sample: the sample at the boundary
    :param adv_label: targeted adversarial label
    :param distance: adversarial robustness of the previous step
    :param FL_params: set of main function arguments
    :return gradf: the normal vector of the boundary
    """
    if FL_params.data_name == "cifar10":
        sample = sample.squeeze(0)

    # Number of disturbances
    num_evals = FL_params.num_evals_boundary
    # Set the step length
    delta = 1 / len(sample.shape) * distance

    # Set the perturbation
    noise_shape = [num_evals] + list(sample.shape)
    rv = torch.randn(*noise_shape, device=FL_params.device)
    if FL_params.data_name == "purchase100":
        rv = rv / torch.sqrt(torch.sum(rv ** 2, dim=1, keepdim=True))
    if FL_params.data_name == "cifar10":
        rv = rv / torch.sqrt(torch.sum(rv ** 2, dim=(1, 2, 3), keepdim=True))

    # Add the perturbation
    perturbed = sample + delta * rv
    # perturbed = clip_image(perturbed, FL_params.clip_min, FL_params.clip_max, FL_params)
    # rv = (perturbed - sample) / delta

    # Model prediction
    decisions = decision_function(model, perturbed, adv_label, FL_params)
    decision_shape = [len(decisions)] + [1] * len(sample.shape)
    fval = 2 * decisions.reshape(decision_shape) - 1.0

    # get the direction of normal vector
    if torch.mean(fval) == torch.tensor(1.0):
        gradf = torch.mean(rv, dim=0)
    elif torch.mean(fval) == torch.tensor(-1.0):
        gradf = - torch.mean(rv, dim=0)
    else:
        fval -= torch.mean(fval)
        gradf = torch.mean(fval * rv, dim=0)

    return gradf


def decision_function(model, images, adv_label, FL_params):
    """
    Decision function output 1 on the desired side of the boundary,
	0 otherwise
    """
    predict_label = torch.argmax(model(images), dim=1).reshape(len(images), 1)

    target_label = torch.zeros((len(images), 1), device=FL_params.device)
    for i in range((len(images))):
        target_label[i, 0] = torch.tensor([adv_label])

    return predict_label == target_label


def adv_attack(model, x_sample, y_sample, tgt_sample, adv_label, FL_params):
    """
    The main function of our adversarial robustness estimation

    :param model: targeted model -> $M$ in the paper
    :param x_sample: targeted sample -> $\mathbf{x}$ in the paper
    :param y_sample: the label of targeted sample
    :param tgt_sample: the adversarial sample randomly generated -> $\tilde{\mathbf{x}}_0$ in the paper
    :param adv_label: targeted adversarial label -> yk in the paper
    :param FL_params: set of main function arguments
    :return distance_value: distance between the generated adversarial sample and the targeted sample
    :return distance_direction: direction of the vector between the generated adversarial sample and the targeted sample
    :return is_adv: if the generated sample is adversarial
    """
    if FL_params.data_name not in ['cifar10', 'purchase100']:
        raise TypeError('data_name should be a string, including cifar10 and purchase100. ')
    if FL_params.ADV_TYPE not in ['DEEPFOOL', 'CW', 'BLACKBOX']:
        raise TypeError('ATTACK_TYPE should be a string, including DEEPFOOL, CW, BLACKBOX.')

    # DEEPFOOL method
    if FL_params.ADV_TYPE == "DEEPFOOL":
        deepfool_adv, distance_value, is_adv = deepfool_initialize(model, x_sample, y_sample, adv_label, FL_params)
        deepfool_adv = deepfool_adv.to(FL_params.device)
        distance_direction = ((deepfool_adv - x_sample) / distance_value).view(-1)

        return distance_value, distance_direction, is_adv

    # CW method
    if FL_params.ADV_TYPE == "CW":
        cw_adv, distance_value, is_adv = cw_initialize(model, x_sample, y_sample, adv_label, FL_params)
        cw_adv = cw_adv.to(FL_params.device)
        distance_direction = ((cw_adv - x_sample) / distance_value).view(-1)

        return distance_value, distance_direction, is_adv

    # Black-box method
    if FL_params.ADV_TYPE == "BLACKBOX":

        # get an adversarial sample randomly generated at the decision boundary
        adv_init = initialize(model, x_sample, y_sample, tgt_sample, adv_label, FL_params)
        adv_update = adv_init
        ori_sample = x_sample

        distance_init = torch.norm(adv_init - ori_sample, p=FL_params.adv_norm)
        distance_value = distance_init
        distance_direction = (adv_init - ori_sample) / distance_value

        is_adv = 0

        # print("x0 prediction: {}".format(F.softmax(model(adv_init), dim=-1)))
        # print("x0 cos similarity: {}".format(loss_cos(model, adv_init, x_sample, adv_label, distance_init, FL_params)))

        # main loop
        for adv_epoch in range(FL_params.adv_iter):

            # adv_sample -> $\bar{\mathbf{x}}$ in the paper
            adv_sample = copy.deepcopy(adv_update)
            distance = copy.deepcopy(distance_value)

            # Get the loss and compute the gradient of the objective function directly
            adv_sample.requires_grad = True
            loss = objective_function(model, adv_sample, ori_sample, adv_label, distance, FL_params)
            loss.backward()
            grads = adv_sample.grad
            grads = grads / torch.norm(grads, p=FL_params.adv_norm)
            adv_sample.requires_grad = False

            # Update the sample
            adv_sample -= FL_params.adv_lr * grads

            # Ensure that the updated sample always belongs to the targeted label
            beta = FL_params.beta_init
            while not is_adversarial(model, adv_sample, adv_label, FL_params):
                beta += FL_params.beta_step_size
                adv_sample += beta * (adv_sample-ori_sample) / \
                              torch.norm(adv_sample-ori_sample, p=FL_params.adv_norm)
                if beta > FL_params.beta_max:
                    break

            # print("is_adv1?", torch.argmax(model(adv_sample)))
            # print("updated sample prediction: ", F.softmax(model(adv_sample), dim=-1))
            # **** We got the adversarial sample from this update ****

            # Binary search
            adv_sample = binary_search(model, ori_sample, adv_sample, adv_label, FL_params)
            # print("is_adv2?", torch.argmax(model(adv_sample)))
            # print("binary search sample prediction: ", F.softmax(model(adv_sample), dim=-1))

            if FL_params.adv_with_test:
                losses_now = objective_function(model, adv_sample, ori_sample, adv_label, distance, FL_params)
                print("adv_update: epoch={}, adv_label={}, loss={}, distance={}".format(adv_epoch + 1, torch.argmax(model(adv_sample)), losses_now, distance_value))

            # distance_value -> $r$ in the paper
            # distance_direction -> direction of adversarial perturbation
            distance_value = torch.norm(adv_sample - ori_sample, p=FL_params.adv_norm)
            distance_direction = ((adv_sample - ori_sample) / distance_value).view(-1)

            adv_update = copy.deepcopy(adv_sample)
            if is_adversarial(model, adv_update, adv_label, FL_params):
                is_adv = 1

        print("blackbox_attack: ori_sample={}, adv_label={}, distance={}".format(y_sample.item(), adv_label.item(), distance_value.item()))

        return distance_value, distance_direction, is_adv


