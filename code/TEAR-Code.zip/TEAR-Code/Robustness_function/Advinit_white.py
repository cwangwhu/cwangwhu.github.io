import torch
from AdvBox.adversarialbox.adversary import Adversary
from AdvBox.adversarialbox.attacks.deepfool import DeepFoolAttack
from AdvBox.adversarialbox.models.pytorch import PytorchModel
from AdvBox.adversarialbox.attacks.cw2_pytorch import CW_L2


def deepfool_initialize(model, x_sample, y_sample, adv_label, FL_params):

    model = model.to(FL_params.device)
    model = model.eval()

    XX_target = None
    if FL_params.data_name == 'purchase100':
        XX_target = x_sample.unsqueeze(0).to(FL_params.device_cpu)
    if FL_params.data_name == 'cifar10':
        XX_target = x_sample.to(FL_params.device_cpu)
    YY_target = None

    M_tgt = PytorchModel(model, None, bounds=(FL_params.clip_min, FL_params.clip_max), channel_axis=1)

    deepfool_attacker = DeepFoolAttack(M_tgt)

    attacker_config = {"iterations": 1000, "overshoot": 0.02}

    adversary = Adversary(XX_target, YY_target)
    adversary.set_target(is_targeted_attack=True, target_label=adv_label.item())

    adversary = deepfool_attacker(adversary, **attacker_config)

    # flag for the successful adv-attack
    suc = 0
    if adversary.is_successful():
        suc = 1
        adv_s = adversary.adversarial_example[0]
        adv_s = torch.from_numpy(adv_s).unsqueeze(0)

        d = torch.norm(XX_target - adv_s, p=FL_params.attack_norm)

    else:
        adv_s = adversary.bad_adversarial_example[0]
        adv_s = torch.from_numpy(adv_s).unsqueeze(0)

        d = torch.norm(XX_target - adv_s, p=FL_params.attack_norm)

    print("deepfool_attack: ori_sample={}, adv_label={}, distance={}".
          format(y_sample, adversary.adversarial_label, d))

    return adv_s, d, suc


def cw_initialize(model, x_sample, y_sample, adv_label, FL_params):

    model = model.to(FL_params.device)
    model = model.eval()
    XX_target = x_sample.unsqueeze(0).to(FL_params.device_cpu)
    YY_target = None

    M_tgt = PytorchModel(model, None, bounds=(FL_params.clip_min, FL_params.clip_max), channel_axis=1)

    cw_attacker = CW_L2(M_tgt)

    attacker_config = {"num_labels": FL_params.class_num, "max_iterations": 1000, "binary_search_steps": 10, "initial_const": 1.0, "k": 0}

    adversary = Adversary(XX_target, YY_target)
    adversary.set_target(is_targeted_attack=True, target_label=adv_label.item())

    adversary = cw_attacker(adversary, **attacker_config)

    # flag for the successful adv-attack
    suc = 0

    if adversary.is_successful():
        suc = 1
        adv_s = adversary.adversarial_example[0]

        if FL_params.data_name == 'purchase100':
            adv_s = torch.from_numpy(adv_s).unsqueeze(0)
        if FL_params.data_name == 'cifar10':
            adv_s = torch.from_numpy(adv_s)

        d = torch.norm(XX_target - adv_s, p=FL_params.attack_norm)

    else:
        adv_s = adversary.bad_adversarial_example[0]

        if FL_params.data_name == 'purchase100':
            adv_s = torch.from_numpy(adv_s).unsqueeze(0)
        if FL_params.data_name == 'cifar10':
            adv_s = torch.from_numpy(adv_s)

        d = torch.norm(XX_target - adv_s, p=FL_params.attack_norm)

    print("cw_attack: ori_sample={}, adv_label={}, distance={}".
          format(y_sample, adversary.adversarial_label, d))

    return adv_s, d, suc

