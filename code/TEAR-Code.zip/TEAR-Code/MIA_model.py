import numpy as np
import random
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from xgboost import XGBClassifier


def MIA_function(train_distance, test_distance, train_direction, test_direction, FL_params):

    data_distance = np.vstack([train_distance, test_distance])
    data_direction = np.vstack([train_direction, test_direction])

    # Set the labels: members->1 non-members->0
    y = np.hstack([np.ones(FL_params.target_num), np.zeros(FL_params.target_num)])

    # random_state can set to a certain value for a better performance or do averaging
    random_state = random.randint(0, 200)
    # Set net parameters, you can change them for a better performance,
    # we hope for a better "both record"
    # dis means distance net, dir means direction net
    max_depth_dis = 6
    min_child_weight_dis = 1.0
    scale_pos_weight_dis = 1.0
    max_depth_dir = 6
    min_child_weight_dir = 1.0
    scale_pos_weight_dir = 1.0

    # Split the data into training data and testing data
    X_train_distance, X_test_distance, X_train_direction, X_test_direction, y_train, y_test = \
        train_test_split(data_distance, data_direction, y, test_size=0.2, random_state=random_state)

    y_pred_train = np.zeros(len(y_train))
    y_pred_test = np.zeros(len(y_test))

    # Train distance net
    clf_distance = XGBClassifier(learning_rate=0.1, n_estimators=1000,
                                 max_depth=max_depth_dis, min_child_weight=min_child_weight_dis, scale_pos_weight=scale_pos_weight_dis)
    clf_distance.fit(X_train_distance, y_train,
                     eval_set=[(X_test_distance, y_test)], early_stopping_rounds=20, verbose=False)

    p_train_distance = clf_distance.predict(X_train_distance)
    p_test_distance = clf_distance.predict(X_test_distance)

    print("Distance record: acc_train:{}, acc_test:{}, precision:{}, recall:{}, f1_score:{}".
          format(accuracy_score(y_train, p_train_distance), accuracy_score(y_test, p_test_distance),
                 precision_score(y_test, p_test_distance, pos_label=1),
                 recall_score(y_test, p_test_distance, pos_label=1),
                 f1_score(y_test, p_test_distance, pos_label=1)))

    # Train direction net
    clf_direction = XGBClassifier(learning_rate=0.1, n_estimators=1000,
                                  max_depth=max_depth_dir, min_child_weight=min_child_weight_dir, scale_pos_weight=scale_pos_weight_dir)
    clf_direction.fit(X_train_direction, y_train,
                      eval_set=[(X_test_direction, y_test)], early_stopping_rounds=20, verbose=False)

    p_train_direction = clf_direction.predict(X_train_direction)
    p_test_direction = clf_direction.predict(X_test_direction)

    print("Direction record: acc_train:{}, acc_test:{}, precision:{}, recall:{}, f1_score:{}".
          format(accuracy_score(y_train, p_train_direction), accuracy_score(y_test, p_test_direction),
                 precision_score(y_test, p_test_direction, pos_label=1),
                 recall_score(y_test, p_test_direction, pos_label=1),
                 f1_score(y_test, p_test_direction, pos_label=1)))

    for ii in range(len(y_train)):
        if p_train_distance[ii] == 0 and p_train_direction[ii] == 0:
            y_pred_train[ii] = 0
        else:
            y_pred_train[ii] = 1
    for ii in range(len(y_test)):
        if p_test_distance[ii] == 0 and p_test_direction[ii] == 0:
            y_pred_test[ii] = 0
        else:
            y_pred_test[ii] = 1

    # Distance record means the model performance only used distance data
    # Direction record means the model performance only used direction data
    # Both record means the model performance used both distance and direction data -> test results in the paper
    print("Both record: acc_train:{}, acc_test:{}, precision:{}, recall:{}, f1_score:{}".
          format(accuracy_score(y_train, y_pred_train), accuracy_score(y_test, y_pred_test),
                 precision_score(y_test, y_pred_test, pos_label=1), recall_score(y_test, y_pred_test, pos_label=1),
                 f1_score(y_test, y_pred_test, pos_label=1)))


