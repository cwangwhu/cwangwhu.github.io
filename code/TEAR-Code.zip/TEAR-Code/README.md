# Temporal Evolution of Adversarial Robustness (TEAR) 

Code for TEAR : Exploring Temporal Evolution of Adversarial Robustness for Membership Inference Attacks against Practical Federated Learning

## Getting Started
To run this repository, we kindly advise you to install python 3.7 and PyTorch 1.9.1
with Anaconda. You may download Anaconda and read the installation instruction on the official
website (https://www.anaconda.com/download/).
Create a new environment and install PyTorch and torchvision on it:

```shell
conda create --name xxx - pytorch python == 3.7
conda activate xxx - pytorch
conda install pytorch == 1.9.1
conda install torchvision -c pytorch
```

Install other requirements:
```shell
pip install numpy scikit-learn matplotlib xgboost os random copy 
```

Besides, you need to install AdvBox. You may read the installation instruction on the website (https://github.com/advboxes/AdvBox).


## Running experiments
**Running experiments on Purchase100.** 

(1) Download the dataset on the website (https://www.kaggle.com/c/acquire-valued-shoppers-challenge/data), and put it in the './data/purchase' folder.

(2) Run the data process code and get the data:
```shell
python ./data/purchase/data_preprocess.py
```

(3) Run the PyTorch code:
```shell
python MIA_main_purchase.py
```

**Running experiments on CIFAR-10.** 

Run the PyTorch code (data will be downloaded automatically):
```shell
python MIA_main_cifar.py
```

## Contents
- **data/:** 
Contains the data of purchase100 and CIFAR-10 dataset.

- **FL_model_data_init.py:**
Initialization of data and model in FL.

- **FL_base_function.py:**
Some base functions in FL.

- **Robustness_function/Advinit_white.py:**
The function of deepfool and cw adversarial attack.

- **Robustness_function/Advinit_black.py:**
The function of our black-box adversarial attack, including generation of initial sample points and binary search.

- **Robustness_function/Adv_main.py:**
The function of quantifying adversarial robustness. We introduce the framework and process of our black-box method, including normal vector estimation, example update and so on.

- **MIA_model.py:**
The function of inference model construction and membership inference.

- **MIA_main_purchase.py:**
The main function of MIA (both black-box and white-box) for purchase100 dataset.

- **MIA_main_cifar.py:**
The main function of MIA (both black-box and white-box) for CIFAR-10 dataset.
