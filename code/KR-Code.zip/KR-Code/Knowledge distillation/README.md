# Knowledge Representation of Training Data with Adversarial Examples Supporting Decision Boundary 

Code for Knowledge Representation of Training Data with Adversarial Examples Supporting Decision Boundary

## Getting Started
To run this repository, we kindly advise you to install python 3.7 and PyTorch 1.8.1 with Anaconda. You may download Anaconda and read the installation instruction on the official website (https://www.anaconda.com/download/).
Create a new environment and install PyTorch and torchvision on it:

```shell
conda create --name xxx - pytorch python == 3.7
conda activate xxx - pytorch
conda install pytorch == 1.8.1
conda install torchvision -c pytorch
```

Install other requirements:
```shell
pip install numpy scikit-learn matplotlib os random copy time tqdm argparse
```

## Running experiments
**Running experiments of knowledge distillation.**

(1) Download the TinyImageNet dataset on the website (http://cs231n.stanford.edu/tiny-imagenet-200.zip), and put it in the './data/TinyImageNet/' folder (CIFAR10 dataset will be downloaded automatically).

(2) Run the teacher training code and get teacher model:
```shell
python teacher_train.py
```
For CIFAR10 dataset, we use the teacher model directly by Heo et al.(2019) on the website (https://github.com/bhheo/BSS_distillation). We only need to run this code for TinyImageNet dataset.

(3) Run the adversarial example generation code and generate adversarial examples with MinAD combined with KRM for knowledge distillation:
```shell
python knowledge_matrix.py --data_name $DATA_NAME --train_batch $TRAIN_BATCH --feature_mode 'MinAD_KRM' --attack_lr_begin $ATTACK_LR_BEGIN --attack_lr_end $ATTACK_LR_END
```
> `data_name` - Dataset used.\
> `train_batch` - Batch size used for training.\
> `feature_mode` - Type of adversarial example generation, choice=['MinAD', 'MinAD_KRM'].\
> `attack_lr_begin` - Initial learning rate of MinAD.\
> `attack_lr_end` - Threshold of learning rate of MinAD.

(4) Run the knowledge distillation code and test:
```shell
python knowledge_distillation.py --data_name $DATA_NAME --train_batch $TRAIN_BATCH --attack_size $ATTACK_SIZE --feature_mode $FEATURE_MODE --attack_lr_begin $ATTACK_LR_BEGIN --attack_lr_end $ATTACK_LR_END
```
> `data_name` - Dataset used.\
> `train_batch` - Batch size used for training.\
> `attack_size` - Number of attack samples per train batch.\
> `feature_mode` - Type of adversarial example generation, choice=['MinAD', 'MinAD_KRM'].\
> `attack_lr_begin` - Initial learning rate of MinAD.\
> `attack_lr_end` - Threshold of learning rate of MinAD.

## Contents
- **model_data_init.py:**
Initialization of dataset and model (teacher and student).

- **model_train.py:**
The function of training teacher model.

- **adv_generation.py:**
The function of adversarial example generation. We introduce our MinAD and generate embeddings for distillation.

- **knowledge_matrix.py:**
The function of knowledge representation generation. We introduce KRM and generate KRM with MinAD.

- **knowledge_distillation.py:**
The function of knowledge distillation, including the process and test of knowledge distillation.

- **params.py:**
Introduction of parameters we used.

- **./model/resnet.py:**
Network building of resnet.
