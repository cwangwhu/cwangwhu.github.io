import os
import numpy as np
from tqdm import tqdm
import torch
import torchvision
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F

from model_data_init import data_init
from models import *
from params import args_parse


# *** this file is only for pre-training of teacher model !!! *** #

# for training
def train_epoch(args, loader, model, lr_schedule=None, epoch_i=None, opt=None):

    train_loss = 0; train_acc = 0; train_n = 0; i = 0

    for batch_idx, (data, target) in enumerate(tqdm(loader)):
        X, y = data.to(args.device), target.to(args.device)
        yp = model(X)

        loss = nn.CrossEntropyLoss()(yp, y)

        lr = lr_schedule(epoch_i + (i + 1) / len(loader))
        opt.param_groups[0].update(lr=lr)
        opt.zero_grad()
        loss.backward()
        opt.step()

        train_loss += loss.item() * y.size(0)
        train_acc += (yp.max(1)[1] == y).sum().item()
        train_n += y.size(0)
        i += 1

    return train_loss / train_n, train_acc / train_n


# for testing
def test_epoch(args, loader, model):

    test_loss = 0; test_acc1 = 0; test_acc5 = 0; test_n = 0

    with torch.no_grad():
        for batch_idx, (data, target) in enumerate(loader):

            X, y = data.to(args.device), target.to(args.device)
            yp = model(X)
            loss = nn.CrossEntropyLoss()(yp, y)
            test_loss += loss.item()*y.size(0)
            # top1 acc
            test_acc1 += (yp.max(1)[1] == y).sum().item()

            # top5 acc
            maxk = max((1, 5))
            y_resize = y.view(-1, 1)
            _, pred = yp.topk(maxk, 1, True, True)
            test_acc5 += torch.eq(pred, y_resize).sum().float().item()

            test_n += y.size(0)

    return test_loss / test_n, test_acc1 / test_n, test_acc5 / test_n


# main function
def train(args):

    train_loader, test_loader = data_init(args.data_name, args.train_batch)

    model = torchvision.models.resnet50(pretrained=False).to(args.device)
    model.load_state_dict(torch.load(f"./results/resnet50.pt"))

    num_epochs = 20

    print("Teacher model training...")
    optimizer = optim.SGD(model.parameters(), lr=0.1, momentum=0.9, weight_decay=5e-4)
    lr_schedule = lambda t: np.interp([t], [0, num_epochs * 2 // 5, num_epochs * 4 // 5, num_epochs], [0, 0.1, 0.01, 0])[0]

    for t in range(num_epochs):
        lr = lr_schedule(t)
        model.train()
        train_loss, train_acc = train_epoch(args, train_loader, model, lr_schedule=lr_schedule, epoch_i=t, opt=optimizer)
        model.eval()
        test_loss, test_acc1, test_acc5 = test_epoch(args, test_loader, model)
        print(f'Epoch: {t}, Train Loss: {train_loss:.3f} Train Acc: {train_acc:.3f} Test Loss: {test_loss:.3f} Test Acc1: {test_acc1:.3f}, Test Acc5: {test_acc5:.3f},lr: {lr:.5f}')

    torch.save(model.state_dict(), f"{args.model_dir}/{num_epochs}_epoch.pt")


if __name__ == "__main__":

    parser = args_parse()
    args = parser.parse_args()

    # set teacher saving path
    model_dir = f"./results/Res50_Tiny"
    args.model_dir = model_dir
    if not os.path.exists(model_dir):
        os.makedirs(model_dir)
    print("Model Directory:", model_dir)

    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    args.device = device
    torch.cuda.set_device(device)
    print(device)

    torch.manual_seed(args.seed)

    train(args)


