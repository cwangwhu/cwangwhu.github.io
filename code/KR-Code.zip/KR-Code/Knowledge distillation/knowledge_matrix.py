import os
import numpy as np
from tqdm import tqdm
import torch

from model_data_init import data_init, model_init
from params import args_parse
from adv_generation import set_target, adv_attack


def get_data(args, loader):

    x_list = []
    i_list = []
    for i in range(args.num_class):
        x_list.append([])
        i_list.append([])

    # get all the data of each class
    for idb, (XX_tgt, YY_tgt) in enumerate(loader):
        for idx in range(len(YY_tgt)):
            yy_tgt = YY_tgt[idx]
            x_list[yy_tgt.item()].append(XX_tgt[idx])

    # get center point of each class
    x_center = torch.zeros(args.num_class, 3, 32, 32) \
        if args.data_name == 'CIFAR10' else torch.zeros(args.num_class, 3, 224, 224)

    for class_idx in range(args.num_class):
        l = x_list[class_idx]
        list_d = torch.zeros(len(l))

        for idl in tqdm(range(len(l))):
            sum_d = torch.tensor(0.)
            for jdl in range(len(l)):
                sum_d += torch.norm(l[idl] - l[jdl], p=2)
            list_d[idl] = sum_d

        mdx = int(torch.argmax(list_d))
        x = l[mdx]
        x_center[class_idx] = x
        # print('class:{}, list:{}, mdx:{}'.format(class_idx, list_d, mdx))

    x_center = np.array(x_center)
    np.set_printoptions(threshold=np.inf)
    # print('x_center.shape:', x_center.shape)
    np.save(f"{args.feature_dir}/train_center_point.npy", x_center)


def get_embeddings_black(args, x_list, loader, model):
    print("Getting MinAD_KRM embeddings...")

    # get adversarial target samples
    tgt_dir = f'./results/BSS_distillation_{args.data_name}/MinAD_tgt_list.npy'
    if not os.path.exists(tgt_dir):
        tgt_list = set_target(args.data_name, model, loader, args.num_class, args.device)
        tgt_list = tgt_list.detach().cpu().numpy()
        np.save(tgt_dir, tgt_list)
    tgt_list = np.load(tgt_dir)
    tgt_list = torch.from_numpy(tgt_list).to(args.device)

    adv_list = torch.zeros(args.num_class, 10, 3, 32, 32, device=args.device) \
        if args.data_name == 'CIFAR10' else torch.zeros(args.num_class, 10, 3, 224, 224, device=args.device)

    for yy in tqdm(range(len(x_list))):
        xx = torch.from_numpy(x_list[yy])
        xx = xx.unsqueeze(0).to(args.device)

        yy = torch.tensor([yy]).to(args.device)

        for class_idx in range(10):

            if args.data_name == "TinyImageNet":
                preds = model(xx).squeeze(0)
                adv_idx = torch.argsort(preds, descending=True)[class_idx + 1].item()
            else:
                adv_idx = class_idx

            adv_label = torch.tensor([adv_idx], device=args.device)
            if adv_label == yy:
                continue

            tgt = tgt_list[adv_idx]

            # logger.info('Black attack|| yy_label:{}, adv_label:{}, distance:{}'.
            #             format(yy, adv_label, torch.norm(tgt - xx, p=2)))

            # MinAD begins
            adv, _ = adv_attack(args, model, xx, yy, tgt, adv_label)

            adv_list[yy, class_idx] = adv.squeeze(0)

        torch.save(adv_list, f"{args.feature_dir}/train_{args.feature_mode}_advs.pt")

    # print(adv_list.shape)

    return adv_list


# python knowledge_matrix.py --data_name 'CIFAR10' --train_batch 256 --feature_mode 'MinAD_KRM' --attack_lr_begin 16 --attack_lr_end 0.2
# python knowledge_matrix.py --data_name 'TinyImageNet' --train_batch 64 --feature_mode 'MinAD_KRM' --attack_lr_begin 1280 --attack_lr_end 16
# *** main function for knowledge representation ***/
def get_knowledge(args):
    print("Beginning generating KRM ...")

    # 1. load the data
    train_loader, test_loader = data_init(args.data_name, args.train_batch)

    # 2. load the teacher
    t_net, _ = model_init(args.data_name, args.device)
    t_net.eval()

    # 3. get center point of each class
    if not os.path.exists(f"{args.feature_dir}/train_center_point.npy"):
        get_data(args, train_loader)

    x_train = np.load(f"{args.feature_dir}/train_center_point.npy")

    # 4. adversarial example generation
    train_adv = get_embeddings_black(args, x_train, train_loader, t_net)
    torch.save(train_adv, f"{args.feature_dir}/train_{args.feature_mode}_advs.pt")


if __name__ == "__main__":

    parser = args_parse()
    args = parser.parse_args()
    print(args)

    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    args.device = device
    torch.cuda.set_device(device)
    print(device)

    # set result saving path
    feature_dir = f"./results/km_data_{args.data_name}"
    args.feature_dir = feature_dir
    if not os.path.exists(feature_dir):
        os.makedirs(feature_dir)
    print("Feature Directory:", feature_dir)

    n_class = {"CIFAR10": 10, "TinyImageNet": 200}
    args.num_class = n_class[args.data_name]

    torch.manual_seed(args.seed)

    get_knowledge(args)

