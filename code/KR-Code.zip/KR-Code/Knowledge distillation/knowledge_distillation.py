import os
import time
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import torch.backends.cudnn as cudnn
from torch.autograd import Variable
from tqdm import tqdm

from model_data_init import data_init, model_init
from params import args_parse
from adv_generation import get_black_vulnerabilty, set_target


def train_once(args, train_loader, t_net, s_net, tgt_list, epoch):
    epoch_start_time = time.time()
    print('\nStage 1 Epoch: %d' % epoch)

    temperature = 3
    attack_size = args.attack_size

    # set optimizer
    optimizer = optim.SGD(s_net.parameters(), lr=0.1, momentum=0.9, weight_decay=1e-4)
    if args.train_epochs / 2 - 1 < epoch < args.train_epochs / 4 * 3:
        optimizer = optim.SGD(s_net.parameters(), lr=0.01, momentum=0.9, weight_decay=1e-4)
    elif epoch > args.train_epochs / 4 * 3 - 1:
        optimizer = optim.SGD(s_net.parameters(), lr=0.001, momentum=0.9, weight_decay=1e-4)

    ratio = max(3 * (1 - epoch / args.train_epochs), 0) + 1
    ratio_attack = max(2 * (1 - 4 / 3 * epoch / args.train_epochs), 0) + 0

    s_net.train()
    t_net.eval()

    train_loss = 0
    correct = 0
    total = 0

    # training student model
    for batch_idx, (inputs, targets) in enumerate(tqdm(train_loader)):
        inputs, targets = inputs.to(args.device), targets.to(args.device)

        batch_size1 = inputs.shape[0]

        optimizer.zero_grad()
        inputs, targets = Variable(inputs), Variable(targets)

        out_s = s_net(inputs)

        # Cross-entropy loss
        loss = nn.CrossEntropyLoss()(out_s[0: batch_size1, :], targets)
        with torch.no_grad():
            out_t = t_net(inputs)

        # KD loss
        loss += - ratio * (F.softmax(out_t/temperature, 1).detach() * F.log_softmax(out_s/temperature, 1)).sum() / batch_size1

        if ratio_attack > 0:

            condition1 = targets.data == out_t.sort(dim=1, descending=True)[1][:, 0].data
            condition2 = targets.data == out_s.sort(dim=1, descending=True)[1][:, 0].data
            attack_flag = condition1 & condition2

            if attack_flag.sum():
                # base sample selection
                attack_idx = attack_flag.nonzero().squeeze(1)
                if attack_idx.shape[0] > attack_size:
                    diff = (F.softmax(out_t[attack_idx,:], 1).data - F.softmax(out_s[attack_idx,:], 1).data) ** 2
                    distill_score = diff.sum(dim=1) - diff.gather(1, targets[attack_idx].data.unsqueeze(1)).squeeze()
                    attack_idx = attack_idx[distill_score.sort(descending=True)[1][:attack_size]]

                # target class sampling
                attack_class = out_t.sort(dim=1, descending=True)[1][:, 1][attack_idx].data
                class_score, class_idx = F.softmax(out_t, 1)[attack_idx, :].data.sort(dim=1, descending=True)
                class_score = class_score[:, 1:]
                class_idx = class_idx[:, 1:]

                rand_seed = 1 * (class_score.sum(dim=1) * torch.rand([attack_idx.shape[0]]).cuda()).unsqueeze(1)
                prob = class_score.cumsum(dim=1)
                for k in range(attack_idx.shape[0]):
                    for c in range(prob.shape[1]):
                        if (prob[k, c] >= rand_seed[k]).cpu().numpy():
                            attack_class[k] = class_idx[k, c]
                            break

                # forward and backward for adversarial samples
                data_ = inputs[attack_idx, :, :, :].data
                if args.feature_mode == "MinAD":
                    attacked_inputs = get_black_vulnerabilty(args, t_net, data_, tgt_list, attack_class)
                elif args.feature_mode == 'MinAD_KRM':
                    attacked_inputs_train = torch.load(f"{args.feature_dir}/train_{args.feature_mode}_advs.pt")
                    attacked_inputs_train = attacked_inputs_train.reshape(
                        attacked_inputs_train.shape[0]*attacked_inputs_train.shape[1], attacked_inputs_train.shape[2], attacked_inputs_train.shape[3], attacked_inputs_train.shape[4])
                    attacked_inputs = attacked_inputs_train
                else:
                    raise Exception("Unknown feature mode")

                batch_size2 = attacked_inputs.shape[0]
                attack_out_t = t_net(attacked_inputs)
                attack_out_s = s_net(attacked_inputs)

                # KD loss for Boundary Supporting Samples (BSS)
                loss += - ratio_attack * (F.softmax(attack_out_t / temperature, 1).detach() * F.log_softmax(attack_out_s / temperature, 1)).sum() / batch_size2

        loss.backward()
        optimizer.step()

        train_loss += loss.data.item()
        _, predicted = torch.max(out_s[0:batch_size1, :].data, 1)
        total += targets.size(0)
        correct += predicted.eq(targets.data).cpu().float().sum()
        b_idx = batch_idx

    print('Train \t Time Taken: %.2f sec' % (time.time() - epoch_start_time))
    print('Loss: %.3f | Acc: %.3f%% (%d/%d)' % (train_loss / (b_idx + 1), 100. * correct / total, correct, total))


def test(args, test_loader, net):
    epoch_start_time = time.time()
    net.eval()
    test_loss = 0
    correct1 = 0
    correct5 = 0

    total = 0
    for batch_idx, (inputs, targets) in enumerate(test_loader):
        inputs, targets = inputs.to(args.device), targets.to(args.device)

        inputs, targets = Variable(inputs), Variable(targets)
        outputs = net(inputs)
        loss = nn.CrossEntropyLoss()(outputs, targets)

        test_loss += loss.data.item()
        _, predicted = torch.max(outputs.data, 1)
        total += targets.size(0)

        # compute top1 acc
        correct1 += predicted.eq(targets.data).cpu().float().sum()

        # compute top5 acc
        maxk = max((1, 5))
        y_resize = targets.view(-1, 1)
        _, pred = outputs.topk(maxk, 1, True, True)
        correct5 += torch.eq(pred, y_resize).sum().float().item()

        b_idx= batch_idx

    print('Test \t Time Taken: %.2f sec' % (time.time() - epoch_start_time))
    print('Loss: %.3f | Top1 Acc: %.3f%% Top5 Acc: %.3f%%' % (test_loss/(b_idx+1), 100.*correct1/total, 100.*correct5/total))


# python knowledge_distillation.py --data_name 'CIFAR10' --train_batch 256 --attack_size 64 --feature_mode $feature_mode --attack_lr_begin 16 --attack_lr_end 0.2
# python knowledge_distillation.py --data_name 'TinyImageNet' --train_batch 64 --attack_size 32 --feature_mode $feature_mode --attack_lr_begin 1280 --attack_lr_end 16
# *** main function for knowledge distillation ***/
def distillation(args):

    # 1. load the data
    train_loader, test_loader = data_init(args.data_name, args.train_batch)

    # 2. load the teacher and student model
    t_net, s_net = model_init(args.data_name, args.device)

    # 3. knowledge distillation
    if args.feature_mode == "MinAD":
        tgt_dir = f'./results/BSS_distillation_{args.data_name}/MinAD_tgt_list.npy'
        # generate target adversarial samples
        if not os.path.exists(tgt_dir):
            tgt_list = set_target(args.data_name, t_net, train_loader, args.num_class, args.device)
            tgt_list = tgt_list.detach().cpu().numpy()
            np.save(tgt_dir, tgt_list)
        tgt_list = np.load(tgt_dir)
        tgt_list = torch.from_numpy(tgt_list).to(args.device)
    else:
        tgt_list = None

    for epoch in range(1, args.train_epochs + 1):
        train_once(args, train_loader, t_net, s_net, tgt_list, epoch)
        test(args, test_loader, s_net)

    # 4. save the model
    state = {
        'net': s_net,
        'epoch': args.train_epochs,
    }
    torch.save(state, f"{args.res_folder}/{args.feature_mode}_{args.train_epochs}epoch_{args.train_batch}_{args.attack_size}.t7")


if __name__ == "__main__":

    parser = args_parse()
    args = parser.parse_args()
    print(args)

    # set model saving path
    res_folder = f'./results/BSS_distillation_{args.data_name}'
    args.res_folder = res_folder
    if not os.path.exists(res_folder):
        os.makedirs(res_folder)
    print("Model Directory:", res_folder)

    # set result saving path
    feature_dir = f"./results/km_data_{args.data_name}"
    args.feature_dir = feature_dir
    if not os.path.exists(feature_dir):
        os.makedirs(feature_dir)
    print("Feature Directory:", feature_dir)

    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    if torch.cuda.is_available():
        cudnn.benchmark = True
    args.device = device
    torch.cuda.set_device(device)
    print(device)

    n_class = {"CIFAR10": 10, "TinyImageNet": 200}
    args.num_class = n_class[args.data_name]

    torch.manual_seed(args.seed)

    distillation(args)

