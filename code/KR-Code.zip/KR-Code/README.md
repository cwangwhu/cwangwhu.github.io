# Knowledge Representation of Training Data with Adversarial Examples Supporting Decision Boundary 

Code for Knowledge Representation of Training Data with Adversarial Examples Supporting Decision Boundary

## Getting Started
To run this repository, we kindly advise you to install python 3.7 and PyTorch 1.8.1 with Anaconda. You may download Anaconda and read the installation instruction on the official website (https://www.anaconda.com/download/).
Create a new environment and install PyTorch and torchvision on it:

```shell
conda create --name xxx - pytorch python == 3.7
conda activate xxx - pytorch
conda install pytorch == 1.8.1
conda install torchvision -c pytorch
```

Install other requirements:
```shell
pip install numpy scikit-learn matplotlib os random copy time tqdm argparse
```

## Running experiments
For details about each case, see README in the corresponding folder

## Contents
- **dataset_inference/:**
Function of the dataset inference case.
- **IPGuard/:**
Function of the IPGuard case.
- **knowledge_distillation/:**
Function of the knowledge distillation case.

