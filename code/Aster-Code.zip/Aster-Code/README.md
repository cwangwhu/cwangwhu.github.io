# Aster
Source code repo for Aster - an MIA works under black-box scenario.

You need to unzip /data/mnist/mnist.zip and the zip files in /target_models manually to run Evaluate.py.
