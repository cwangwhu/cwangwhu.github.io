# -*- coding: utf-8 -*-

import os
import numpy as np
from .models import Build_Reference_Models, Build_Suspect_Models
from sklearn import metrics
import pickle
from sklearn.ensemble import RandomForestClassifier

np.random.seed(0)

def Train_Reference(kind, dataset_name, retrieve):
    if kind.lower() == "pos":
        file = "/D_tar.npz"
    else:
        file = "/D_ext.npz"

    data_dir = os.path.join("./data", dataset_name)
    temp = np.load(data_dir + file)
    X, y = temp["X"], temp["y"]
    models_dir = os.path.join("./models", dataset_name)
    if not retrieve:
    
        X_dim = X.shape[1]
        M_ref = Build_Reference_Models(X_dim)
        for model in M_ref:
            model.fit(X,y)
            
        # save reference models
        
        if not os.path.isdir(models_dir):
            os.mkdir(models_dir)
        k = 0
        for model in M_ref:
            k += 1
            with open(models_dir +"/"+ 'M_ref'+ kind + str(k)+ '.pickle', 'wb') as f:
                pickle.dump(model, f)
            
        # training accuracy 
        k = 0
        for model in M_ref:
            k += 1
            y_pred = model.predict(X)
            acc_score = metrics.accuracy_score(y, y_pred)
            print("The", k, "th reference model'accuracy is:", acc_score)
    
    else:
        M_ref = []
        for k in range(1,8):
            with open(models_dir +"/"+ 'M_ref'+ kind + str(k)+ '.pickle', 'rb') as f:
                M_ref.append(pickle.load(f))

    return M_ref






def Train_Authentication(Y_tar,Y_ext, number_classes, dataset_name, retrieve):
    
    if not retrieve:
        Y_tar = Y_tar.reshape(-1, number_classes)
        Y_ext = Y_ext.reshape(-1, number_classes)
        label_tar = np.ones(Y_tar.shape[0]) 
        label_ext = np.zeros(Y_tar.shape[0]) 
    
        X_train = np.insert(Y_tar, Y_tar.shape[0], Y_ext, axis=0)
        y_train = np.insert(label_tar, label_tar.shape[0], label_ext, axis=0)
        index = np.random.permutation(X_train.shape[0])
        X_train, y_train = X_train[index], y_train[index]
        
        model = RandomForestClassifier(n_estimators=100, n_jobs=-1, min_samples_split=3, min_samples_leaf=3,)
        model.fit(X_train, y_train)
        
        # training accuracy
        y_pred = model.predict(X_train)
        acc_score = metrics.accuracy_score(y_train, y_pred)
        print("The authentication model'accuracy is:", acc_score)
        
        # save the model
        with open('./models/'+dataset_name+'/detection_model.pickle', 'wb') as f:
            pickle.dump(model, f)
            
            
        
    else:
        with open('./models/'+dataset_name+'/detection_model.pickle', 'rb') as f:
            authentication_model = pickle.load(f)
    return model 


def Train_Suspect(kind, dataset_name, seed, random_suspect):
    if kind.lower() == "pos":
        file = "/D_tar.npz"
    else:
        file = "/D_sus_neg.npz"

    data_dir = os.path.join("./data", dataset_name)
    temp = np.load(data_dir + file)
    X, y = temp["X"], temp["y"]
    
    X_dim = X.shape[1]
    suspect_models = Build_Suspect_Models(seed, X_dim, random_suspect)
    for model in suspect_models:
        model.fit(X,y)
        
    # save reference models
    models_dir = os.path.join("./models", dataset_name, kind.lower())
    if not os.path.isdir(models_dir):
        os.mkdir(models_dir)
    k = 0
    for model in suspect_models:
        k += 1
        with open(models_dir +"/seed" + str(seed) +'_suspect' + str(k)+ '.pickle', 'wb') as f:
            pickle.dump(model, f)
        
    # training accuracy 
    k = 0
    for model in suspect_models:
        k += 1
        y_pred = model.predict(X)
        acc_score = metrics.accuracy_score(y, y_pred)
        print("The", k, "th suspect model'accuracy is:", acc_score)
    
    return suspect_models



















