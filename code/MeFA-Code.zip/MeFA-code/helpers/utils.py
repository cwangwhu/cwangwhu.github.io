# -*- coding: utf-8 -*-

import numpy as np

import pickle
from sklearn import metrics


def Select_Fingerprint(Y_tar, Y_ext, model, dataset_name):
    
    index = np.arange(Y_tar.shape[1])
    for y in Y_tar:
        temp = np.nonzero(model.predict(y)==1)[0] 
        index = np.intersect1d(index,temp)
        
    for y in Y_ext:
        temp = np.nonzero(model.predict(y)==0)[0]
        index = np.intersect1d(index,temp)
            
        
    print("D_fp number:", index.shape[0])
    
    
    np.savez("./data/" + dataset_name + "/D_fp_index.npz", arr_01 = index)
    
    return index
    

    
    
def Evaluate(authentication_model, D_fp, dataset_name):

    # load all the suspect models
    suspect_pos_list = []
    for seed in range(99):
        try:
            for k in range(1,99):
                try:
                    with open("./models/"+ dataset_name + "/pos" + "/seed" + str(seed) +'_suspect' + str(k)+ '.pickle', 'rb') as f:
                        model = pickle.load(f)
                except FileNotFoundError:
                    break
                suspect_pos_list.append(model)
        except FileNotFoundError:
            break
        
    suspect_neg_list = []
    for seed in range(10):
        try:
            for k in range(1,99):
                try:
                    with open("./models/"+ dataset_name + "/neg" + "/seed" + str(seed) +'_suspect' + str(k)+ '.pickle', 'rb') as f:
                        model = pickle.load(f)
                except FileNotFoundError:
                    break
                suspect_neg_list.append(model)
        except FileNotFoundError:
            break

    
    pos_inference_scores = []
    neg_inference_scores = []
    k = 0
    for model in suspect_pos_list:
        k += 1
        pred = model.predict_proba(D_fp)
        pred_authentication = authentication_model.predict(pred)
        inference_score = metrics.accuracy_score(np.ones(pred_authentication.shape[0]), pred_authentication)
        pos_inference_scores.append(inference_score)
        print("The inference score of " + str(k) + "st positive suspect model:", inference_score)
    k = 0
    for model in suspect_neg_list:
        k += 1
        pred = model.predict_proba(D_fp)
        pred_authentication = authentication_model.predict_proba(pred)
        inference_score = np.mean(pred_authentication[:,1])
        neg_inference_scores.append(inference_score)
        print("The inference score of " + str(k) + "st negative suspect model:", inference_score)

    pos_inference_scores = np.array(pos_inference_scores).reshape(-1,7)
    neg_inference_scores = np.array(neg_inference_scores).reshape(-1,7)
    
    return pos_inference_scores, neg_inference_scores

