# -*- coding: utf-8 -*-

import os
import scipy.io as scio
import pandas as pd
import numpy as np
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import MinMaxScaler
from sklearn.cluster import KMeans
from sklearn.model_selection import train_test_split
import pickle
from sklearn import metrics

random_seed = 0
np.random.seed(0)

def Load_Mnist():
    Mnist = scio.loadmat("./dataset/mnist-original.mat")
    X = Mnist["data"]
    y = Mnist["label"]
    X, y = np.transpose(X), np.transpose(y)
    X = X/255.0
    return X, y

def Load_Purchase(number_classes):
    purchase =  pd.read_csv("./dataset/dataset_purchase")
    purchase.dropna(axis=0, how="any", inplace=True)
    X = np.array(purchase.iloc[:,1:])
    #y = np.array(purchase.iloc[:,0:1], dtype="int64")
    kmeans = KMeans(n_clusters=number_classes, random_state=0).fit(X)
    y = kmeans.labels_
    y = y.reshape(-1)
    return X, y

def Load_Adult():
    adult_df = pd.read_csv("./dataset/adult.data",names=None,index_col=False)
    object_columns = adult_df.dtypes=="object"
    object_columns = list(object_columns[object_columns].index)
    int_columns = adult_df.dtypes=="int64"
    int_columns = list(int_columns[int_columns].index)
    
    for col_name in object_columns:
        values = np.array(adult_df[col_name])
        onehot_encoder = OneHotEncoder(sparse=False)
        values = values.reshape(len(values), 1)
        onehot_matrix = onehot_encoder.fit_transform(values)
        adult_df.drop([col_name],axis=1,inplace=True)
        for i in range(onehot_matrix.shape[1]):
            adult_df.insert(0, 'new_'+col_name+"_"+str(i), value=onehot_matrix[:,i])
    
    for col_name in int_columns:
        Scaler = MinMaxScaler(feature_range=(-1, 1))
        col_value = np.array(adult_df[col_name]).reshape(-1,1)
        new_col = Scaler.fit_transform(col_value)
        adult_df[col_name] = new_col
    
    y = (adult_df.iloc[:,0]==1)
    y = np.array(y, dtype=int)
    adult_df.drop(["new_income_1", "new_income_0"], axis=1, inplace=True)
    X = adult_df.values

    return X,y 



def Process_Split_Dataset(dataset, num_classes, tar_size, ext_size):

    dataset_name = dataset + "_" + str(tar_size)
    if dataset.lower() == "mnist":
        X,y = Load_Mnist()
    elif dataset.lower() == "adult":
        X,y = Load_Adult()
    elif dataset.lower() == "purchase":
        X,y = Load_Purchase(num_classes)
        dataset_name = dataset + str(num_classes) + "_"  + str(tar_size)
    else:
        print("Unsupported dataset!")
        return None, None, None
    
    y = y.reshape(-1)
    
    X_tar,X,y_tar,y = train_test_split(X,y,train_size=tar_size,random_state=random_seed,stratify=y)
    X_ext, X, y_ext, y = train_test_split(X,y,train_size=ext_size,random_state=random_seed,stratify=y)
    X_sus_neg, X, y_sus_neg, y = train_test_split(X,y,train_size=tar_size,random_state=random_seed,stratify=y)
    data_dir = os.path.join("./data", dataset_name)
    if not os.path.isdir(data_dir):
        os.mkdir(data_dir)
    np.savez(data_dir+"/D_tar.npz", X=X_tar, y=y_tar)
    np.savez(data_dir+"/D_ext.npz", X=X_ext, y=y_ext)
    np.savez(data_dir+"/D_sus_neg.npz", X=X_sus_neg, y=y_sus_neg)
    np.savez(data_dir+"/D_remained.npz", X=X, y=y)



    
def Get_All_Data(dataset_name):
    data_dir = os.path.join("./data", dataset_name)
    
    temp = np.load(data_dir+"/D_tar.npz")
    X_tar, y_tar = temp["X"], temp["y"]
    temp = np.load(data_dir+"/D_ext.npz")
    X_ext, y_ext = temp["X"], temp["y"]
    temp = np.load(data_dir+"/D_sus_neg.npz")
    X_sus_neg,y_sus_neg = temp["X"], temp["y"]
    
    return X_tar, y_tar, X_ext, y_ext, X_sus_neg, y_sus_neg
    
def Get_Y(models_list1, models_list2, X, dataset_name, retrive):
    
    if not retrive:
        
        Y_tar = []
        for model in models_list1:
            pred_vector = model.predict_proba(X)
            Y_tar.append(pred_vector)
        Y_tar = np.array(Y_tar)
        # save predictions
        np.savez("./data/" + dataset_name + "/Y_tar.npz", arr_01=Y_tar)
        
        Y_ext = []
        for model in models_list2:
            pred_vector = model.predict_proba(X)
            Y_ext.append(pred_vector)
        Y_ext = np.array(Y_ext)
        # save predictions
        np.savez("./data/" + dataset_name + "/Y_ext.npz", arr_01=Y_ext)
    else:
        Y_tar = np.load("./data/" + dataset_name + "/Y_tar.npz")["arr_01"]
        Y_ext = np.load("./data/" + dataset_name + "/Y_ext.npz")["arr_01"]
    
    # Y_tar.shape = 7*args.tar_size*number_classes
    return Y_tar, Y_ext

def Select_Fingerprint(Y_tar, Y_ext, model, dataset_name):
    
    index = np.arange(Y_tar.shape[1])
    for y in Y_tar:
        temp = np.nonzero(model.predict(y)==1)[0] 
        index = np.intersect1d(index,temp)
        
    for y in Y_ext:
        temp = np.nonzero(model.predict(y)==0)[0]
        index = np.intersect1d(index,temp)
            
        
    print("D_fp number:", index.shape[0])
    
    
    np.savez("./data/" + dataset_name + "/D_fp_index.npz", arr_01 = index)
    
    return index
    

    
    
def Evaluate(authentication_model, D_fp, dataset_name):

    # load all the suspect models
    suspect_pos_list = []
    for seed in range(99):
        try:
            for k in range(1,99):
                try:
                    with open("./models/"+ dataset_name + "/pos" + "/seed" + str(seed) +'_suspect' + str(k)+ '.pickle', 'rb') as f:
                        model = pickle.load(f)
                except FileNotFoundError:
                    break
                suspect_pos_list.append(model)
        except FileNotFoundError:
            break
        
    suspect_neg_list = []
    for seed in range(10):
        try:
            for k in range(1,99):
                try:
                    with open("./models/"+ dataset_name + "/neg" + "/seed" + str(seed) +'_suspect' + str(k)+ '.pickle', 'rb') as f:
                        model = pickle.load(f)
                except FileNotFoundError:
                    break
                suspect_neg_list.append(model)
        except FileNotFoundError:
            break

    
    pos_inference_scores = []
    neg_inference_scores = []
    k = 0
    for model in suspect_pos_list:
        k += 1
        pred = model.predict_proba(D_fp)
        #pred_authentication = authentication_model.predict_proba(pred)
        #inference_score = np.mean(pred_authentication[:,1])
        pred_authentication = authentication_model.predict(pred)
        inference_score = metrics.accuracy_score(np.ones(pred_authentication.shape[0]), pred_authentication)
        pos_inference_scores.append(inference_score)
        print("The inference score of " + str(k) + "st positive suspect model:", inference_score)
    k = 0
    for model in suspect_neg_list:
        k += 1
        pred = model.predict_proba(D_fp)
        pred_authentication = authentication_model.predict_proba(pred)
        inference_score = np.mean(pred_authentication[:,1])
        neg_inference_scores.append(inference_score)
        print("The inference score of " + str(k) + "st negative suspect model:", inference_score)

    pos_inference_scores = np.array(pos_inference_scores).reshape(-1,7)
    neg_inference_scores = np.array(neg_inference_scores).reshape(-1,7)
    
    return pos_inference_scores, neg_inference_scores
    

    
    
    
    
    
    
    
    
    
    
    
    
    