# -*- coding: utf-8 -*-


import numpy as np
#import matplotlib.pyplot as plt
from xgboost import XGBClassifier
from sklearn import metrics
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from sklearn.ensemble import RandomForestClassifier
import pickle

np.random.seed(0)

def Build_Reference_Models(X_dim):
    lay1 = X_dim
    lay2 = int(lay1*1.4)
    lay3 = int(lay2*0.3)
    
    models_list = [XGBClassifier(), 
                  DecisionTreeClassifier(criterion="entropy",max_leaf_nodes=300 ,max_depth=10),
                  LogisticRegression(penalty="l1", solver="liblinear", max_iter=1000),
                  LogisticRegression(penalty="l2", max_iter=1000),
                  SVC(probability=True),
                  MLPClassifier(hidden_layer_sizes=(lay1,lay2,lay3), learning_rate_init=0.01, activation='tanh', solver='sgd'),
                  RandomForestClassifier()
                  ]
    
    return models_list




def Build_Suspect_Models(seed, X_dim, random_suspect=False):
    if random_suspect:
        models_list = [Build_XGB(seed=seed), 
                      Build_DT(seed=seed),
                      Build_LRl1(seed=seed),
                      Build_LRl2(seed=seed),
                      Build_SVC(seed=seed),
                      Build_DNN(seed, X_dim),
                      Build_RF(seed=seed)]
    else:
        lay1 = X_dim
        lay2 = int(lay1*1.4)
        lay3 = int(lay2*0.3)
        models_list = [XGBClassifier(), 
                      DecisionTreeClassifier(criterion="entropy",max_leaf_nodes=300 ,max_depth=10),
                      LogisticRegression(penalty="l1", solver="liblinear", max_iter=1000),
                      LogisticRegression(penalty="l2", max_iter=1000),
                      SVC(probability=True),
                      MLPClassifier(hidden_layer_sizes=(lay1,lay2,lay3), learning_rate_init=0.01, activation='tanh', solver='sgd'),
                      RandomForestClassifier()]

    return models_list


def Build_XGB(seed):
    np.random.seed(seed)
    max_depth = np.random.randint(2,5)
    learning_rate = np.random.uniform(0.01,0.5)
    n_estimators = np.random.randint(50,200)
    model = XGBClassifier(max_depth=max_depth, learning_rate=learning_rate,
                  n_estimators=n_estimators)
    return model


def Build_DT(seed):
    np.random.seed(seed)
    min_samples_split = np.random.randint(2,4)
    min_samples_leaf = np.random.randint(1,3)
    max_leaf_nodes= np.random.randint(100,500)
    max_depth = np.random.randint(8,12)
    model = DecisionTreeClassifier(min_samples_split=min_samples_split,
                           min_samples_leaf=min_samples_leaf, 
                           max_leaf_nodes=max_leaf_nodes,
                           max_depth=max_depth)
    return model
    

def Build_LRl1(seed):
    np.random.seed(seed)
    max_iter = np.random.randint(200, 1000)
    tol = np.random.uniform(0.00001,0.001)
    
    model = LogisticRegression(penalty="l1", solver="liblinear", max_iter=max_iter, tol=tol)
    return model


def Build_LRl2(seed):
    np.random.seed(seed)
    max_iter = np.random.randint(200, 1000)
    tol = np.random.uniform(0.00001,0.001)
    
    model = LogisticRegression(penalty="l2", max_iter=max_iter, tol=tol)
    return model



def Build_SVC(seed):
    np.random.seed(seed)

    C = np.random.uniform(0.1,2)
    tol = np.random.uniform(0.0001,0.01)
    model = SVC(probability=True, C=C, tol=tol)
    return model

def Build_DNN(seed, X_dim):
    np.random.seed(seed)
    
    lay1 = X_dim
    lay2 = int(lay1*1.4*np.random.uniform(0.8,1.2))
    lay3 = int(lay2*0.3*np.random.uniform(0.8,1.2))
    
    learning_rate_init = np.random.uniform(0.005,0.02)
    if np.random.randint(0,2)==0:
        activation='tanh'
    else:
        activation='relu'
        
    temp_seed = np.random.randint(0,3)
    if temp_seed==0:
        solver='lbfgs'
    elif temp_seed==1:
        solver='sgd'
    else:
        solver='adam'

    model = MLPClassifier(hidden_layer_sizes=(lay1,lay2,lay3), 
                          learning_rate_init=learning_rate_init, 
                          activation=activation, solver=solver)
    return model



def Build_RF(seed):
    np.random.seed(seed)

    n_estimators = np.random.randint(80,200)
    max_depth = np.random.randint(8,20)
    min_samples_split =  np.random.randint(2,4)
    min_impurity_decrease = np.random.uniform(0,1e-6)
    model = RandomForestClassifier(n_estimators=n_estimators,
                                   max_depth = max_depth,
                                   min_samples_split=min_samples_split,
                                   min_impurity_decrease=min_impurity_decrease)
    return model






