# -*- coding: utf-8 -*-


import argparse
import os
import numpy as np
from sklearn import metrics
from helpers.data_process import Process_Split_Dataset, Get_All_Data, Select_Fingerprint,Evaluate, Get_Y
from helpers.trainer import Train_Reference, Train_Authentication, Train_Suspect


np.random.seed(0)

parser = argparse.ArgumentParser(description='Data IP protection based on membership inference attck')
parser.add_argument('--lr', default=0.1, type=float, help='learning rate')

parser.add_argument('--dataset', default='Purchase', type=str, help='the dataset [Mnist] [Adult] [Purchase]')
parser.add_argument('--num_classes', default=50, help='the number of classes for Purchase dataset')
parser.add_argument('--tar_size', default='10000', type=int, help='the number of records for target dataset')
parser.add_argument('--ext_size', default='10000', type=int, help='the number of records for ext dataset')
parser.add_argument('--retrieve', default=False, type=bool, help='retrieve=True means we have saved all trained models')
parser.add_argument('--random_suspect', default=False, type=bool, help='randomly set the hyper-parameters of the suspect model?')
parser.add_argument('--threshold', default=0.72, type=float, help='the thrshold to determine the IP violation combined with inference score')


args = parser.parse_args()


if args.dataset.lower() == "mnist":
    number_classes = 10
elif args.dataset.lower() == "adult":
    number_classes = 2
else:
    number_classes = args.num_classes


if args.dataset.lower() == "purchase":
    dataset_name = args.dataset + str(number_classes) + "_" + str(args.tar_size)
else:
    dataset_name = args.dataset + "_" + str(args.tar_size)
    

data_dir = "./data"
if not os.path.isdir(data_dir):
        os.mkdir(data_dir)
models_dir = "./models"
if not os.path.isdir(models_dir):
        os.mkdir(models_dir)

# process and split the dataset

Process_Split_Dataset(args.dataset, number_classes, args.tar_size, args.ext_size)


# train reference models based on D_tar and D_ext respctively
M_ref_pos = Train_Reference("pos", dataset_name, args.retrieve)
M_ref_neg = Train_Reference("neg", dataset_name, args.retrieve)


# get Y_tar (7*args.tar_size*number_classes) and Y_ext, 
# which is the predictions of M_ref_pos, M_ref_neg on D_tar
X_tar, _, _, _, _, _ =  Get_All_Data(dataset_name)

Y_tar, Y_ext = Get_Y(M_ref_pos, M_ref_neg, X_tar, dataset_name, args.retrieve)

# train authentication model

authentication_model = Train_Authentication(Y_tar, Y_ext, number_classes, dataset_name, args.retrieve)

# select membership fingerprint data (D_fp)
D_fp_index = Select_Fingerprint(Y_tar, Y_ext, authentication_model, dataset_name)
D_fp = X_tar[D_fp_index]



# construct suspect models

suspect_dir0 = os.path.join("./models", dataset_name, "neg")
suspect_dir1 = os.path.join("./models", dataset_name, "pos")
if not os.path.isdir(suspect_dir0):
    os.mkdir(suspect_dir0)
    os.mkdir(suspect_dir1)

for k in range(10):
    Train_Suspect("pos", dataset_name, k, args.random_suspect)
    Train_Suspect("neg", dataset_name, k, args.random_suspect)



pos_inference_scores, neg_inference_scores = Evaluate(authentication_model, D_fp, dataset_name)

pos_inference_scores, neg_inference_scores = pos_inference_scores.reshape(-1), neg_inference_scores.reshape(-1)
inference_scores = np.insert(pos_inference_scores, pos_inference_scores.shape[0], neg_inference_scores, axis=0)
inference_scores = np.where(inference_scores>args.threshold, 1,0)


pos_labels = np.ones(pos_inference_scores.shape[0])
neg_labels = np.zeros(neg_inference_scores.shape[0])
labels = np.insert(pos_labels, pos_labels.shape[0], neg_labels, axis=0)


precision = metrics.precision_score(labels, inference_scores)
recall = metrics.precision_score(labels, inference_scores)
print("The precision of this authentication is:", precision)
print("The recall of this authentication is:", recall)




























