#  Membership Fingerprint Authentication (MeFA) 

## About The Project
**MeFA** is an intellectual property protection framework to determine whether a black-box suspect model has used the specific dataset to train. We leverage the membership inference technology to select the fingerprint data from the target dataset showing strong membership property in multiple types of models, and use them to verify the membership property for a model concerned with the target dataset. In MeFA, we could only access the prediction API of the model and the internal setting of the model is confidential. By MeFA, the dataset owner can figure out whether his dataset has been stolen to train the model thus detecting the violation of intellectual property.



## Getting Started
### Prerequisites
**MeFA** requires the following packages: 
- Python 3.7.6
- xgboost 0.90
- Sklearn 0.22.1
- Numpy 1.18.5
- Scipy 1.5.0
- pandas 1.0.3

### File Structure 
```
MeFA
├── dataset
│   ├── adult.data
│   └── dataset_purchase
│   └── mnist-original.mat
├── helpers
│   ├── data_process.py
│   ├── utils.py
│   ├── models.py
│   └── trainer.py
└── main.py

```
There are several parts of the code:
- dataset folder: This folder contains the original dataset  of  Adult, Purchase and MNIST. In order to reduce the memory space, we just list the links to theset dataset here. 
   -- Adult: https://archive.ics.uci.edu/ml/datasets/Adult
   -- Purchase: https://github.com/privacytrustlab/datasets/blob/master/dataset_purchase.tgz
   -- MNIST: http://yann.lecun.com/exdb/mnist/

- data_process.py: This file mainly contains the preprocessing of the raw dataset in dataset folder.
- utils.py: This file contains membership fingerprint selection and membership fingerprint authentication algorithms, which corresponds to **Design of MeFA** in our paper. 

- models.py: This file contains the internal setting of reference models, suspect models, and authentication models.
- trainer.py: This file trains models (reference models, suspect models, and authentication models), and saves them.
- main.py: The main function of MeFA. 



## Attack Setting 
The settings of MeFA are determined in the parameter **args** in **main.py**. 
- dataset: the dataset used for training the target model (default: purchase, support: adult, purchase, mnist)). 
- num_classes: The number of classes that the purchase dataset is splited.
- 
- tar_size: the number of records in target dataset (default: 10000).
- ext_size: the number of records in extra dataset (default: 10000).
- retrieve: If all models has already been trained, you can save time by setting retrieve=True directly proceeding with membership fingerprint authentication.
- random_suspect: whether to randomly set the hyper-parameters of the suspect model.
- threshold: determines the final result for authentication combined with inference score.

## Execute MeFA
Run main.py in your python IDE directly. 

# Notes
- There is no need to use a GPU for the model training. 
- If you want to change the model setting, please modify the  corresosponding function in models.py. 

