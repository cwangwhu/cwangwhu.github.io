We release the code for “Manipulating Supply Chain Demand Forecasting with Targeted Poisoning Attacks”.

Prerequisites:
Install dependencies (e.g., sklearn, numpy, scipy)

Download Datasets:
Download Bike Sharing Demand dataset from https://archive.ics.uci.edu/ml/datasets/bike+sharing+dataset, 
and GEFCom2012 dataset from https://www.kaggle.com/c/global-energy-forecasting-competition-2012-load-forecasting.

Getting Started:
Run python poison.py

Code Structure:
+ poison.py: for generating poisoning data under white-box and black-box settings;
+ my_args.py: for parameters adjustment;
+ gd_poisoners.py: for different linear regression models construction.

