﻿#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <boost/thread.hpp>
#include <boost/random/linear_congruential.hpp>
#include <time.h>

#define MAX_STRING 200
#define NEG_SAMPLING_POWER 0.75
#define SIGMOID_BOUND 6

const int hash_table_size = 30000000;
const int neg_table_size = 1e7;
const int sigmoid_table_size = 1000;

struct ClassVertex {
	char *name;
	double degree;
	double degree1;
	double degree2;
};
typedef float real;

struct ClassVertex *vertex;
char checkin_file[MAX_STRING], embedding_file[MAX_STRING], friendship_file[MAX_STRING], virtuallinkage_file[MAX_STRING];
int num_threads, dim, num_negative;
int max_num_vertices = 100000, num_vertices = 0, num_vertices1 = 0, num_vertices2 = 0, num_vertices3 = 0, num_vertices4 = 0;
int *neg_table_user, *neg_table_poi, *neg_table_time, *neg_table_category, *neg_table_friendship, *neg_table_virtual;
real init_rho = 0.025, rho, ret, ratio;
real *emb_vertex, *sigmoid_table, *check_time;
long long current_sample_count = 0, current_sample_count1 = 0, current_sample_count3 = 0, total_samples = 3000000, curedge;
long long num_edges_checkin = 0, num_edges_virtual = 0, num_edges_friendship = 0, number_poi = 0;
int *vertex1, *vertex2, *vertex3, *vertex4, *virtuallinkage_1, *virtuallinkage_2, *friendship_1, *friendship_2;
real *Edge, *NewEdge, *AddEdge;
int *user_vid, *time_vid, *poi_vid, *category_vid, *poi_category_vid, *vertex_hash_table, *vertex_hash_table_1, *vertex_hash_table_2, *vertex_hash_table_3;
int t;
long long count2 = 0, count1 = 0, count3 = 0;
real alp;

void InitHashTable()
{
	vertex_hash_table = (int *)malloc(hash_table_size * sizeof(int));
	for (int k = 0; k != hash_table_size; k++) vertex_hash_table[k] = -1;
	vertex_hash_table_1 = (int *)malloc(hash_table_size * sizeof(int));
	for (int k = 0; k != hash_table_size; k++) vertex_hash_table_1[k] = -1;
	vertex_hash_table_2 = (int *)malloc(hash_table_size * sizeof(int));
	for (int k = 0; k != hash_table_size; k++) vertex_hash_table_2[k] = -1;
	vertex_hash_table_3 = (int *)malloc(hash_table_size * sizeof(int));
	for (int k = 0; k != hash_table_size; k++) vertex_hash_table_3[k] = -1;
}


unsigned int Hash(char *key)
{
	unsigned int seed = 131;
	unsigned int hash = 0;
	while (*key)
	{
		hash = hash * seed + (*key++);
	}
	return hash % hash_table_size;
}


int SearchHashTable(char *key)
{
	int addr = Hash(key);
	while (1)
	{
		if (vertex_hash_table[addr] == -1) return -1;
		if (!strcmp(key, vertex[vertex_hash_table[addr]].name)) return vertex_hash_table[addr];
		addr = (addr + 1) % hash_table_size;
	}
	return -1;
}


void InsertHashTable(char *key, int value)
{
	int addr = Hash(key);
	while (vertex_hash_table[addr] != -1) addr = (addr + 1) % hash_table_size;
	vertex_hash_table[addr] = value;
}


int AddVertex(char *name)
{
	int length = strlen(name) + 1;
	if (length > MAX_STRING) length = MAX_STRING;
	vertex[num_vertices].name = (char *)calloc(length, sizeof(char));
	strcpy(vertex[num_vertices].name, name);
	vertex[num_vertices].degree = 0;
	vertex[num_vertices].degree1 = 0;
	vertex[num_vertices].degree2 = 0;
	num_vertices++;
	if (num_vertices + 2 >= max_num_vertices)
	{
		max_num_vertices += 1000;
		vertex = (struct ClassVertex *)realloc(vertex, max_num_vertices * sizeof(struct ClassVertex));
	}
	InsertHashTable(name, num_vertices - 1);
	return num_vertices - 1;
}

int SearchHashTable1(int key) {
	return vertex_hash_table_1[key];
}
int SearchHashTable2(int key) {
	return vertex_hash_table_2[key];
}
int SearchHashTable3(int key) {
	return vertex_hash_table_3[key];
}
void InsertHashTable1(int key, int value) {
	vertex_hash_table_1[key] = value;
}
void InsertHashTable2(int key, int value) {
	vertex_hash_table_2[key] = value;
}
void InsertHashTable3(int key, int value) {
	vertex_hash_table_3[key] = value;
}

void ReadData()
{
	FILE *fin;
	char str[2 * MAX_STRING + 10000], name_v1[MAX_STRING], name_v2[MAX_STRING], name_v3[MAX_STRING], name_v4[MAX_STRING];
	int vid, t, vid1, user, poi, time, all;
	char st[300], *token;

	fin = fopen(checkin_file, "rb");
	num_edges_checkin = 0;
	while (fgets(str, sizeof(str), fin)) num_edges_checkin++;
	fclose(fin);
	printf("Number of check-ins: %lld          \n", num_edges_checkin);

	vertex1 = (int *)malloc(num_edges_checkin * sizeof(int));
	vertex2 = (int *)malloc(num_edges_checkin * sizeof(int));
	vertex3 = (int *)malloc(num_edges_checkin * sizeof(int));
	vertex4 = (int *)malloc(num_edges_checkin * sizeof(int));

	if (vertex1 == NULL || vertex2 == NULL || vertex3 == NULL || vertex4 == NULL)
	{
		printf("Error: memory allocation failed!\n");
		exit(1);
	}
	# check_ins
	fin = fopen(checkin_file, "rb");
	for (int k = 0; k != num_edges_checkin; k++)
	{
		fscanf(fin, "%s\t%s\t%s\t%s", name_v1, name_v2, name_v3, name_v4);
		vid = SearchHashTable(name_v1);
		if (vid == -1)
		{
			vid = AddVertex(name_v1);
			user_vid[num_vertices1] = vid;
			InsertHashTable1(vid, num_vertices1);
			num_vertices1++;
		}
		vertex[vid].degree += 1;
		vertex1[k] = vid;

		vid = SearchHashTable(name_v2);
		vid1 = SearchHashTable(name_v2);
		if (vid == -1)
		{
			vid = AddVertex(name_v2);
			poi_vid[num_vertices2] = vid;
			InsertHashTable2(vid, num_vertices2);
			num_vertices2++;
		}
		vertex[vid].degree += 1;
		vertex2[k] = vid;

		vid = SearchHashTable(name_v3);
		if (vid == -1)
		{
			vid = AddVertex(name_v3);
			time_vid[num_vertices3] = vid;
			InsertHashTable3(vid, num_vertices3);
			num_vertices3++;
		}
		vertex[vid].degree += 1;
		vertex3[k] = vid;

		vid = SearchHashTable(name_v4);
		if (vid == -1)
		{
			vid = AddVertex(name_v4);
			category_vid[num_vertices4] = vid;
			num_vertices4++;
		}
		vertex[vid].degree += 1;
		vertex4[k] = vid;
		if (vid1 == -1) poi_category_vid[num_vertices2 - 1] = SearchHashTable(name_v4);
	}
	fclose(fin);

	fin = fopen(checkin_file, "rb");
	check_time = (real *)malloc(num_vertices1 * 168 * sizeof(real));
	for (int i = 0; i < num_vertices1; i++)
		for (int j = 0; j < 168; j++)
			check_time[i * 168 + j] = 0;

	for (int k = 0; k != num_edges_checkin; k++)
	{
		fscanf(fin, "%s\t%s\t%s\t%s", name_v1, name_v2, name_v3, name_v4);
		user = SearchHashTable(name_v1);
		time = SearchHashTable(name_v3);
		if ((SearchHashTable1(user) > -1) && (SearchHashTable3(time) > -1)) {
			check_time[SearchHashTable1(user) * 168 + SearchHashTable3(time)] += 1;
		}
	}
	fclose(fin);

	for (int i = 0; i < num_vertices1; i++) {
		all = 0;
		for (int j = 0; j < 168; j++)
			all += check_time[i * 168 + j];
		for (int j = 0; j < 168; j++)
			check_time[i * 168 + j] = check_time[i * 168 + j] / all;
	}
	
	# virtual hyperedges
	fin = fopen(virtuallinkage_file, "rb");
	while (fgets(str, sizeof(str), fin)) num_edges_virtual++;
	fclose(fin);
	printf("Number of virtual linkages: %lld          \n", num_edges_virtual);

	virtuallinkage_1 = (int *)malloc(num_edges_virtual * sizeof(int));
	virtuallinkage_2 = (int *)malloc(num_edges_virtual * sizeof(int));
	if (virtuallinkage_1 == NULL || virtuallinkage_2 == NULL)
	{
		printf("Error: memory allocation failed!\n");
		exit(1);
	}

	fin = fopen(virtuallinkage_file, "rb");
	for (int k = 0; k != num_edges_virtual; k++)
	{
		fscanf(fin, "%s %s", name_v1, name_v2);

		vid = SearchHashTable(name_v1);
		vertex[vid].degree1 += 1;
		virtuallinkage_1[k] = vid;

		vid = SearchHashTable(name_v2);
		vertex[vid].degree1 += 1;
		virtuallinkage_2[k] = vid;
	}
	fclose(fin);
	
	# friendships
	fin = fopen(friendship_file, "rb");
	while (fgets(str, sizeof(str), fin)) num_edges_friendship++;
	fclose(fin);
	printf("Number of friendship edges: %lld          \n", num_edges_friendship);

	friendship_1 = (int *)malloc(num_edges_friendship * sizeof(int));
	friendship_2 = (int *)malloc(num_edges_friendship * sizeof(int));
	if (friendship_1 == NULL || friendship_2 == NULL)
	{
		printf("Error: memory allocation failed!\n");
		exit(1);
	}
	fin = fopen(friendship_file, "rb");
	for (int k = 0; k != num_edges_friendship; k++)
	{
		fscanf(fin, "%s %s", name_v1, name_v2);
		if (SearchHashTable(name_v1)*SearchHashTable(name_v2) > 0)
		{
			vid = SearchHashTable(name_v1);
			vertex[vid].degree2 += 1;
			friendship_1[k] = vid;

			vid = SearchHashTable(name_v2);
			vertex[vid].degree2 += 1;
			friendship_2[k] = vid;
		}
	}
	fclose(fin);
	printf("Number of vertices1: %lld          \n", num_vertices1);
	printf("Number of vertices2: %lld          \n", num_vertices2);
	printf("Number of vertices3: %lld          \n", num_vertices3);
	printf("Number of vertices4: %lld          \n", num_vertices4);
	printf("Number of vertices: %lld          \n", num_vertices);	
	
}


int ArgPos(char *str, int argc, char **argv) {
	int a;
	for (a = 1; a < argc; a++) if (!strcmp(str, argv[a])) {
		if (a == argc - 1) {
			printf("Argument missing for %s\n", str);
			exit(1);
		}
		return a;
	}
	return -1;
}

void InitVector()
{
	long long a, b;
	real sum = 0;

	emb_vertex = (real *)_aligned_malloc((long long)num_vertices * dim * sizeof(real), 128);
	if (emb_vertex == NULL) { printf("Error: memory allocation failed\n"); exit(1); }

	for (a = 0; a < num_vertices; a++)
	{
		sum = 0;
		for (b = 0; b < dim; b++)
		{
			emb_vertex[a * dim + b] = (rand() / (real)RAND_MAX - 0.5) / dim;
			sum = sum + emb_vertex[a * dim + b] * emb_vertex[a * dim + b];
		}
		for (b = 0; b < dim; b++) emb_vertex[a * dim + b] = emb_vertex[a * dim + b] / sqrt(sum);
	}
}

void InitNegTable()
{
	double sum = 0, cur_sum = 0, por = 0;
	int vid = 0;
	neg_table_user = (int *)malloc(neg_table_size * sizeof(int));
	neg_table_poi = (int *)malloc(neg_table_size * sizeof(int));
	neg_table_time = (int *)malloc(neg_table_size * sizeof(int));
	neg_table_category = (int *)malloc(neg_table_size * sizeof(int));
	neg_table_friendship = (int *)malloc(neg_table_size * sizeof(int));
	neg_table_virtual = (int *)malloc(neg_table_size * sizeof(int));

	for (int k = 0; k != num_vertices1; k++) sum += pow(vertex[user_vid[k]].degree, NEG_SAMPLING_POWER);
	for (int k = 0; k != neg_table_size; k++)
	{
		if ((double)(k + 1) / neg_table_size > por)
		{
			cur_sum += pow(vertex[int(user_vid[vid])].degree, NEG_SAMPLING_POWER);
			por = cur_sum / sum;
			vid++;
		}
		neg_table_user[k] = int(user_vid[vid - 1]);
	}

	vid = 0, sum = 0, cur_sum = 0, por = 0;
	for (int k = 0; k != num_vertices2; k++) sum += pow(vertex[poi_vid[k]].degree, NEG_SAMPLING_POWER);
	for (int k = 0; k != neg_table_size; k++)
	{
		if ((double)(k + 1) / neg_table_size > por)
		{
			cur_sum += pow(vertex[int(poi_vid[vid])].degree, NEG_SAMPLING_POWER);
			por = cur_sum / sum;
			vid++;
		}
		neg_table_poi[k] = int(poi_vid[vid - 1]);
	}

	vid = 0, sum = 0, cur_sum = 0, por = 0;
	for (int k = 0; k != num_vertices3; k++) sum += pow(vertex[time_vid[k]].degree, NEG_SAMPLING_POWER);
	for (int k = 0; k != neg_table_size; k++)
	{
		if ((double)(k + 1) / neg_table_size > por)
		{
			cur_sum += pow(vertex[int(time_vid[vid])].degree, NEG_SAMPLING_POWER);
			por = cur_sum / sum;
			vid++;
		}
		neg_table_time[k] = int(time_vid[vid - 1]);
	}

	vid = 0, sum = 0, cur_sum = 0, por = 0;
	for (int k = 0; k != num_vertices4; k++) sum += pow(vertex[category_vid[k]].degree, NEG_SAMPLING_POWER);
	for (int k = 0; k != neg_table_size; k++)
	{
		if ((double)(k + 1) / neg_table_size > por)
		{
			cur_sum += pow(vertex[int(category_vid[vid])].degree, NEG_SAMPLING_POWER);
			por = cur_sum / sum;
			vid++;
		}
		neg_table_category[k] = int(category_vid[vid - 1]);
	}

	vid = 0, sum = 0, cur_sum = 0, por = 0;
	for (int k = 0; k != num_vertices1; k++) sum += pow(vertex[user_vid[k]].degree1, NEG_SAMPLING_POWER);
	for (int k = 0; k != neg_table_size; k++)
	{
		if ((double)(k + 1) / neg_table_size > por)
		{
			cur_sum += pow(vertex[int(user_vid[vid])].degree1, NEG_SAMPLING_POWER);
			por = cur_sum / sum;
			vid++;
		}
		neg_table_friendship[k] = int(user_vid[vid - 1]);
	}

	vid = 0, sum = 0, cur_sum = 0, por = 0;
	for (int k = 0; k != num_vertices4; k++) sum += pow(vertex[poi_vid[k]].degree2, NEG_SAMPLING_POWER);
	for (int k = 0; k != neg_table_size; k++)
	{
		if ((double)(k + 1) / neg_table_size > por)
		{
			cur_sum += pow(vertex[int(poi_vid[vid])].degree2, NEG_SAMPLING_POWER);
			por = cur_sum / sum;
			vid++;
		}
		neg_table_virtual[k] = int(poi_vid[vid - 1]);
	}
}

void InitSigmoidTable()
{
	real x;
	sigmoid_table = (real *)malloc((sigmoid_table_size + 1) * sizeof(real));
	for (int k = 0; k != sigmoid_table_size; k++)
	{
		x = 2.0 * SIGMOID_BOUND * k / sigmoid_table_size - SIGMOID_BOUND;
		sigmoid_table[k] = 1 / (1 + exp(-x));
	}
}

int Rand(unsigned long long &seed)
{
	seed = seed * 25214903917 + 11;
	return (seed >> 16) % neg_table_size;
}

real FastSigmoid(real x)
{
	if (x > SIGMOID_BOUND) return 1;
	else if (x < -SIGMOID_BOUND) return 0;
	int k = (x + SIGMOID_BOUND) * sigmoid_table_size / SIGMOID_BOUND / 2;
	return sigmoid_table[k];
}

void Update(real *vec_u, real *vec_v, real *vec_error, int label)
{
	real x = 0, g;
	for (int c = 0; c != dim; c++) x += vec_u[c] * vec_v[c];
	g = (label - FastSigmoid(x)) * rho * alp;
	for (int c = 0; c != dim; c++) vec_error[c] += g * vec_v[c];
	for (int c = 0; c != dim; c++) vec_v[c] += g * vec_u[c];
}

void *TrainThread(void *id)
{
	long long u, v, lu, lv, target, label;
	long long last_count = 0, last_count1 = 0, last_count3 = 0;
	long long neg1, neg2, neg3, neg4;
	real *vec_error = (real *)calloc(dim, sizeof(real));
	unsigned long long seed = (long long)id;
	int k, epoch = 0;
	real sum, alpha;

	while (epoch < 1)
	{
		epoch++;
		
		# Homophily Preserving POI domain
		while (1)
		{
			if (count3 > total_samples /2 / num_threads + 2) break;
			if (count3 - last_count3 > 10000)
			{
				current_sample_count3 += count3 - last_count3;
				last_count3 = count3;
				fflush(stdout);
				rho = init_rho * (1 - current_sample_count3 / (real)(total_samples + 1));
				if (rho < init_rho * 0.0001) rho = init_rho * 0.0001;
			}

			curedge = rand() % num_edges_virtual;
			u = virtuallinkage_1[curedge];
			v = virtuallinkage_2[curedge];
			while (1)
			{
				if (u > 0 && v > 0) break;
				curedge = rand() % (num_edges_friendship + 1);
				u = virtuallinkage_1[curedge];
				v = virtuallinkage_2[curedge];
			}
			for (int c = 0; c != dim; c++) vec_error[c] = 0;
			for (int d = 0; d != num_negative + 1; d++)
			{
				if (d == 0)
				{
					target = v;
					label = 1;
				}
				else
				{
					target = neg_table_virtual[Rand(seed)];
					label = 0;
				}
				lu = u * dim;
				lv = target * dim;
				Update(&emb_vertex[lu], &emb_vertex[lv], vec_error, label);
			}
			for (int c = 0; c != dim; c++) emb_vertex[c + lu] += vec_error[c];
			count3++;
		}
		
		# Homophily Preserving User domain
		while (1)
		{
			if (count1 > total_samples / 100 / num_threads + 2) break;
			if (count1 - last_count1 > 10000)
			{
				current_sample_count1 += count1 - last_count1;
				last_count1 = count1;
				fflush(stdout);
				rho = init_rho * (1 - current_sample_count1 / (real)(total_samples + 1));
				if (rho < init_rho * 0.0001) rho = init_rho * 0.0001;
			}
			t = 0;
			curedge = rand() % num_edges_friendship;
			u = friendship_1[curedge];
			v = friendship_2[curedge];
			while (1)
			{
				if (u > 0 && v > 0) break;
				curedge = rand() % (num_edges_friendship + 1);
				u = friendship_1[curedge];
				v = friendship_2[curedge];
			}

			for (int c = 0; c != dim; c++) vec_error[c] = 0;
			for (int d = 0; d != num_negative + 1; d++)
			{
				if (d == 0)
				{
					target = v;
					label = 1;
				}
				else
				{
					target = neg_table_friendship[Rand(seed)];
					label = 0;
				}
				lu = u * dim;
				lv = target * dim;

				Update(&emb_vertex[lu], &emb_vertex[lv], vec_error, label);
			}
			for (int c = 0; c != dim; c++) emb_vertex[c + lu] += vec_error[c];
			count1++;
		}

		# Interaction Attribute Learning across domains
		while (1)
		{
			if (count2 > total_samples / num_threads + 2) break;
			if (count2 - last_count > 10000)
			{
				current_sample_count += count2 - last_count;
				last_count = count2;
				fflush(stdout);
				rho = init_rho * (1 - current_sample_count / (real)(total_samples + 1));
				if (rho < init_rho * 0.0001) rho = init_rho * 0.0001;
			}
			t = 1;

			curedge = rand() % num_edges_checkin;
			u = vertex1[curedge];
			v = vertex3[curedge];
			alpha = check_time[SearchHashTable1(u) * 168 + SearchHashTable3(v)] * 10;
			for (int c = 0; c != dim; c++) vec_error[c] = 0;
			for (int i = 1; i < 5; i++)
			{
				if (i == 1) { u = vertex1[curedge]; alp = 1; }
				if (i == 2) { u = vertex2[curedge]; alp = 1; }
				if (i == 3) { u = vertex3[curedge]; alp = alpha; }
				if (i == 4) { u = vertex4[curedge]; alp = 1; }

				for (int j = 1; j < 4; j++)
				{
					k = (i + j) % 4;
					if (k == 0) k = 4;
					if (k == 1) { v = vertex1[curedge]; alp = 1; }
					if (k == 2) { v = vertex2[curedge]; alp = 1; }
					if (k == 3) { v = vertex3[curedge]; alp = alpha; }
					if (k == 4) { v = vertex4[curedge]; alp = 1; }
					label = 1;

					for (int d = 0; d != num_negative + 1; d++)
					{
						if (d == 0)
						{
							target = v;
							label = 1;
						}
						else
						{
							neg1 = neg_table_user[Rand(seed)];
							neg2 = neg_table_poi[Rand(seed)];
							neg3 = neg_table_time[Rand(seed)];
							neg4 = neg_table_category[Rand(seed)];

							if (k == 1) target = vertex1[neg1];
							if (k == 2) target = vertex2[neg2];
							if (k == 3) target = vertex3[neg3];
							if (k == 4) target = vertex4[neg4];
							label = 0;
						}

						lu = u * dim;
						lv = target * dim;
						Update(&emb_vertex[lu], &emb_vertex[lv], vec_error, label);
					}
					for (int c = 0; c != dim; c++) emb_vertex[c + lu] += vec_error[c];
				}
			}
			count2++;
		}
	}
	free(vec_error);
	return NULL;
}

void Output()
{
	FILE *fo = fopen(embedding_file, "wb");
	fprintf(fo, "%d %d\n", num_vertices, dim);
	for (int a = 0; a < num_vertices; a++)
	{
		fprintf(fo, "%s ", vertex[a].name);
		for (int b = 0; b < dim; b++) fprintf(fo, "%lf ", emb_vertex[a * dim + b]);
		fprintf(fo, "\n");
	}
	fclose(fo);
}


void Experiment() {
	long a;
	boost::thread *pt = new boost::thread[num_threads];

	printf("--------------------------------\n");
	printf("Negative: %d\n", num_negative);
	printf("Dimension: %d\n", dim);
	printf("Initial rho: %lf\n", init_rho);
	printf("--------------------------------\n");

	InitHashTable();
	ReadData();
	InitVector();
	InitNegTable();
	InitSigmoidTable();

	clock_t start = clock();
	printf("--------------------------------\n");
	for (a = 0; a < num_threads; a++) pt[a] = boost::thread(TrainThread, (void *)a);
	for (a = 0; a < num_threads; a++) pt[a].join();
	printf("\n");
	clock_t finish = clock();
	printf("Embedding Learning total time: %lf\n", (double)(finish - start) / CLOCKS_PER_SEC);

	Output();
}


void Initedges()
{
	int user, poi;
	int t1, t2;
	for (int i = 0; i < num_vertices1; i++)
		for (int j = 0; j < num_vertices2; j++)
			Edge[i * num_vertices2 + j] = 0;
	for (int k = 0; k < num_edges_checkin; k++)
	{
		user = vertex1[k];
		poi = vertex2[k];

		t1 = SearchHashTable1(user);
		t2 = SearchHashTable2(poi);
		if ((t1 > -1) && (t2 > -1))
			Edge[SearchHashTable1(user)* num_vertices2 + SearchHashTable2(poi)] += 1;
	}

	for (int i = 0; i < num_vertices1; i++)
		for (int j = 0; j < num_vertices2; j++)
			AddEdge[i * num_vertices2 + j] = 0;

	for (int i = 0; i < num_vertices1; i++)
		for (int j = 0; j < num_vertices2; j++)
			NewEdge[i * num_vertices2 + j] = 0;
}


void predict()
{
	float sum = 0, temp, top, *score, *a;
	FILE *fin;
	int num_edges_new_checkin = 0, user, poi, category, k, sum1 = 0, sample_num;
	int FP = 0, TP = 0, FN = 0, TN = 0, vid = 0, *vertex_user, *vertex_poi, *sample;
	char str[2 * MAX_STRING + 10000], name_v1[MAX_STRING], name_v2[MAX_STRING];
	char st[300], *token;

	score = (float *)malloc(num_vertices1 * num_vertices2 * sizeof(float));
	a = (float *)malloc(num_vertices2 * sizeof(float));
	Edge = (float *)malloc(num_vertices1 * num_vertices2 * sizeof(float));
	NewEdge = (float *)malloc(num_vertices1 * num_vertices2 * sizeof(float));
	AddEdge = (float *)malloc(num_vertices1 * num_vertices2 * sizeof(float));
	Initedges();

	fin = fopen("checkin_file_new.txt", "rb");
	if (fin == NULL)
	{
		printf("ERROR");
		exit(1);
	}
	while (fgets(str, sizeof(str), fin)) num_edges_new_checkin++;
	fclose(fin);
	vertex_user = (int *)malloc(num_edges_new_checkin * sizeof(int));
	vertex_poi = (int *)malloc(num_edges_new_checkin * sizeof(int));
	fin = fopen("checkin_file_new.txt", "rb");

	for (int k = 0; k != num_edges_new_checkin; k++)
	{
		fgets(st, 300, fin);
		token = strtok(st, "\t");    
		strcpy(name_v1, token);
		token = strtok(NULL, "\t");
		strcpy(name_v2, token);

		vid = SearchHashTable(name_v1);
		vertex_user[k] = vid;
		vid = SearchHashTable(name_v2);
		vertex_poi[k] = vid;
	}
	fclose(fin);

	for (int k = 0; k < num_edges_new_checkin; k++)
	{
		user = vertex_user[k];
		poi = vertex_poi[k];
		if ((SearchHashTable1(user) > -1) && (SearchHashTable2(poi) > -1))
			NewEdge[SearchHashTable1(user)* num_vertices2 + SearchHashTable2(poi)] += 1;
	}

	sample_num = num_vertices1;
	sample = (int *)malloc(sample_num * sizeof(int));
	for (int i = 0; i < sample_num; i++) sample[i] = i;
	
	//score
	for (int i = 0; i < sample_num; i++) {     
		for (int j = 0; j < num_vertices2; j++) {
			user = user_vid[sample[i]];
			poi = poi_vid[j];
			category = poi_category_vid[j];

			if (Edge[sample[i] * num_vertices2 + j] > 0)
				score[sample[i] * num_vertices2 + j] = -10;
			else {
				for (int k = 0; k < dim; k++) sum += emb_vertex[user*dim + k] * emb_vertex[poi*dim + k];
				score[sample[i] * num_vertices2 + j] = sum;
			}
			sum = 0;
		}
	}

	///////////////top-3
	for (int i = 0; i < sample_num; i++) {
		for (int j = 0; j < num_vertices2; j++) {
			a[j] = score[sample[i] * num_vertices2 + j];
		}
		std::sort(a, a + num_vertices2);

		k = num_vertices2 - 4;
		top = a[k];
		for (int j = 0; j < num_vertices2; j++) {
			if (score[sample[i] * num_vertices2 + j] > top)
				AddEdge[sample[i] * num_vertices2 + j] = 1;
			else
				AddEdge[sample[i] * num_vertices2 + j] = 0;
		}
	}
	for (int i = 0; i < sample_num; i++) {
		sum = 0;
		for (int k = 0; k < num_vertices2; k++)
			if (NewEdge[sample[i] * num_vertices2 + k] > 0 && Edge[sample[i] * num_vertices2 + k] == 0)  sum = sum + 1;

		if (sum >= 5)
		{
			for (int j = 0; j < num_vertices2; j++) {
				if (Edge[sample[i] * num_vertices2 + j] == 0)
				{
					if (AddEdge[sample[i] * num_vertices2 + j] > 0)
						if (NewEdge[sample[i] * num_vertices2 + j] > 0)
							TP++;
						else
							TN++;
					else
						if (NewEdge[sample[i] * num_vertices2 + j] > 0)
							FP++;
						else
							FN++;
				}
			}
		}
	}
	printf("k = %d, TP: %d, TN: %d, FP: %d, FN: %d\n", num_vertices2 - k - 1, TP, TN, FP, FN);
	TP = 0, TN = 0, FP = 0, FN = 0;

	///////top-5
	for (int i = 0; i < sample_num; i++) {
		for (int j = 0; j < num_vertices2; j++) {
			a[j] = score[sample[i] * num_vertices2 + j];
		}
		std::sort(a, a + num_vertices2);
		k = num_vertices2 - 6;
		top = a[k];

		for (int j = 0; j < num_vertices2; j++) {
			if (score[sample[i] * num_vertices2 + j] > top)
				AddEdge[sample[i] * num_vertices2 + j] = 1;
			else
				AddEdge[sample[i] * num_vertices2 + j] = 0;
		}
	}
	for (int i = 0; i < sample_num; i++) {
		sum = 0;
		for (int k = 0; k < num_vertices2; k++)
			if (NewEdge[sample[i] * num_vertices2 + k] > 0 && Edge[sample[i] * num_vertices2 + k] == 0)  sum = sum + 1;
		if (sum >= 5)
		{
			for (int j = 0; j < num_vertices2; j++) {
				if (Edge[sample[i] * num_vertices2 + j] == 0)
				{
					if (AddEdge[sample[i] * num_vertices2 + j] > 0)
						if (NewEdge[sample[i] * num_vertices2 + j] > 0)
							TP++;
						else
							TN++;
					else
						if (NewEdge[sample[i] * num_vertices2 + j] > 0)
							FP++;
						else
							FN++; 
				}
			}
		}
	}
	printf("k = %d, TP: %d, TN: %d, FP: %d, FN: %d\n", num_vertices2 - k - 1, TP, TN, FP, FN);
	TP = 0, TN = 0, FP = 0, FN = 0;

	///////top-10
	for (int i = 0; i < sample_num; i++) {
		for (int j = 0; j < num_vertices2; j++) {
			a[j] = score[sample[i] * num_vertices2 + j];
		}
		std::sort(a, a + num_vertices2);
		k = num_vertices2 - 11;
		top = a[k];
		for (int j = 0; j < num_vertices2; j++) {
			if (score[sample[i] * num_vertices2 + j] > top)
				AddEdge[sample[i] * num_vertices2 + j] = 1;
			else
				AddEdge[sample[i] * num_vertices2 + j] = 0;
		}
	}
	for (int i = 0; i < sample_num; i++) {
		sum = 0;
		for (int k = 0; k < num_vertices2; k++)
			if (NewEdge[sample[i] * num_vertices2 + k] > 0 && Edge[sample[i] * num_vertices2 + k] == 0)  sum = sum + 1;
		if (sum >= 5)
		{
			for (int j = 0; j < num_vertices2; j++) {
				if (Edge[sample[i] * num_vertices2 + j] == 0)
				{
					if (AddEdge[sample[i] * num_vertices2 + j] > 0)
						if (NewEdge[sample[i] * num_vertices2 + j] > 0)
							TP++;
						else
							TN++;
					else
						if (NewEdge[sample[i] * num_vertices2 + j] > 0)
							FP++;
						else
							FN++;
				}
			}
		}
	}
	printf("k = %d, TP: %d, TN: %d, FP: %d, FN: %d\n", num_vertices2 - k - 1, TP, TN, FP, FN);
	TP = 0, TN = 0, FP = 0, FN = 0;

	///////top-20
	for (int i = 0; i < sample_num; i++) {
		for (int j = 0; j < num_vertices2; j++) {
			a[j] = score[sample[i] * num_vertices2 + j];
		}
		std::sort(a, a + num_vertices2);
		k = num_vertices2 - 21;
		top = a[k];

		for (int j = 0; j < num_vertices2; j++) {
			if (score[sample[i] * num_vertices2 + j] > top)
				AddEdge[sample[i] * num_vertices2 + j] = 1;
			else
				AddEdge[sample[i] * num_vertices2 + j] = 0;
		}
	}
	for (int i = 0; i < sample_num; i++) {
		sum = 0;
		for (int k = 0; k < num_vertices2; k++)
			if (NewEdge[sample[i] * num_vertices2 + k] > 0 && Edge[sample[i] * num_vertices2 + k] == 0)  sum = sum + 1;

		if (sum >= 5)
		{
			for (int j = 0; j < num_vertices2; j++) {
				if (Edge[sample[i] * num_vertices2 + j] == 0)
				{
					if (AddEdge[sample[i] * num_vertices2 + j] > 0)
						if (NewEdge[sample[i] * num_vertices2 + j] > 0)
							TP++;
						else
							TN++;                                                                                                                               
					else
						if (NewEdge[sample[i] * num_vertices2 + j] > 0)
							FP++;
						else
							FN++;
				}
			}
		}
	}
	printf("k = %d, TP: %d, TN: %d, FP: %d, FN: %d\n", num_vertices2 - k - 1, TP, TN, FP, FN);
	TP = 0, TN = 0, FP = 0, FN = 0;
}


int main(int argc, char **argv) {
	int i;
	if (argc == 1) {
		printf("No Parameters\n\n");
		printf("./line -train checkin_file.txt -friendship friendship_file.txt -virtuallinkage virtuallinkage_file.txt -output embedding_file.txt -size 150 -negative 50 -rho 0.005 -threads 20\n\n");
		return 0;
	}
	if ((i = ArgPos((char *)"-train", argc, argv)) > 0) strcpy(checkin_file, argv[i + 1]);
	if ((i = ArgPos((char *)"-friendship", argc, argv)) > 0) strcpy(friendship_file, argv[i + 1]);
	if ((i = ArgPos((char *)"-virtuallinkage", argc, argv)) > 0) strcpy(virtuallinkage_file, argv[i + 1]);
	if ((i = ArgPos((char *)"-output", argc, argv)) > 0) strcpy(embedding_file, argv[i + 1]);
	if ((i = ArgPos((char *)"-size", argc, argv)) > 0) dim = atoi(argv[i + 1]);
	if ((i = ArgPos((char *)"-negative", argc, argv)) > 0) num_negative = atoi(argv[i + 1]);
	if ((i = ArgPos((char *)"-rho", argc, argv)) > 0) init_rho = atof(argv[i + 1]);
	if ((i = ArgPos((char *)"-threads", argc, argv)) > 0) num_threads = atoi(argv[i + 1]);
	rho = init_rho;
	vertex = (struct ClassVertex *)calloc(max_num_vertices, sizeof(struct ClassVertex));

	user_vid = (int *)calloc(max_num_vertices, sizeof(int));
	poi_vid = (int *)calloc(max_num_vertices, sizeof(int));
	poi_category_vid = (int *)calloc(max_num_vertices, sizeof(int));
	time_vid = (int *)calloc(max_num_vertices, sizeof(int));
	category_vid = (int *)calloc(max_num_vertices, sizeof(int));

	Experiment();
	predict();
	return 0;
}
