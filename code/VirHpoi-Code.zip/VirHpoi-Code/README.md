# VirHpoi
 Efficient Point-of-Interest Recommendation Services with Heterogenous Hypergraph Embedding

## Getting Started
### Prerequisites
Install BOOST package

- raw datasets:

   -- Global-scale Check-in Dataset with User Social Networks: https://sites.google.com/site/yangdingqi/home/foursquare-dataset

### File Structure:
```
VirHpoi
├── dataset
│   └── JK
├── virtual hyperedge
│   ├── geographical
│   │   ├── main.py
│   │   └── PowerLaw.py
│   ├── semantic.py
│   ├── linkage decision.py
│   └── process.py
└── virtual
     └── virtual.cpp
```
There are several parts of the code:
- dataset folder: This folder contains the processed dataset for Jakarta city.  Users who have check-ins at least 5 times and POIs with more than 10 visitors are selected.

- geographical folder: This folder contains the calculation for geographical similarity
- semantic.py: This file contains the calculation for semantic similarity
- linkage decision.py: This file contains clustering models and constructs virtual hyperedges.
- process.py: This file mainly contains the preprocessing of the raw dataset in dataset folder.

- virtual.cpp: This file trains models, gets the embeddings of LBSNs and evaluate the model.

## Execute RecUP
*** Run linkage decision.py  ***
*** Run process.py  ***
*** Run virtual.cpp  ***

