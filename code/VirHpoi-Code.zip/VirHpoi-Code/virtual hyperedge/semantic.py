import numpy as np

f1 = open('../dataset/JK/Checkins_anonymized.txt', 'r')
f2 = open('../dataset/JK/POIs.txt', 'r')
data1 = f1.readlines()
data2 = f2.readlines()
list1 = list(data1)

i = 0
for line in list1:
    timeslot = str(line.split('\t')[2])

    if "Mon" in timeslot:
        time = int(timeslot[11:13])
        timefinal = time

    elif "Tue" in timeslot:
        time = int(timeslot[11:13])
        timefinal = 24 + time

    elif "Wed" in timeslot:
        time = int(timeslot[11:13])
        timefinal = 48 + time

    elif "Thu" in timeslot:
        time = int(timeslot[11:13])
        timefinal = 72 + time

    elif "Fri" in timeslot:
        time = int(timeslot[11:13])
        timefinal = 96 + time

    elif "Sat" in timeslot:
        time = int(timeslot[11:13])
        timefinal = 120 + time

    elif "Sun" in timeslot:
        time = int(timeslot[11:13])
        timefinal = 144 + time

    list1[i] = line.strip('\n') + "\t" + str(timefinal) + "\n"
    i += 1

size = len(data2)
A = np.zeros((size, 168))
for eachline2 in list1:
    context = int(eachline2.split('\t')[1])
    timeslott = int(eachline2.split('\t')[4])
    A[context][timeslott] += 1

semantic_similarity = np.zeros((size, size))
a = 0
b = 0
while a < size:
    x = A[a]
    while b < size:
        y = A[b]
        num = x.dot(y.T)
        denom = np.linalg.norm(x) * np.linalg.norm(y)
        semantic_similarity[a][b] = float(num)/denom    #168
        b += 1
    a += 1
    b = 0

np.save('semantic_similarity.npy', semantic_similarity)

f1.close()
f2.close()
