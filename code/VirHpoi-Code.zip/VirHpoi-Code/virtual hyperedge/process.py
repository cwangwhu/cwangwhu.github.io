import numpy as np
import datetime

f1 = open('../dataset/JK/Checkins_anonymized.txt', 'r')
f2 = open('../dataset/JK/POIs.txt', 'r')
f3 = open('../dataset/JK/Friendship.txt', 'r')
f4 = open('virtuallink.txt', 'r')

f5 = open('../virtual/checkin_file.txt', 'w')
f6 = open('../virtual/checkin_file_new.txt', 'w')
f7 = open('../virtual/friendship_file.txt', 'w')
f8 = open('../virtual/virtuallinkage_file.txt', 'w')

data1 = f1.readlines()
data2 = f2.readlines()
data3 = f3.readlines()
data4 = f4.readlines()
checkins = list(data1)
pois = list(data2)
Friendship = list(data3)
virtuallink = list(data4)
result = []
train = []
test = []
friendship = []
i = 0
for line in checkins:
    timeslot = str(line.split('\t')[2])

    if "Mon" in timeslot:
        time = int(timeslot[11:13])
        timefinal = time

    elif "Tue" in timeslot:
        time = int(timeslot[11:13])
        timefinal = 24 + time

    elif "Wed" in timeslot:
        time = int(timeslot[11:13])
        timefinal = 48 + time

    elif "Thu" in timeslot:
        time = int(timeslot[11:13])
        timefinal = 72 + time

    elif "Fri" in timeslot:
        time = int(timeslot[11:13])
        timefinal = 96 + time

    elif "Sat" in timeslot:
        time = int(timeslot[11:13])
        timefinal = 120 + time

    elif "Sun" in timeslot:
        time = int(timeslot[11:13])
        timefinal = 144 + time

    checkins[i] = line.strip('\n') + "\t" + str(timefinal) + "\n"
    i += 1
b = 0

def get_list(date):
    return datetime.datetime.strptime(date, "%a %b %d %H:%M:%S +0000 %Y").timestamp()

for i in range(len(checkins)):
    result.append([])
    line = checkins[i].split('\t')
    result[i].append(line[0])
    result[i].append(line[1])
    result[i].append(line[4].strip('\n'))
    result[i].append(pois[int(line[1])].split('\t')[3])
    result[i].append(get_list(line[2]))

user_dict = {}
poi_dict = {}
time_dict = {}
category_dict = {}

result.sort(key=lambda x: int(x[0]))
context = result[0][0]
count = 0
num = 0
user_dict[context] = num
for eachline1 in result:
    context1 = result[count][0]
    if context != context1:
        num += 1
        user_dict[context1] = num
    result[int(count)][0] = num
    count += 1
    context = context1

result.sort(key=lambda x: int(x[1]))
context = result[0][1]
count = 0
num += 1
poi_dict[context] = num
for eachline1 in result:
    context1 = result[count][1]
    if context != context1:
        num += 1
        poi_dict[context1] = num
    result[int(count)][1] = num
    count += 1
    context = context1

result.sort(key=lambda x: int(x[2]))
context = result[0][2]
count = 0
num += 1
time_dict[context] = num
for eachline1 in result:
    context1 = result[count][2]
    if context != context1:
        num += 1
        time_dict[context1] = num
    result[int(count)][2] = num
    count += 1
    context = context1

result.sort(key=lambda x: x[3])
context = result[0][3]
count = 0
num += 1
category_dict[context] = num
for eachline1 in result:
    context1 = result[count][3]
    if context != context1:
        num += 1
        category_dict[context1] = num
    result[int(count)][3] = num
    count += 1
    context = context1

result.sort(key=lambda x: x[0])

number = 0
context = 0
list1 = []
list2 = result.copy()
while len(list2) != 0:
    for eachline in list2:
        user = eachline[0]
        if int(user) == int(context):
            list1.append(eachline)
            context = eachline[0]
            number += 1
        else:
            context = user
            del list2[0:number]
            number = 0
            break
    if len(list2) == len(list1):
        list2 = []
    list1.sort(key=lambda x: x[4])
    leng = len(list1)
    leng = leng / 100 * 30 + 1
    j = 0
    for eachline in list1:
        j += 1
        if (j < leng):
            test.append(str(eachline[0]) + "\t" + str(eachline[1]) + "\t" + str(eachline[2]) + "\t" + str(
                eachline[3]) + '\n')
        else:
            train.append(str(eachline[0]) + "\t" + str(eachline[1]) + "\t" + str(eachline[2]) + "\t" + str(
                eachline[3]) + '\n')
    list1 = []

for i in range(len(Friendship)):
    line = Friendship[i].strip('\n').split('\t')
    Friendship[i] = str(user_dict[line[0]]) + '\t' + str(user_dict[line[1]]) + '\n'

for i in range(len(virtuallink)):
    line = virtuallink[i].strip('\n').split('\t')
    if line[0] not in poi_dict or line[1] not in poi_dict:
        continue
    virtuallink[i] = str(poi_dict[line[0]]) + '\t' + str(poi_dict[line[1]]) + '\n'

for line in train:
    f5.writelines(line)

for line in test:
    f6.writelines(line)

for line in Friendship:
    f7.writelines(line)

for line in virtuallink:
    f8.writelines(line)

f1.close()
f2.close()
f3.close()
f4.close()
f5.close()
f6.close()
f7.close()
f8.close()
