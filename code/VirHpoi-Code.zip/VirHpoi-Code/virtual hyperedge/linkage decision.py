import numpy as np
from sys import exit
from itertools import combinations, product
from scipy.spatial.distance import pdist, squareform
from collections import OrderedDict
import os

os.system('python semantic.py')
os.system('python geographical/main.py')

f1 = open('virtuallink.txt', 'w')

geographical = np.load('geographical/geographical_similarity.npy')
geographical2 = geographical.copy()
semantic = np.load('semantic_similarity.npy')


ratio = 0.8
topk = 100
size = geographical.shape[0]

a1 = 0
while a1 < size:
    geographical[a1][a1] = 0
    semantic[a1][a1] = 0
    a1 += 1
geographical2 = geographical2.reshape(1, size*size)
geographical2.sort()

ave = geographical2[0][int(size*size-topk*size/2)]

def sigmoid(x, useStatus):
    if useStatus:
        return 1.0 / (1 + np.exp(-float(x-ave)))
    else:
        return float(x)

a1 = 0
b1 = 0
while a1 < size:
    while b1 < size:
        x = geographical[a1][b1]
        geographical[a1][b1] = sigmoid(x, 1)
        b1 += 1
    b1 = 0
    a1 += 1

a1 = 0
while a1 < size:
    geographical[a1][a1] = 0
    a1 += 1

sim_Matrix = ratio*geographical + (1-ratio)*semantic
dist_Matrix = sim_Matrix

dist_Matrix_Vector = squareform(sim_Matrix)  
dist_Matrix_Matrix = sim_Matrix
n = int(np.ceil((dist_Matrix_Vector.size * 2) ** 0.5))  
indexes = combinations(range(n), 2)  

clusters = OrderedDict()  
cluster = []
initial_clusters = OrderedDict() 
last = 0
for idx, ids in zip(indexes, dist_Matrix_Vector): 
    cluster.append((idx, ids)) 
    if idx[0] != last:
        cluster.sort(key=lambda x: x[1], reverse=True)
        clusters[last] = cluster[0:2000]
        cluster = [(idx, ids)]
        last = idx[0]

output = []
used = []
while len(output) < n/5/2:
    pairs = []
    listpairs = []
    for idx in clusters:
        pairs.append(clusters[idx][0])
    # 获取最大类簇对儿
    pairs.sort(key=lambda x: x[1], reverse=True)
    while 1:
        max_cluster_pairs = pairs[0]
        (a, b) = max_cluster_pairs[0]
        if (a not in used) and (b not in used):
            break
        else:
            del pairs[0]

    listpairs = clusters[a] + clusters[b]
    used += [a, b]

    listpairs.sort(key=lambda x: x[1], reverse=True)
    while 1:
        second_cluster_pairs = listpairs[0]
        if second_cluster_pairs[0][1] not in used:
            c = second_cluster_pairs[0][1]
            break
        else:
            del listpairs[0]
    if c in clusters:
        listpairs += clusters[c]
    used += [c]

    listpairs.sort(key=lambda x: x[1], reverse=True)
    while 1:
        third_cluster_pairs = listpairs[0]
        if third_cluster_pairs[0][1] not in used:
            d = third_cluster_pairs[0][1]
            break
        else:
            del listpairs[0]
    if d in clusters:
        listpairs += clusters[d]
    used += [d]

    listpairs.sort(key=lambda x: x[1], reverse=True)
    while 1:
        fourth_cluster_pairs = listpairs[0]
        if fourth_cluster_pairs[0][1] not in used:
            e = fourth_cluster_pairs[0][1]
            break
        else:
            del listpairs[0]
    if e in clusters:
        listpairs += clusters[e]
    used += [e]

    output.append([a, b, c, d, e])
    if a in clusters:
        del clusters[a]
    if b in clusters:
        del clusters[b]
    if c in clusters:
        del clusters[c]
    if d in clusters:
        del clusters[d]
    if e in clusters:
        del clusters[e]

for item in output:
    indexes = combinations(item, 2)
    for idx in zip(indexes):
        f1.writelines(str(idx[0][0]) + '\t' + str(idx[0][1]) + '\n')
f1.close()

exit()

