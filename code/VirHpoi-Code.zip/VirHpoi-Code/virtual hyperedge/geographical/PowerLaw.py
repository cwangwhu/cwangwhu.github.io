import math
import time
import numpy as np
from collections import defaultdict
import matplotlib.pyplot as plt
import pwlf

def dist(loc1, loc2):
    lat1, long1 = loc1[0], loc1[1]
    lat2, long2 = loc2[0], loc2[1]
    if abs(lat1 - lat2) < 1e-6 and abs(long1 - long2) < 1e-6:
        return 0.0
    degrees_to_radians = math.pi / 180.0
    phi1 = (90.0 - lat1) * degrees_to_radians
    phi2 = (90.0 - lat2) * degrees_to_radians
    theta1 = long1 * degrees_to_radians
    theta2 = long2 * degrees_to_radians
    cos = (math.sin(phi1) * math.sin(phi2) * math.cos(theta1 - theta2) +
           math.cos(phi1) * math.cos(phi2))
    arc = math.acos(cos)
    earth_radius = 6371
    return arc * earth_radius


class PowerLaw(object):
    def __init__(self, a=None, b=None):
        self.a = a
        self.b = b
        self.check_in_matrix = None
        self.visited_lids = {}
        self.poi_coos = None

    @staticmethod
    def compute_distance_distribution(check_in_matrix, poi_coos):
        distribution = defaultdict(int)
        for uid in range(check_in_matrix.shape[0]):
            lids = check_in_matrix[uid, :].nonzero()[0] 
            for i in range(len(lids)): 
                for j in range(i + 1, len(lids)): 
                    lid1, lid2 = lids[i], lids[j]
                    coo1, coo2 = poi_coos[lid1], poi_coos[lid2]
                    distance = int(dist(coo1, coo2))
                    distribution[distance] += 1
        total = 1.0 * sum(distribution.values())
        for distance in distribution:
            distribution[distance] /= total
        distribution = sorted(distribution.items(), key=lambda k: k[0])

        # distribution2 = [(elem1, log(elem2)) for elem1, elem2 in distribution]
        """
        font = {'family': 'Times New Roman',
            'weight': 'normal',
            'size': 20,
            }

        plt.figure(figsize=(5, 4))
        plt.loglog(*zip(*distribution), '.', Marker='.')
        plt.ylabel("Checkin Probability (log)", font)
        plt.xlabel("Physical Distance - km (log)", font)
        # plt.ylim(0.0001, 1)

        # plt.title(yLabel)
        plt.xticks(fontsize=20, fontfamily='Times New Roman')
        plt.yticks(fontsize=20, fontfamily='Times New Roman')
        # plt.savefig("./1.pdf", bbox_inches='tight')
        plt.show()
        """


        return zip(*distribution[1:])

    def fit_distance_distribution(self, check_in_matrix, poi_coos):
        self.check_in_matrix = check_in_matrix
        for uid in range(check_in_matrix.shape[0]):
            self.visited_lids[uid] = check_in_matrix[uid, :].nonzero()[0]

        print("Fitting distance distribution...", )
        self.poi_coos = poi_coos
        x, t = self.compute_distance_distribution(check_in_matrix, poi_coos)
        x = np.log10(x)
        t = np.log10(t)
        global my_pwlf
        my_pwlf = pwlf.PiecewiseLinFit(x, t)
        my_pwlf.fit(3)
        xHat = np.sort(x)
        yHat = my_pwlf.predict(xHat)
        plt.figure()
        plt.plot(x, t, 'o')
        plt.plot(xHat, yHat, '-')
        plt.show()
        print("Fitting distance distribution over", )

    def pr_d(self, d):
        d = max(0.01, d)
        d = np.log10(d)
        y = my_pwlf.predict(d)[0]
        return 10 ** y

    def predict(self, uid, lj):
        lj = self.poi_coos[lj]
        print("predict", )
        return np.prod([self.pr_d(dist(self.poi_coos[li], lj)) for li in self.visited_lids[uid]])

    def similar(self, li, lj):
        li = self.poi_coos[li]
        lj = self.poi_coos[lj]
        return self.pr_d(dist(li, lj))
