import numpy as np
from PowerLaw import PowerLaw
import datetime

def read_poi_coos():
    poi_coos = {}
    print("poi")
    poi_data = list2
    for eachline in poi_data:
        lid, lat, lng, _, _ = eachline.strip().split('\t')
        lid, lat, lng = int(lid), float(lat), float(lng)
        poi_coos[lid] = (lat, lng)
    return poi_coos


def read_training_data():
    print("checkins")
    training_matrix = np.zeros((user_num, poi_num))
    for eachline in train_data:
        uid, lid = int(eachline[5]), int(eachline[1])
        training_matrix[uid, lid] = 1.0
    return training_matrix


def main():
    training_matrix = read_training_data()
    poi_coos = read_poi_coos()
    print("main")
    G.fit_distance_distribution(training_matrix, poi_coos)
    m = 0
    n = 0
    geographical_similarity = np.zeros((poi_num, poi_num))
    while m < poi_num:
        while n < poi_num:
            geographical_similarity[m][n] = G.similar(m, n)
            n = n + 1
        n = 0
        m = m + 1
    np.save('geographical_similarity.npy', geographical_similarity)


if __name__ == '__main__':
    f1 = open('../../dataset/JK/Checkins_anonymized.txt', 'r')
    f2 = open('../../dataset/JK/POIs.txt', 'r')
    data1 = f1.readlines()
    data2 = f2.readlines()
    list1 = list(data1)
    list2 = list(data2)
    poi_num = len(list2)
    train_data = []
    linelist = []

    def get_list(date):
        return datetime.datetime.strptime(date, "%a %b %d %H:%M:%S +0000 %Y").timestamp()

    last_user = list1[0].strip('\n').split("\t")[0]
    for eachline in data1:
        eachlinestrlist = eachline.strip('\n').split("\t")
        user = eachlinestrlist[0]
        if user != last_user:
            last_user = user
            linelist.sort(key=lambda x: x[4])
            train_data.extend(linelist)
            linelist = []
        J = eachlinestrlist[2]
        T = get_list(J)
        eachlinestrlist.append(T)
        linelist.append(eachlinestrlist)
    train_data.extend(linelist)

    t = 0
    last_context = train_data[0][0]
    for i in range(len(train_data)):
        context = int(train_data[i][0])
        if int(last_context) != int(context):
            t = t + 1
        train_data[i].append(str(t))
        last_context = context
    user_num = t+1

    G: object = PowerLaw()

    main()
