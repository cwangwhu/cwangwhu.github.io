# HiLS
Revisiting Long- and Short-term Preference Learning for Next POI Recommendation with Hierarchical LSTM

## Getting Started
### Prerequisites
To run this repository, we kindly advise you to install python 3.7.13, Pytorch 1.8.1 and other dependencies (e.g., numpy 1.21.6, pickle 0.7.5) with Anaconda and read the installation instruction on the official website (https://www.anaconda.com)
Create a new environment and install packages on it.

- load datasets:

   -- NYC and Tokyo Check-in Dataset: https://sites.google.com/site/yangdingqi/home/foursquare-dataset

- Code structure:

   -- traces.py: the preprocessing of the raw data in datasets.
   
   -- HiLS.py: the implement of HiLS

## Execute HiLS
*** Run python3 main.py  ***