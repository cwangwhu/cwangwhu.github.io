import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
import pickle
import numpy as np
import torch
from collections import defaultdict
import gc
import os
from math import radians, cos, sin, asin, sqrt
from collections import deque, Counter

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def shuffle(*arrays, **kwargs):
    require_indices = kwargs.get('indices', False)
    if len(set(len(x) for x in arrays)) != 1:
        raise ValueError('All inputs to shuffle must have '
                         'the same length.')
    shuffle_indices = np.arange(len(arrays[0]))
    np.random.shuffle(shuffle_indices)
    if len(arrays) == 1:
        result = arrays[0][shuffle_indices]
    else:
        result = tuple(x[shuffle_indices] for x in arrays)
    if require_indices:
        return result, shuffle_indices
    else:
        return result


def minibatch(*tensors, **kwargs):
    batch_size = kwargs.get('batch_size', 128)
    if len(tensors) == 1:
        tensor = tensors[0]
        for i in range(0, len(tensor), batch_size):
            yield tensor[i:i + batch_size]
    else:
        for i in range(0, len(tensors[0]), batch_size):
            yield tuple(x[i:i + batch_size] for x in tensors)


def pad_batch_of_lists_masks(batch_of_lists, batch_of_lists_tim, batch_of_lists_cai, batch_of_lists_geo, max_len):
    padded = [l + [0] * (max_len - len(l)) for l in batch_of_lists]
    padded_tim = [l + [0] * (max_len - len(l)) for l in batch_of_lists_tim]
    padded_cai = [l + [0] * (max_len - len(l)) for l in batch_of_lists_cai]
    padded_geo = [l + [0] * (max_len - len(l)) for l in batch_of_lists_geo]
    padded_mask = [[1.0] * (len(l) - 1) + [0.0] * (max_len - len(l) + 1) for l in batch_of_lists]
    padde_mask_non_local = [[1.0] * (len(l)) + [0.0] * (max_len - len(l)) for l in batch_of_lists]
    return padded, padded_tim, padded_cai, padded_geo, padded_mask, padde_mask_non_local


class Model(nn.Module):
    def __init__(self, n_users, n_items, n_cai, n_geo, emb_size=500, hidden_units=500, dropout=0.8, user_dropout=0.5,
                 data_neural=None, tim_sim_matrix=None):
        super(self.__class__, self).__init__()
        self.n_users = n_users
        self.n_items = n_items
        self.n_cai = n_cai
        self.n_geo = n_geo
        self.hidden_units = hidden_units
        if emb_size == None:
            emb_size = hidden_units
        self.emb_size = emb_size
        self.item_emb = nn.Embedding(n_items, emb_size)
        self.tim_emb = nn.Embedding(48, emb_size)
        self.cai_emb = nn.Embedding(n_cai, emb_size)
        self.geo_emb = nn.Embedding(n_geo, emb_size)

        self.tim_sim_matrix = tim_sim_matrix

        self.semlevel_size = emb_size * 3
        self.semlevel_hidden_units = emb_size
        self.semlevel_units_input = emb_size
        self.poilevel_size = emb_size + self.semlevel_units_input

        self.poi_lstm = nn.LSTM(input_size=self.poilevel_size, hidden_size=hidden_units)
        self.poi_lstm_history = nn.LSTM(input_size=self.poilevel_size, hidden_size=hidden_units)
        self.sem_lstm = nn.LSTM(input_size=self.semlevel_size, hidden_size=self.semlevel_hidden_units)
        self.sem_lstm_history = nn.LSTM(input_size=self.semlevel_size, hidden_size=self.semlevel_hidden_units)

        self.linear = nn.Linear(hidden_units * 2, n_items)
        self.linear_1 = nn.Linear(self.semlevel_hidden_units * 2, n_cai)
        self.dropout = nn.Dropout(0.0)
        self.user_dropout = nn.Dropout(user_dropout)
        self.data_neural = data_neural
        self.linear1 = nn.Linear(hidden_units, hidden_units)
        self.linear2 = nn.Linear(self.semlevel_hidden_units, self.semlevel_hidden_units)

        self.linear_short = nn.Linear(self.semlevel_hidden_units, self.semlevel_units_input)
        self.linear_long = nn.Linear(self.semlevel_hidden_units, self.semlevel_units_input)
        self.init_weights()

    def init_weights(self):
        ih = (param.data for name, param in self.named_parameters() if 'weight_ih' in name)
        hh = (param.data for name, param in self.named_parameters() if 'weight_hh' in name)
        b = (param.data for name, param in self.named_parameters() if 'bias' in name)
        for t in ih:
            nn.init.xavier_uniform_(t)
        for t in hh:
            nn.init.orthogonal_(t)
        for t in b:
            nn.init.constant_(t, 0)

    def forward(self, user_vectors, item_vectors, mask_batch_ix_non_local, session_id_batch, tim_vectors, cai_vectors,
                geo_vectors, is_train, sequence_tim_batch):
        batch_size = item_vectors.size()[0]
        sequence_size = item_vectors.size()[1]
        items = self.item_emb(item_vectors)
        cais = self.cai_emb(cai_vectors)
        geos = self.geo_emb(geo_vectors)
        tims = self.tim_emb(tim_vectors)

        # ###########################################################
        # short-term preference
        # semantic level
        x_sem = torch.cat((cais, tims, geos), 2)
        x_sem = x_sem.transpose(0, 1)
        h1 = Variable(torch.zeros(1, batch_size, self.semlevel_hidden_units)).cuda()
        c1 = Variable(torch.zeros(1, batch_size, self.semlevel_hidden_units)).cuda()
        out_sem, (h1, c1) = self.sem_lstm(x_sem, (h1, c1))
        out_sem = out_sem.transpose(0, 1)

        # POI level
        out_sem_input = torch.selu(self.linear_short(out_sem))
        x_poi = torch.cat([items, out_sem_input], dim=2).transpose(0, 1)
        h2 = Variable(torch.zeros(1, batch_size, self.hidden_units)).cuda()
        c2 = Variable(torch.zeros(1, batch_size, self.hidden_units)).cuda()
        out_poi, (h2, c2) = self.poi_lstm(x_poi, (h2, c2))
        out_poi = out_poi.transpose(0, 1)

        # ###########################################################
        # long-term preference
        user_batch = np.array(user_vectors.cpu())
        poi_list = []
        sem_list = []
        for ii in range(batch_size):
            user_id_current = user_batch[ii]
            current_session_timid = sequence_tim_batch[ii][:-1]
            session_id_current = session_id_batch[ii]
            current_poi_embed = out_poi[ii]
            current_sem_embed = out_sem[ii]
            current_session_mask = mask_batch_ix_non_local[ii].unsqueeze(1)
            sequence_length = int(sum(np.array(current_session_mask.cpu()))[0])
            current_poi_represent_list = []
            current_sem_represent_list = []
            if is_train:
                for iii in range(sequence_length - 1):
                    current_session_represent = torch.sum(current_poi_embed * current_session_mask, dim=0).unsqueeze(
                        0) / sum(current_session_mask)
                    current_poi_represent_list.append(current_session_represent)
                    current_session_represent_2 = torch.sum(current_sem_embed * current_session_mask, dim=0).unsqueeze(
                        0) / sum(current_session_mask)
                    current_sem_represent_list.append(current_session_represent_2)
            else:
                for iii in range(sequence_length - 1):
                    current_poi_represent_rep_item = current_poi_embed[0:iii + 1]
                    current_poi_represent_rep_item = torch.sum(current_poi_represent_rep_item, dim=0).unsqueeze(0) / (
                                iii + 1)
                    current_poi_represent_list.append(current_poi_represent_rep_item)
                    current_sem_represent_rep_item = current_sem_embed[0:iii + 1]
                    current_sem_represent_rep_item = torch.sum(current_sem_represent_rep_item, dim=0).unsqueeze(0) / (
                                iii + 1)
                    current_sem_represent_list.append(current_sem_represent_rep_item)
            current_poi_session_represent = torch.cat(current_poi_represent_list, dim=0)
            current_sem_session_represent = torch.cat(current_sem_represent_list, dim=0)
            history_poi_represent_list = []
            history_sem_represent_list = []
            h2_l = Variable(torch.zeros(1, 1, self.hidden_units)).cuda()
            c2_l = Variable(torch.zeros(1, 1, self.hidden_units)).cuda()
            h1_l = Variable(torch.zeros(1, 1, self.semlevel_hidden_units)).cuda()
            c1_l = Variable(torch.zeros(1, 1, self.semlevel_hidden_units)).cuda()
            for jj in range(session_id_current):
                item = [s[0] for s in self.data_neural[user_id_current]['sessions'][jj]]
                cai = [s[2] for s in self.data_neural[user_id_current]['sessions'][jj]]
                geo = [s[3] for s in self.data_neural[user_id_current]['sessions'][jj]]
                tim = [s[1] for s in self.data_neural[user_id_current]['sessions'][jj]]
                item = Variable(torch.LongTensor(np.array(item))).cuda()
                item_emb = self.item_emb(item).unsqueeze(1)
                cai = Variable(torch.LongTensor(np.array(cai))).cuda()
                cai_emb = self.cai_emb(cai).unsqueeze(1)
                geo = Variable(torch.LongTensor(np.array(geo))).cuda()
                geo_emb = self.geo_emb(geo).unsqueeze(1)
                tim = Variable(torch.LongTensor(np.array(tim))).cuda()
                tim_emb = self.tim_emb(tim).unsqueeze(1)
                x_sem_l = torch.cat((cai_emb, tim_emb, geo_emb), 2)
                out_sem_l, (h1_l, c1_l) = self.sem_lstm_history(x_sem_l, (h1_l, c1_l))
                out_sem_l_input = torch.selu(self.linear_long(out_sem_l))
                x_poi_l = torch.cat([item_emb, out_sem_l_input], dim=2)
                out_poi_l, (h2_l, c2_l) = self.poi_lstm_history(x_poi_l, (h2_l, c2_l))
                sequence_tim_id = [s[1] for s in self.data_neural[user_id_current]['sessions'][jj]]
                jaccard_sim_row = Variable(torch.FloatTensor(self.tim_sim_matrix[current_session_timid]),
                                           requires_grad=False).cuda()
                jaccard_sim_expicit = jaccard_sim_row[:, sequence_tim_id]
                jaccard_sim_expicit_last = F.softmax(jaccard_sim_expicit)
                hidden_poi_for_current = torch.mm(jaccard_sim_expicit_last, out_poi_l.squeeze(1))
                history_poi_represent_list.append(hidden_poi_for_current.unsqueeze(0))
                hidden_sem_for_current = torch.mm(jaccard_sim_expicit_last, out_sem_l.squeeze(1))
                history_sem_represent_list.append(hidden_sem_for_current.unsqueeze(0))
            history_poi_represent = torch.cat(history_poi_represent_list, dim=0).transpose(0, 1)
            history_sem_represent = torch.cat(history_sem_represent_list, dim=0).transpose(0, 1)
            current_poi_session_represent = current_poi_session_represent.unsqueeze(2)
            current_sem_session_represent = current_sem_session_represent.unsqueeze(2)
            sims_poi = F.softmax(history_poi_represent.bmm(current_poi_session_represent).squeeze(2), dim=1).unsqueeze(
                1)
            sims_sem = F.softmax(history_sem_represent.bmm(current_sem_session_represent).squeeze(2), dim=1).unsqueeze(
                1)
            out_poi_current = torch.selu(self.linear1(sims_poi.bmm(history_poi_represent).squeeze(1)))
            out_sem_current = torch.selu(self.linear2(sims_sem.bmm(history_sem_represent).squeeze(1)))
            out_poi_current = out_poi_current.unsqueeze(2)
            poi_2_sims = F.softmax(history_poi_represent.bmm(out_poi_current).squeeze(2) * 1.0, dim=1).unsqueeze(1)
            out_poi_layer_2 = poi_2_sims.bmm(history_poi_represent).squeeze(1)
            out_current_padd = Variable(torch.FloatTensor(sequence_size - sequence_length + 1, self.emb_size).zero_(),
                                        requires_grad=False).cuda()
            out_current_padd_2 = Variable(
                torch.FloatTensor(sequence_size - sequence_length + 1, self.semlevel_hidden_units).zero_(),
                requires_grad=False).cuda()
            out_poi_layer_2_list = []
            out_sem_layer_2_list = []
            out_poi_layer_2_list.append(out_poi_layer_2)
            out_poi_layer_2_list.append(out_current_padd)
            out_sem_layer_2_list.append(out_sem_current)
            out_sem_layer_2_list.append(out_current_padd_2)
            out_poi_layer_2 = torch.cat(out_poi_layer_2_list, dim=0).unsqueeze(0)
            out_sem_layer_2 = torch.cat(out_sem_layer_2_list, dim=0).unsqueeze(0)
            poi_list.append(out_poi_layer_2)
            sem_list.append(out_sem_layer_2)
        y_poi = torch.selu(torch.cat(poi_list, dim=0))
        y_sem = torch.selu(torch.cat(sem_list, dim=0))
        out_poi = F.selu(out_poi)
        out_sem = F.selu(out_sem)
        out_put_emb_poi = torch.cat([y_poi, out_poi], dim=2)
        out_put_emb_sem = torch.cat([y_sem, out_sem], dim=2)
        output_ln_poi = self.linear(out_put_emb_poi)
        output_poi = F.log_softmax(output_ln_poi, dim=-1)
        output_ln_sem = self.linear_1(out_put_emb_sem)
        output_sem = F.log_softmax(output_ln_sem, dim=-1)
        return output_poi, output_sem


def generate_input_history(data_neural, mode, candidate=None):
    data_train = {}
    train_idx = {}
    if candidate is None:
        candidate = data_neural.keys()
    for u in candidate:
        sessions = data_neural[u]['sessions']
        train_id = data_neural[u][mode]
        data_train[u] = {}
        for c, i in enumerate(train_id):
            if mode == 'train' and c == 0:
                continue
            session = sessions[i]
            trace = {}
            loc_np = np.reshape(np.array([s[0] for s in session[:-1]]), (len(session[:-1]), 1))
            tim_np = np.reshape(np.array([s[1] for s in session[:-1]]), (len(session[:-1]), 1))
            target = np.array([s[0] for s in session[1:]])
            trace['loc'] = Variable(torch.LongTensor(loc_np))
            trace['target'] = Variable(torch.LongTensor(target))
            trace['tim'] = Variable(torch.LongTensor(tim_np))
            history = []
            if mode == 'test':
                test_id = data_neural[u]['train']
                for tt in test_id:
                    history.extend([(s[0], s[1]) for s in sessions[tt]])
            for j in range(c):
                history.extend([(s[0], s[1]) for s in sessions[train_id[j]]])
            history = sorted(history, key=lambda x: x[1], reverse=False)
            history_loc = np.reshape(np.array([s[0] for s in history]), (len(history), 1))
            history_tim = np.reshape(np.array([s[1] for s in history]), (len(history), 1))
            trace['history_loc'] = Variable(torch.LongTensor(history_loc))
            trace['history_tim'] = Variable(torch.LongTensor(history_tim))
            data_train[u][i] = trace
        train_idx[u] = train_id
    return data_train, train_idx


def generate_input_long_history(data_neural, mode, candidate=None):
    data_train = {}
    train_idx = {}
    if candidate is None:
        candidate = data_neural.keys()
    for u in candidate:
        sessions = data_neural[u]['sessions']
        train_id = data_neural[u][mode]
        data_train[u] = {}
        for c, i in enumerate(train_id):
            trace = {}
            if mode == 'train' and c == 0:
                continue
            session = sessions[i]
            target = np.array([s[0] for s in session[1:]])
            history = []
            if mode == 'test':
                test_id = data_neural[u]['train']
                for tt in test_id:
                    history.extend([(s[0], s[1]) for s in sessions[tt]])
            for j in range(c):
                history.extend([(s[0], s[1]) for s in sessions[train_id[j]]])
            history_tim = [t[1] for t in history]
            history_count = [1]
            last_t = history_tim[0]
            count = 1
            for t in history_tim[1:]:
                if t == last_t:
                    count += 1
                else:
                    history_count[-1] = count
                    history_count.append(1)
                    last_t = t
                    count = 1
            history_loc = np.reshape(np.array([s[0] for s in history]), (len(history), 1))
            history_tim = np.reshape(np.array([s[1] for s in history]), (len(history), 1))
            trace['history_loc'] = Variable(torch.LongTensor(history_loc))
            trace['history_tim'] = Variable(torch.LongTensor(history_tim))
            trace['history_count'] = history_count
            loc_tim = history
            loc_tim.extend([(s[0], s[1]) for s in session[:-1]])
            loc_np = np.reshape(np.array([s[0] for s in loc_tim]), (len(loc_tim), 1))
            tim_np = np.reshape(np.array([s[1] for s in loc_tim]), (len(loc_tim), 1))
            trace['loc'] = Variable(torch.LongTensor(loc_np))
            trace['tim'] = Variable(torch.LongTensor(tim_np))
            trace['target'] = Variable(torch.LongTensor(target))
            data_train[u][i] = trace
        train_idx[u] = train_id
    return data_train, train_idx


def generate_queue(train_idx, mode, mode2):
    user = list(train_idx.keys())
    train_queue = list()
    if mode == 'random':
        initial_queue = {}
        for u in user:
            if mode2 == 'train':
                initial_queue[u] = deque(train_idx[u][1:])
            else:
                initial_queue[u] = deque(train_idx[u])
        queue_left = 1
        while queue_left > 0:
            for j, u in enumerate(user):
                if len(initial_queue[u]) > 0:
                    train_queue.append((u, initial_queue[u].popleft()))
            queue_left = sum([1 for x in initial_queue if len(initial_queue[x]) > 0])
    elif mode == 'normal':
        for u in user:
            for i in train_idx[u]:
                train_queue.append((u, i))
    return train_queue


def generate_batch_data(one_train_batch):
    session_id_batch = []
    user_id_batch = []
    sequence_batch = []
    sequences_lens_batch = []
    sequences_tim_batch = []
    sequences_geo_batch = []
    sequences_cai_batch = []
    for sample in one_train_batch:
        user_id_batch.append(sample[0])
        session_id_batch.append(sample[1])
        session_sequence_current = [s[0] for s in data_neural[sample[0]]['sessions'][sample[1]]]  # 当前兴趣点序列
        session_sequence_tim_current = [s[1] for s in data_neural[sample[0]]['sessions'][sample[1]]]  # 当前时间序列
        session_sequence_cai_current = [s[2] for s in data_neural[sample[0]]['sessions'][sample[1]]]  # 当前活动类别序列
        session_sequence_geo_current = [s[3] for s in data_neural[sample[0]]['sessions'][sample[1]]]  # 当前距离序列
        sequence_batch.append(session_sequence_current)
        sequences_lens_batch.append(len(session_sequence_current))
        sequences_tim_batch.append(session_sequence_tim_current)
        sequences_cai_batch.append(session_sequence_cai_current)
        sequences_geo_batch.append(session_sequence_geo_current)
    return user_id_batch, session_id_batch, sequence_batch, sequences_lens_batch, sequences_tim_batch, sequences_cai_batch, sequences_geo_batch


def train_network(network, poi_cai, num_epoch=20, batch_size=32, criterion=None):
    candidate = data_neural.keys()
    data_train, train_idx = generate_input_history(data_neural, 'train', candidate=candidate)
    for epoch in range(num_epoch):
        network.train(True)
        i = 0
        run_queue = generate_queue(train_idx, 'random', 'train')
        for one_train_batch in minibatch(run_queue, batch_size=batch_size):
            user_id_batch, session_id_batch, sequence_batch, sequences_lens_batch, sequence_tim_batch, session_cai_batch, session_geo_batch = generate_batch_data(
                one_train_batch)

            max_len = max(sequences_lens_batch)
            padded_sequence_batch, padded_sequence_tim_batch, padded_sequence_cai_batch, padded_sequence_geo_batch, mask_batch_ix, mask_batch_ix_non_local = pad_batch_of_lists_masks(
                sequence_batch, sequence_tim_batch, session_cai_batch, session_geo_batch,
                max_len)

            padded_sequence_batch = Variable(torch.LongTensor(np.array(padded_sequence_batch))).to(device)
            padded_sequence_tim_batch = Variable(torch.LongTensor(np.array(padded_sequence_tim_batch))).to(device)
            padded_sequence_cai_batch = Variable(torch.LongTensor(np.array(padded_sequence_cai_batch))).to(device)
            padded_sequence_geo_batch = Variable(torch.LongTensor(np.array(padded_sequence_geo_batch))).to(device)
            mask_batch_ix = Variable(torch.FloatTensor(np.array(mask_batch_ix))).to(device)
            mask_batch_ix_non_local = Variable(torch.FloatTensor(np.array(mask_batch_ix_non_local))).to(device)
            user_id_batch = Variable(torch.LongTensor(np.array(user_id_batch))).to(device)

            logp_seq_poi, logp_seq_sem = network(user_id_batch, padded_sequence_batch, mask_batch_ix_non_local,
                                                 session_id_batch, padded_sequence_tim_batch, padded_sequence_cai_batch,
                                                 padded_sequence_geo_batch, True, sequence_tim_batch)

            predictions_logp_poi = logp_seq_poi[:, :-1] * mask_batch_ix[:, :-1, None]
            predictions_logp_sem = logp_seq_sem[:, :-1] * mask_batch_ix[:, :-1, None]

            actual_next_tokens = padded_sequence_batch[:, 1:]
            actual_next_tokens_cai = padded_sequence_cai_batch[:, 1:]

            logp_next = torch.gather(predictions_logp_poi, dim=2, index=actual_next_tokens[:, :, None])
            logp_next_cai = torch.gather(predictions_logp_sem, dim=2, index=actual_next_tokens_cai[:, :, None])
            loss_poi = -logp_next.sum() / mask_batch_ix[:, :-1].sum()
            loss_sem = -logp_next_cai.sum() / mask_batch_ix[:, :-1].sum()
            loss = loss_poi + loss_sem

            opt.zero_grad()
            loss.backward()

            nn.utils.clip_grad_norm_(network.parameters(), 5.0)
            opt.step()
            if (i + 1) % 20 == 0:
                print("epoch" + str(epoch) + ": loss: " + str(loss))
            i += 1
        results, results2 = evaluate(network, poi_cai, 1)
        print("POI prediction Scores: ", results)
        print("Category prediction Scores: ", results2)


def get_acc(target, scores, scores_sem, poi_cai):
    target = target.data.cpu().numpy()
    val, idxx = scores.data.topk(100, 1)
    predx = idxx.cpu().numpy()
    val_sem, idxx_sem = scores_sem.data.topk(100, 1)
    predx_sem = idxx_sem.cpu().numpy()
    for i, p in enumerate(predx):
        for j, item in enumerate(p):
            if item not in poi_cai:
                continue
            if poi_cai[item] not in predx_sem[i]:
                predx[i][j] = 0

    acc = np.zeros((3, 1))
    ndcg = np.zeros((3, 1))
    for i, p in enumerate(predx):
        p = p.tolist()
        while 0 in p:
            p.remove(0)
        p = np.array(p)
        t = target[i]
        if t != 0:
            if t in p[:10] and t > 0:
                acc[0] += 1
                rank_list = list(p[:10])
                rank_index = rank_list.index(t)
                ndcg[0] += 1.0 / np.log2(rank_index + 2)
            if t in p[:5] and t > 0:
                acc[1] += 1
                rank_list = list(p[:5])
                rank_index = rank_list.index(t)
                ndcg[1] += 1.0 / np.log2(rank_index + 2)
            if t == p[0] and t > 0:
                acc[2] += 1
                rank_list = list(p[:1])
                rank_index = rank_list.index(t)
                ndcg[2] += 1.0 / np.log2(rank_index + 2)
        else:
            break
    return acc.tolist(), ndcg.tolist()


def get_acc_sem(target, scores):
    target = target.data.cpu().numpy()
    val, idxx = scores.data.topk(100, 1)
    predx = idxx.cpu().numpy()
    acc = np.zeros((6, 1))
    ndcg = np.zeros((6, 1))
    for i, p in enumerate(predx):
        t = target[i]
        if t != 0:
            if t in p[:100] and t > 0:
                acc[0] += 1
                rank_list = list(p[:100])
                rank_index = rank_list.index(t)
                ndcg[0] += 1.0 / np.log2(rank_index + 2)
            if t in p[:50] and t > 0:
                acc[1] += 1
                rank_list = list(p[:50])
                rank_index = rank_list.index(t)
                ndcg[1] += 1.0 / np.log2(rank_index + 2)
            if t in p[:25] and t > 0:
                acc[2] += 1
                rank_list = list(p[:25])
                rank_index = rank_list.index(t)
                ndcg[2] += 1.0 / np.log2(rank_index + 2)
            if t in p[:10] and t > 0:
                acc[3] += 1
                rank_list = list(p[:10])
                rank_index = rank_list.index(t)
                ndcg[3] += 1.0 / np.log2(rank_index + 2)
            if t in p[:5] and t > 0:
                acc[4] += 1
                rank_list = list(p[:5])
                rank_index = rank_list.index(t)
                ndcg[4] += 1.0 / np.log2(rank_index + 2)
            if t == p[0] and t > 0:
                acc[5] += 1
                rank_list = list(p[:1])
                rank_index = rank_list.index(t)
                ndcg[5] += 1.0 / np.log2(rank_index + 2)
        else:
            break
    return acc.tolist(), ndcg.tolist()


def caculate_time_sim(data_neural):
    time_checkin_set = defaultdict(set)
    for uid in data_neural:
        uid_sessions = data_neural[uid]
        for sid in uid_sessions['sessions']:
            session_current = uid_sessions['sessions'][sid]
            for checkin in session_current:
                timid = checkin[1]
                locid = checkin[0]
                if timid not in time_checkin_set:
                    time_checkin_set[timid] = set()
                time_checkin_set[timid].add(locid)
    sim_matrix = np.zeros((48, 48))
    for i in range(48):
        for j in range(48):
            set_i = time_checkin_set[i]
            set_j = time_checkin_set[j]
            jaccard_ij = len(set_i & set_j) / len(set_i | set_j)
            sim_matrix[i][j] = jaccard_ij
    return sim_matrix


def evaluate(network, poi_cai, batch_size=2):
    network.train(False)
    candidate = data_neural.keys()
    data_test, test_idx = generate_input_long_history(data_neural, 'test', candidate=candidate)
    users_acc = {}
    sem_acc = {}
    with torch.no_grad():
        run_queue = generate_queue(test_idx, 'normal', 'test')
        for one_test_batch in minibatch(run_queue, batch_size=batch_size):
            user_id_batch, session_id_batch, sequence_batch, sequences_lens_batch, sequence_tim_batch, session_cai_batch, session_geo_batch = generate_batch_data(
                one_test_batch)
            user_id_batch_test = user_id_batch
            max_len = max(sequences_lens_batch)
            padded_sequence_batch, padded_sequence_tim_batch, padded_sequence_cai_batch, padded_sequence_geo_batch, mask_batch_ix, mask_batch_ix_non_local = pad_batch_of_lists_masks(
                sequence_batch, sequence_tim_batch, session_cai_batch, session_geo_batch, max_len)

            padded_sequence_batch = Variable(torch.LongTensor(np.array(padded_sequence_batch))).to(device)
            padded_sequence_tim_batch = Variable(torch.LongTensor(np.array(padded_sequence_tim_batch))).to(device)
            padded_sequence_cai_batch = Variable(torch.LongTensor(np.array(padded_sequence_cai_batch))).to(device)
            padded_sequence_geo_batch = Variable(torch.LongTensor(np.array(padded_sequence_geo_batch))).to(device)
            mask_batch_ix = Variable(torch.FloatTensor(np.array(mask_batch_ix))).to(device)
            mask_batch_ix_non_local = Variable(torch.FloatTensor(np.array(mask_batch_ix_non_local))).to(device)
            user_id_batch = Variable(torch.LongTensor(np.array(user_id_batch))).to(device)

            logp_seq_poi, logp_seq_sem = network(user_id_batch, padded_sequence_batch, mask_batch_ix_non_local,
                                                 session_id_batch, padded_sequence_tim_batch, padded_sequence_cai_batch,
                                                 padded_sequence_geo_batch, True, sequence_tim_batch)
            # print(logp_seq)
            predictions_logp_poi = logp_seq_poi[:, :-1] * mask_batch_ix[:, :-1, None]
            predictions_logp_sem = logp_seq_sem[:, :-1] * mask_batch_ix[:, :-1, None]

            actual_next_tokens = padded_sequence_batch[:, 1:]
            actual_next_tokens_cai = padded_sequence_cai_batch[:, 1:]

            for ii, u_current in enumerate(user_id_batch_test):
                if u_current not in sem_acc:
                    sem_acc[u_current] = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
                acc, ndcg = get_acc_sem(actual_next_tokens_cai[ii], predictions_logp_sem[ii])

                sem_acc[u_current][1] += acc[5][0]
                sem_acc[u_current][2] += acc[4][0]
                sem_acc[u_current][3] += acc[3][0]
                sem_acc[u_current][4] += acc[2][0]
                sem_acc[u_current][5] += acc[1][0]
                sem_acc[u_current][6] += acc[0][0]
                ###ndcg
                sem_acc[u_current][7] += ndcg[5][0]
                sem_acc[u_current][8] += ndcg[4][0]
                sem_acc[u_current][9] += ndcg[3][0]
                sem_acc[u_current][10] += ndcg[2][0]
                sem_acc[u_current][11] += ndcg[1][0]
                sem_acc[u_current][12] += ndcg[0][0]
                sem_acc[u_current][0] += (sequences_lens_batch[ii] - 1)

            for ii, u_current in enumerate(user_id_batch_test):
                if u_current not in users_acc:
                    users_acc[u_current] = [0, 0, 0, 0, 0, 0, 0, 0]
                acc, ndcg = get_acc(actual_next_tokens[ii], predictions_logp_poi[ii], predictions_logp_sem[ii], poi_cai)

                users_acc[u_current][1] += acc[2][0]  # @1
                users_acc[u_current][2] += acc[1][0]  # @5
                users_acc[u_current][3] += acc[0][0]  # @10
                ###ndcg
                users_acc[u_current][4] += ndcg[2][0]  # @1
                users_acc[u_current][5] += ndcg[1][0]  # @5
                users_acc[u_current][6] += ndcg[0][0]  # @10
                users_acc[u_current][0] += (sequences_lens_batch[ii] - 1)

        tmp_acc = {}
        tmp_acc_sem = {}
        avg_acc = [0, 0, 0, 0, 0, 0]
        avg_acc_sem = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
        for u in users_acc:
            if u not in tmp_acc:
                tmp_acc[u] = [0, 0, 0, 0, 0, 0, 0]
            tmp_acc[u][0] = users_acc[u][1] / users_acc[u][0]
            tmp_acc[u][1] = users_acc[u][2] / users_acc[u][0]
            tmp_acc[u][2] = users_acc[u][3] / users_acc[u][0]
            tmp_acc[u][3] = users_acc[u][4] / users_acc[u][0]
            tmp_acc[u][4] = users_acc[u][5] / users_acc[u][0]
            tmp_acc[u][5] = users_acc[u][6] / users_acc[u][0]

        avg_acc[0] = np.mean([tmp_acc[x][0] for x in tmp_acc])
        avg_acc[1] = np.mean([tmp_acc[x][1] for x in tmp_acc])
        avg_acc[2] = np.mean([tmp_acc[x][2] for x in tmp_acc])
        avg_acc[3] = np.mean([tmp_acc[x][3] for x in tmp_acc])
        avg_acc[4] = np.mean([tmp_acc[x][4] for x in tmp_acc])
        avg_acc[5] = np.mean([tmp_acc[x][5] for x in tmp_acc])

        for u in sem_acc:
            if u not in tmp_acc_sem:
                tmp_acc_sem[u] = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
            tmp_acc_sem[u][0] = sem_acc[u][1] / sem_acc[u][0]
            tmp_acc_sem[u][1] = sem_acc[u][2] / sem_acc[u][0]
            tmp_acc_sem[u][2] = sem_acc[u][3] / sem_acc[u][0]
            tmp_acc_sem[u][3] = sem_acc[u][4] / sem_acc[u][0]
            tmp_acc_sem[u][4] = sem_acc[u][5] / sem_acc[u][0]
            tmp_acc_sem[u][5] = sem_acc[u][6] / sem_acc[u][0]
            tmp_acc_sem[u][6] = sem_acc[u][7] / sem_acc[u][0]
            tmp_acc_sem[u][7] = sem_acc[u][8] / sem_acc[u][0]
            tmp_acc_sem[u][8] = sem_acc[u][9] / sem_acc[u][0]
            tmp_acc_sem[u][9] = sem_acc[u][10] / sem_acc[u][0]
            tmp_acc_sem[u][10] = sem_acc[u][11] / sem_acc[u][0]
            tmp_acc_sem[u][11] = sem_acc[u][12] / sem_acc[u][0]

        avg_acc_sem[0] = np.mean([tmp_acc_sem[x][0] for x in tmp_acc_sem])
        avg_acc_sem[1] = np.mean([tmp_acc_sem[x][1] for x in tmp_acc_sem])
        avg_acc_sem[2] = np.mean([tmp_acc_sem[x][2] for x in tmp_acc_sem])
        avg_acc_sem[3] = np.mean([tmp_acc_sem[x][3] for x in tmp_acc_sem])
        avg_acc_sem[4] = np.mean([tmp_acc_sem[x][4] for x in tmp_acc_sem])
        avg_acc_sem[5] = np.mean([tmp_acc_sem[x][5] for x in tmp_acc_sem])
        avg_acc_sem[6] = np.mean([tmp_acc_sem[x][6] for x in tmp_acc_sem])
        avg_acc_sem[7] = np.mean([tmp_acc_sem[x][7] for x in tmp_acc_sem])
        avg_acc_sem[8] = np.mean([tmp_acc_sem[x][8] for x in tmp_acc_sem])
        avg_acc_sem[9] = np.mean([tmp_acc_sem[x][9] for x in tmp_acc_sem])
        avg_acc_sem[10] = np.mean([tmp_acc_sem[x][10] for x in tmp_acc_sem])
        avg_acc_sem[11] = np.mean([tmp_acc_sem[x][11] for x in tmp_acc_sem])

        return avg_acc, avg_acc_sem


if __name__ == '__main__':
    np.random.seed(1)
    torch.manual_seed(1)
    os.environ["CUDA_VISIBLE_DEVICES"] = "1"
    data = pickle.load(open('NYC_1.pk', 'rb'), encoding='latin1')
    vid_list = data['vid_list']
    uid_list = data['uid_list']
    cai_list = data['cai_list']
    geo_list = data['geo_list']
    poi_cai = data['poi_cai_lookup']
    data_neural = data['data_neural']

    loc_size = len(vid_list)
    uid_size = len(uid_list)
    cai_size = len(cai_list)
    geo_size = len(geo_list)

    time_sim_matrix = caculate_time_sim(data_neural)
    torch.cuda.empty_cache()
    gc.collect()
    device = torch.device("cuda")
    n_users = uid_size
    n_items = loc_size
    n_cai = cai_size
    n_geo = geo_size
    session_id_sequences = None
    user_id_session = None
    network = Model(n_users=n_users, n_items=n_items, n_cai=n_cai, n_geo=n_geo, data_neural=data_neural,
                    tim_sim_matrix=time_sim_matrix).to(
        device)
    opt = torch.optim.Adam(filter(lambda p: p.requires_grad, network.parameters()), lr=0.0001,
                           weight_decay=1 * 1e-6)
    criterion = nn.NLLLoss().cuda()
    train_network(network, poi_cai, criterion=criterion)
