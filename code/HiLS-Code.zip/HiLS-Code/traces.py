from __future__ import print_function
from __future__ import division

import math
import time
import argparse
import numpy as np
import pickle as pickle
from collections import Counter


def entropy_spatial(sessions):
    locations = {}
    days = sorted(sessions.keys())
    for d in days:
        session = sessions[d]
        for s in session:
            if s[0] not in locations:
                locations[s[0]] = 1
            else:
                locations[s[0]] += 1
    frequency = np.array([locations[loc] for loc in locations])
    frequency = frequency / np.sum(frequency)
    entropy = - np.sum(frequency * np.log(frequency))
    return entropy


class DataFoursquare(object):
    def __init__(self):
        tmp_path = "./TKY/"
        self.TWITTER_PATH = tmp_path + 'dataset_TSMC2014_TKY.csv'
        self.VENUES_PATH = tmp_path + 'venues_all.txt'
        self.SAVE_PATH = tmp_path
        self.save_name = 'TKY'
        self.trace_len_min = 10
        self.location_global_visit_min = 10
        self.hour_gap = 72
        self.min_gap = 10
        self.session_max = 10
        self.filter_short_session = 5
        self.sessions_count_min = 5

        self.train_split = 0.8

        self.data = {}
        self.venues = {}
        self.data_filter = {}
        self.uid_list = {}
        self.vid_list = {'unk': [0, -1]}
        self.vid_list_lookup = {}
        self.cai_list = {'unk': [0, -1]}
        self.cai_list_lookup = {}
        self.geo_list = {'unk': [0, -1]}
        self.pid_loc_lat = {}
        self.vid_lookup = {}
        self.data_neural = {}
        self.geo_list_lookup = {}
        self.poi_cai = {}

    def dist(self, loc1, loc2):
        long1, lat1 = loc1[0], loc1[1]
        long2, lat2 = loc2[0], loc2[1]
        if abs(lat1 - lat2) < 1e-6 and abs(long1 - long2) < 1e-6:
            return 0.0
        degrees_to_radians = math.pi / 180.0
        phi1 = (90.0 - lat1) * degrees_to_radians
        phi2 = (90.0 - lat2) * degrees_to_radians
        theta1 = long1 * degrees_to_radians
        theta2 = long2 * degrees_to_radians
        cos = (math.sin(phi1) * math.sin(phi2) * math.cos(theta1 - theta2) +
               math.cos(phi1) * math.cos(phi2))
        arc = math.acos(cos)
        earth_radius = 6371
        return arc * earth_radius

    def load_trajectory_from_tweets(self):
        with open(self.TWITTER_PATH) as fid:
            for i, line in enumerate(fid):
                if i == 0:
                    continue
                uid, vid, cat, _, lat, lon, _, tid = line.strip('\r\n').split(',')
                if uid not in self.data:
                    self.data[uid] = [[vid, tid, cat]]
                else:
                    self.data[uid].append([vid, tid, cat])
                if vid not in self.venues:
                    self.venues[vid] = 1
                else:
                    self.venues[vid] += 1

    @staticmethod
    def tid_list(tmd):
        tm = time.strptime(tmd, "%Y-%m-%d %H:%M:%S")
        tid = tm.tm_wday * 24 + tm.tm_hour
        return tid

    @staticmethod
    def tid_list_48(tmd):
        tmd2 = tmd.replace(' +0000', '')
        tm = time.strptime(tmd2, "%a %b %d %H:%M:%S %Y")
        if tm.tm_wday in [0, 1, 2, 3, 4]:
            tid = tm.tm_hour
        else:
            tid = tm.tm_hour + 24
        return tid

    def filter_users(self):
        uid_3 = [x for x in self.data if len(self.data[x]) > self.trace_len_min]
        pick3 = sorted([(x, len(self.data[x])) for x in uid_3], key=lambda x: x[1], reverse=True)
        pid_3 = [x for x in self.venues if self.venues[x] > self.location_global_visit_min]
        pid_pic3 = sorted([(x, self.venues[x]) for x in pid_3], key=lambda x: x[1], reverse=True)
        pid_3 = dict(pid_pic3)

        session_len_list = []
        for u in pick3:
            uid = u[0]
            info = self.data[uid]

            topk = Counter([x[0] for x in info]).most_common()
            topk1 = [x[0] for x in topk if x[1] > 1]
            sessions = {}
            for i, record in enumerate(info):
                poi, tmd, cai = record
                try:

                    tmd2 = tmd.replace(' +0000', '')
                    tid = int(time.mktime(time.strptime(tmd2, "%a %b %d %H:%M:%S %Y")))
                except Exception as e:
                    print('error:{}'.format(e))
                    continue
                sid = len(sessions)
                if poi not in pid_3 and poi not in topk1:

                    continue
                if i == 0 or len(sessions) == 0:
                    sessions[sid] = [record]
                else:
                    if (tid - last_tid) / 3600 > self.hour_gap or len(sessions[sid - 1]) > self.session_max:
                        sessions[sid] = [record]
                    elif (tid - last_tid) / 60 > self.min_gap:
                        sessions[sid - 1].append(record)
                    else:
                        pass
                last_tid = tid
            sessions_filter = {}
            for s in sessions:
                if len(sessions[s]) >= self.filter_short_session:
                    sessions_filter[len(sessions_filter)] = sessions[s]
                    session_len_list.append(len(sessions[s]))
            if len(sessions_filter) >= self.sessions_count_min:
                self.data_filter[uid] = {'sessions_count': len(sessions_filter), 'topk_count': len(topk),
                                         'topk': topk,
                                         'sessions': sessions_filter, 'raw_sessions': sessions}

        self.user_filter3 = [x for x in self.data_filter if
                             self.data_filter[x]['sessions_count'] >= self.sessions_count_min]

    def build_users_locations_dict(self):
        for u in self.user_filter3:
            sessions = self.data_filter[u]['sessions']
            if u not in self.uid_list:
                self.uid_list[u] = [len(self.uid_list), len(sessions)]
            for sid in sessions:
                poi = [p[0] for p in sessions[sid]]
                cai = [p[2] for p in sessions[sid]]
                for p in poi:
                    if p not in self.vid_list:
                        self.vid_list_lookup[len(self.vid_list)] = p
                        self.vid_list[p] = [len(self.vid_list), 1]
                    else:
                        self.vid_list[p][1] += 1
                for p in cai:
                    if p not in self.cai_list:
                        self.cai_list_lookup[len(self.cai_list)] = p
                        self.cai_list[p] = [len(self.cai_list), 1]
                    else:
                        self.cai_list[p][1] += 1

    def load_venues(self):
        with open(self.TWITTER_PATH, 'r') as fid:
            i = 0
            for line in fid:
                if i == 0:
                    i = 1
                    continue
                uid, pid, cat, _, lat, lon, _, tid = line.strip('\r\n').split(',')
                self.pid_loc_lat[pid] = [float(lon), float(lat)]

    def venues_lookup(self):
        for vid in self.vid_list_lookup:
            pid = self.vid_list_lookup[vid]
            lon_lat = self.pid_loc_lat[pid]
            self.vid_lookup[vid] = lon_lat

    def add_geo(self):
        for u in self.data_filter:
            sessions = self.data_filter[u]['sessions']
            for sid in sessions:
                for i, checkin in enumerate(sessions[sid]):
                    if(i==0):
                        sessions[sid][i].append(0)
                    else:
                        b = sessions[sid][i][0]
                        loc1 = self.vid_lookup[self.vid_list[sessions[sid][i][0]][0]]
                        loc2 = self.vid_lookup[self.vid_list[sessions[sid][i-1][0]][0]]
                        distance = self.dist(loc1, loc2)
                        distance = distance*10
                        sessions[sid][i].append(round(distance))
        for u in self.data_filter:
            sessions = self.data_filter[u]['sessions']
            for sid in sessions:
                geo = [p[3] for p in sessions[sid]]
                for p in geo:
                    if p not in self.geo_list:
                        self.geo_list_lookup[len(self.geo_list)] = p
                        self.geo_list[p] = [len(self.geo_list), 1]
                    else:
                        self.geo_list[p][1] += 1

    def build_cai_list(self):
        for u in self.data_neural:
            sessions = self.data_neural[u]['sessions']
            for sid in sessions:
                for checkin in sessions[sid]:
                    if checkin[0] in self.poi_cai:
                        continue
                    else:
                        self.poi_cai[checkin[0]] = checkin[2]



    def prepare_neural_data(self):
        for u in self.uid_list:
            sessions = self.data_filter[u]['sessions']
            sessions_tran = {}
            sessions_id = []
            for sid in sessions:
                sessions_tran[sid] = [[self.vid_list[p[0]][0], self.tid_list_48(p[1]), self.cai_list[p[2]][0], self.geo_list[p[3]][0]] for p in
                                      sessions[sid] ]
                sessions_id.append(sid)
            split_id = int(np.floor(self.train_split * len(sessions_id)))
            train_id = sessions_id[:split_id]
            test_id = sessions_id[split_id:]
            pred_len = sum([len(sessions_tran[i]) - 1 for i in train_id])
            valid_len = sum([len(sessions_tran[i]) - 1 for i in test_id])
            train_loc = {}
            for i in train_id:
                for sess in sessions_tran[i]:
                    if sess[0] in train_loc:
                        train_loc[sess[0]] += 1
                    else:
                        train_loc[sess[0]] = 1
            # calculate entropy
            entropy = entropy_spatial(sessions)

            # calculate location ratio
            train_location = []
            for i in train_id:
                train_location.extend([s[0] for s in sessions[i]])
            train_location_set = set(train_location)
            test_location = []
            for i in test_id:
                test_location.extend([s[0] for s in sessions[i]])
            test_location_set = set(test_location)
            whole_location = train_location_set | test_location_set
            test_unique = whole_location - train_location_set
            location_ratio = len(test_unique) / len(whole_location)

            # calculate radius of gyration
            lon_lat = []
            for pid in train_location:
                try:
                    lon_lat.append(self.pid_loc_lat[pid])
                except:
                    print(pid)
                    print('error')
            lon_lat = np.array(lon_lat)
            center = np.mean(lon_lat, axis=0, keepdims=True)
            center = np.repeat(center, axis=0, repeats=len(lon_lat))
            rg = np.sqrt(np.mean(np.sum((lon_lat - center) ** 2, axis=1, keepdims=True), axis=0))[0]

            self.data_neural[self.uid_list[u][0]] = {'sessions': sessions_tran, 'train': train_id, 'test': test_id,
                                                     'pred_len': pred_len, 'valid_len': valid_len,
                                                     'train_loc': train_loc, 'explore': location_ratio,
                                                     'entropy': entropy, 'rg': rg}

    def get_parameters(self):
        parameters = {}
        parameters['TWITTER_PATH'] = self.TWITTER_PATH
        parameters['SAVE_PATH'] = self.SAVE_PATH

        parameters['trace_len_min'] = self.trace_len_min
        parameters['location_global_visit_min'] = self.location_global_visit_min
        parameters['hour_gap'] = self.hour_gap
        parameters['min_gap'] = self.min_gap
        parameters['session_max'] = self.session_max
        parameters['filter_short_session'] = self.filter_short_session
        parameters['sessions_min'] = self.sessions_count_min
        parameters['train_split'] = self.train_split


    def save_variables(self):
        foursquare_dataset = {'data_neural': self.data_neural, 'vid_list': self.vid_list, 'uid_list': self.uid_list, 'cai_list': self.cai_list,
                              'geo_list': self.geo_list,
                              'parameters': self.get_parameters(), 'data_filter': self.data_filter,
                              'vid_lookup': self.vid_lookup, 'poi_cai_lookup': self.poi_cai}
        pickle.dump(foursquare_dataset, open(self.SAVE_PATH + self.save_name + '.pk', 'wb'))



if __name__ == '__main__':
    data_generator = DataFoursquare()
    data_generator.load_trajectory_from_tweets()
    data_generator.filter_users()
    data_generator.build_users_locations_dict()
    data_generator.load_venues()
    data_generator.venues_lookup()
    data_generator.add_geo()
    data_generator.prepare_neural_data()
    data_generator.build_cai_list()
    data_generator.save_variables()
