# RecUP
 Attacking Recommender Systems with Plausible User Profles 

## Getting Started
### Prerequisites
Install Pytorch and other dependencies (e.g., numpy, scipy)

- load datasets:

   -- MovieLens-100K: https://grouplens.org/datasets/movielens/
   
   -- FilmTrust: https://guoguibing.github.io/librec/datasets/filmtrust.zip
   
   -- CiaoDVD: https://guoguibing.github.io/librec/datasets/CiaoDVD.zip

- Code structure:

   -- dataset.py: this file contains the preprocessing of the raw data in datasets.
   
   -- ALS_optimize_origin.py: compute latent factor vectors only using normal profles.
   
   -- ALS_optimize.py: compute latent factor vectors using malicious profles and normal profles.
   
   -- attack_HR.py: compute the HitRatio
   
   -- main.py: the implement of RecUP

## Execute RecUP
*** Run python3 main.py  ***

