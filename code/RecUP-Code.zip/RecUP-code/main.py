import argparse
import random
import copy
import time
import heapq
import numpy as np
import torch
import torch.nn as nn
from torch.autograd import Variable
import math

from dataset import loadtrain, matrix_ones
from attack_HR import com_HR

def select(train,train_data_matrix,opt):
    userCount,itemCount = train_data_matrix.shape
    HitRatio_sim = []
    for i in range(userCount):
        index = (np.ones((opt.mal_use)) * i).astype(np.int32)
        mal_data = np.concatenate((np.zeros((opt.mal_use,1)),train_data_matrix[index, :]),axis = 1)
        HitRatio_i,_,_ = com_HR(opt,train, mal_data)
        HitRatio_sim.append(HitRatio_i)
    np.save('HitRatio_use_sim_%d.npy'%opt.mal_use,HitRatio_sim)  
    return HitRatio_sim


class discriminator(nn.Module):
    def __init__(self,itemCount):
        
        super(discriminator,self).__init__()
        self.dis=nn.Sequential(
            nn.Linear(itemCount,1024),
            nn.ReLU(True),
            nn.Linear(1024,128),
            nn.ReLU(True),
            nn.Linear(128,16),
            nn.ReLU(True),
            nn.Linear(16,1),
            nn.Sigmoid()
        )
    def forward(self,data):
        result=self.dis( data )
        return result  
    
class generator(nn.Module):
    def __init__(self,itemCount):

        super(generator,self).__init__()
        self.gen=nn.Sequential(
            nn.Linear(opt.latent_dim, 256),
            nn.ReLU(True),
            nn.Linear(256, 512),
            nn.ReLU(True),
            nn.Linear(512,1024),
            nn.ReLU(True),
            nn.Linear(1024, itemCount),
            nn.Sigmoid()
        )
    def forward(self,noise):
        result=self.gen(noise) * 5
        return result 


def sigmoid(x):
    return 1 / (1 + math.exp(-x))

def loss_LH(PM_mask, fakeData):
    mal_data = fakeData.cpu().detach().numpy()   
    mal_data = np.concatenate((np.zeros((mal_data.shape[0],1)),mal_data),axis = 1)
    HitRatio, user_features, item_features = com_HR(opt,train, mal_data)
    M_predict = np.dot(user_features, item_features.T)[1:,1:]
    
    no_pur = np.ones_like(PM_mask) - PM_mask
    loss = 0
    for u in range(PM_mask.shape[0]):
        if PM_mask[u,opt.target_item] == 0:
            ru = np.multiply(M_predict[u,:], no_pur[u,:])
            rut = ru[opt.target_item]
            Lu = np.sort(ru)[-10:]
            lossu = 0
            for i in range(Lu.shape[0]):
                lossu = lossu + sigmoid(Lu[i] - rut)
            loss = loss + lossu/Lu.shape[0]
        
    return loss/PM_mask.shape[0]


def main(train, train_data_matrix, inf_use):
    
    userCount,itemCount = train_data_matrix.shape
    PM_mask = matrix_ones(train_data_matrix)
 
    cuda = True if torch.cuda.is_available() else False
    FloatTensor = torch.cuda.FloatTensor if cuda else torch.FloatTensor
    # Build the generator and discriminator
    G=generator(itemCount)
    D=discriminator(itemCount)
    regularization = nn.MSELoss()
    if cuda:
        G.cuda()
        D.cuda()
        regularization.cuda()
    d_optimizer = torch.optim.Adam(D.parameters(), opt.lr, betas=(opt.b1, opt.b2))
    g_optimizer = torch.optim.Adam(G.parameters(), opt.lr, betas=(opt.b1, opt.b2))
        
    # Adversarial ground truths
    valid = Variable(FloatTensor(opt.batch_size, 1).fill_(1.0), requires_grad=False)
    fake = Variable(FloatTensor(opt.batch_size, 1).fill_(0.0), requires_grad=False)
    
    for epoch in range(opt.epochCount):                
        # ---------------------
        #  Train Generator
        # ---------------------
        for step in range(opt.G_step):  
            # Select a random batch of purchased vector                        
            train_index = random.sample(range(0, train_data_matrix.shape[0]), opt.batch_size)            
            realData = Variable(FloatTensor(copy.deepcopy(train_data_matrix[train_index])))
            noise_batch = Variable(FloatTensor(np.random.normal(0, 1, (opt.batch_size, opt.latent_dim))))
            
            # Generate a batch of new purchased vector
            G_Data=G(noise_batch) 
            fakeData =  Variable(FloatTensor(copy.deepcopy(PM_mask[train_index]))) * G_Data.round()
                       
            # Train the generator
            fakeData_result=D(fakeData) 
            g_loss = (1 - opt.lambd) * regularization(fakeData_result, valid) + opt.lambd * loss_LH(PM_mask, fakeData)
            
            g_optimizer.zero_grad()
            g_loss.backward(retain_graph=True)
            g_optimizer.step()
            
        # ---------------------
        #  Train Discriminator
        # ---------------------
        for step in range(opt.D_step):
            # Select a random batch of purchased vector
            train_index = random.sample(range(0, train_data_matrix.shape[0]), opt.batch_size)
            realData = Variable(FloatTensor(copy.deepcopy(train_data_matrix[train_index])))
            noise_batch = Variable(FloatTensor(np.random.normal(0, 1, (opt.batch_size, opt.latent_dim))))
            
            # Generate a batch of new purchased vector 
            G_Data=G(noise_batch) 
            fakeData =  Variable(FloatTensor(copy.deepcopy(PM_mask[train_index]))) * G_Data.round()

            # Train the discriminator
            fakeData_result=D(fakeData) 
            realData_result=D(realData) 
            d_real_loss = regularization(realData_result, valid)
            d_fake_loss = regularization(fakeData_result, fake)
            d_loss = (d_real_loss + d_fake_loss) / 2
            
            d_optimizer.zero_grad()
            d_loss.backward(retain_graph=True)
            d_optimizer.step()
        
        print('Epoch[{}/{}],d_loss:{:.6f},g_loss:{:.6f}'.format(epoch, opt.epochCount,d_loss.item(),g_loss.item()))
    
    inf_index = np.array(list(map(inf_use.index, heapq.nlargest(opt.select_num, inf_use))))
    genindex = inf_index[random.sample(range(0, inf_index.shape[0]), opt.mal_use)]
    noise_batch = Variable(FloatTensor(np.random.normal(0, 1, (opt.mal_use, opt.latent_dim))))
    G_Data=G(noise_batch) 
    fakeData =  Variable(FloatTensor(copy.deepcopy(PM_mask[genindex]))) * G_Data.round()
    mal_data = fakeData.cpu().detach().numpy()
    mal_data = np.concatenate((np.zeros((opt.mal_use,1)),mal_data),axis = 1)
    HitRatio_N,_,_ = com_HR(opt,train, mal_data)
    print (HitRatio_N)
          
    return mal_data
        
    
if __name__ == '__main__':
        
    parser = argparse.ArgumentParser()

    parser.add_argument("--mal_use", type=int, default=47, help="the number of malicious users")
    parser.add_argument("--select_num", type=int, default=64, help="the number of selected potential attack users") 

    parser.add_argument("--target_item", type=int, default=22, help="the target item")
    parser.add_argument("--topN", type=int, default=10, help="the top-N")
    
    parser.add_argument("--lambd", type=float, default=0.5, help="the coefficient of loss")
    parser.add_argument("--converge", type=float, default=1e-5, help="the convergence threshold")
    parser.add_argument("--n_feature", type=int, default=64, help="the number of feature")
    parser.add_argument("--lamda_u", type=float, default=0.05, help="")
    parser.add_argument("--lamda_v", type=float, default=0.05, help="")
    
    parser.add_argument("--batch_size", type=int, default=32, help="size of the batches") 
    parser.add_argument("--epochCount", type=int, default=10, help="number of epochs of training")
    parser.add_argument("--sample_interval", type=int, default=2, help="interval between image sampling")
    parser.add_argument("--latent_dim", type=int, default=100, help="dimensionality of the latent space")

    parser.add_argument("--lr", type=float, default=0.0002, help="adam: learning rate")
    parser.add_argument("--G_step", type=int, default=5, help="the step of G") 
    parser.add_argument("--D_step", type=int, default=2, help="the step of D") 
    parser.add_argument("--b1", type=float, default=0.5, help="adam: decay of first order momentum of gradient")
    parser.add_argument("--b2", type=float, default=0.999, help="adam: decay of first order momentum of gradient")

    opt = parser.parse_args()
    print(opt)
    
    train,train_data_matrix = loadtrain()
    inf_use = select(train,train_data_matrix,opt)
    mal_data = main(train, train_data_matrix, inf_use)
    
   

