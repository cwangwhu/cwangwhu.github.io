import time
import numpy as np
from numpy.random import RandomState
import scipy.sparse as sparse
import heapq

from ALS_optimize import ALS
from ALS_optimize_origin import ALS_origin

def build_user_item_matrix(n_user, n_item, ratings):
    """Build user-item matrix
    Return
    ------
        sparse matrix with shape (n_user, n_item)
    """
    
    data = ratings[:, 2]
    row_ind = ratings[:, 0]
    col_ind = ratings[:, 1]
    shape = (n_user, n_item)
    return sparse.csr_matrix((data, (row_ind, col_ind)), shape=shape)

def arraytorating(malarray, mal_user, n_item):
    malrating = []
    for u in range(mal_user):
        for i in range(n_item):
            if malarray[u,i] != 0 :
                malrating.append([u, i, malarray[u,i]])
    return np.array(malrating)

def predict(data, user_features_, item_features_, max_rating = 2, min_rating = -2):
    data = data.astype(int)
    u_features = user_features_.take(data.take(0, axis=1), axis=0) 
    i_features = item_features_.take(data.take(1, axis=1), axis=0)
    preds = np.sum(u_features * i_features, 1)
    if max_rating:
        preds[preds > max_rating] = max_rating
    if min_rating:
        preds[preds < min_rating] = min_rating
    return preds

def RMSE(estimation, truth):
    """Root Mean Square Error"""
    estimation = np.float64(estimation)
    truth = np.float64(truth)
    num_sample = estimation.shape[0]
    
    # sum square error
    sse = np.sum(np.square(truth - estimation))
    return np.sqrt(np.divide(sse, num_sample - 1))

def optimize_model_origin(converge, n_user, n_item, n_feature, train, mean_rating_, lamda_u, lamda_v, user_features_origin_, item_features_origin_):   

    last_rmse = None
    n_iters = 100
    for iteration in range(n_iters):
        t1 = time.time()
        user_features_origin_, item_features_origin_ = ALS_origin(n_user, n_item, n_feature, train, mean_rating_, lamda_u, lamda_v, user_features_origin_, item_features_origin_)
        train_preds = predict(train.take([0, 1], axis=1), user_features_origin_, item_features_origin_)
        train_rmse = RMSE(train_preds, train.take(2, axis=1) - 3)
        t2 = time.time()
        print("The %d th iteration \t time: %f s \t RMSE: %f " % (iteration + 1, t2 - t1, train_rmse))
        # stop when converge
        if last_rmse and abs(train_rmse - last_rmse) < converge:
            break
        else:
            last_rmse = train_rmse
    return last_rmse, user_features_origin_, item_features_origin_



def optimize_model(converge, n_user, n_item, n_feature, mal_user, train, mean_rating_, mal_mean_rating_, mal_ratings, lamda_u, lamda_v, \
        user_features_, mal_user_features_, item_features_):
    
    last_rmse = None
    n_iters = 100
    for iteration in range(n_iters):
        user_features_, mal_user_features_, item_features_ = ALS(n_user, n_item, n_feature, mal_user, \
                                train, mean_rating_, mal_mean_rating_, mal_ratings, lamda_u, lamda_v, \
                                user_features_, mal_user_features_, item_features_)
        train_preds = predict(train.take([0, 1], axis=1), user_features_, item_features_)
        train_rmse = RMSE(train_preds, train.take(2, axis=1) - 3)

        # stop when converge
        if last_rmse and abs(train_rmse - last_rmse) < converge:
            break
        else:
            last_rmse = train_rmse
    return last_rmse, user_features_, mal_user_features_, item_features_


def HR(train_data_matrix, user_features_, item_features_, topN, target_item):
    M_predict = np.dot(user_features_, item_features_.T) 
    hit = 0
    count = 0   
    for i in range(M_predict.shape[0]-1):
        predict_i = M_predict[i+1,:]       
        top_index = heapq.nlargest(topN,range(len(predict_i)), predict_i.take)       
        if target_item in top_index:
            if train_data_matrix[i,target_item] == 0:
                hit = hit + 1
            else:
                count = count + 1   
    return hit/(i - count)


def com_HR(opt,ratings,mal_data):       
    n_user = max(ratings[:, 0]) + 1
    n_item = max(ratings[:, 1]) + 1
    mal_user = mal_data.shape[0]
    print(mal_user)
    train_data_matrix = build_user_item_matrix(n_user,n_item,ratings).toarray()
    mean_rating_ = np.mean(ratings.take(2, axis=1))
    
    seed = None   
    user_features_ = 0.1 * RandomState(seed).rand(n_user, opt.n_feature)
    mal_user_features_ = 0.1 * RandomState(seed).rand(mal_user, opt.n_feature)
    item_features_ = 0.1 * RandomState(seed).rand(n_item, opt.n_feature)
    mal_ratings = arraytorating(mal_data, mal_user, n_item).astype(np.int32)
    mal_mean_rating_ = np.mean(mal_ratings.take(2, axis=1))
    rmse, user_features_, mal_user_features_, item_features_ = optimize_model(opt.converge, \
                   n_user, n_item, opt.n_feature, mal_user, ratings, \
                   mean_rating_, mal_mean_rating_, mal_ratings, opt.lamda_u, \
                   opt.lamda_v, user_features_, mal_user_features_, item_features_)
    
    HitRatio = HR(train_data_matrix, user_features_, item_features_, opt.topN, opt.target_item)
    return HitRatio, user_features_, item_features_
















