import numpy as np
import pandas as pd
import scipy.sparse as sparse
import copy


def loadtrain():
    column_names = ['user_id', 'item_id', 'rating', 'timestamp']
    df = pd.read_csv('u.data', sep='\t', names=column_names)

    train = copy.deepcopy(df.values[:,0:3])

    df['item_id'] = df['item_id'] - 1
    df['user_id'] = df['user_id'] - 1

    n_users = df.user_id.nunique() 
    n_items = df.item_id.nunique() 
    train_data_matrix = np.zeros((n_users, n_items))
    for line in df.itertuples():
        train_data_matrix[line[1], line[2]] = line[3]
        
    return train, train_data_matrix


def matrix_ones(train_data_matrix):
    train_data_ones = np.zeros_like(train_data_matrix)
    for i in range(train_data_matrix.shape[0]):
        for j in range(train_data_matrix.shape[1]):
            if train_data_matrix[i,j] != 0:
                train_data_ones[i,j] = 1
    return train_data_ones

    
def build_user_item_matrix(n_user, n_item, ratings):
    """Build user-item matrix
    Return
    ------
        sparse matrix with shape (n_user, n_item)
    """
    data = ratings[:, 2]
    row_ind = ratings[:, 0]
    col_ind = ratings[:, 1]
    shape = (n_user, n_item)
    return sparse.csr_matrix((data, (row_ind, col_ind)), shape=shape)